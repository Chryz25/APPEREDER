package com.example.a404

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.view.WindowCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

// ─────────────────────────────────────────────────────────────────────────────
//  DATA CLASSES
// ─────────────────────────────────────────────────────────────────────────────

data class QuizQuestion(
    val question: String,
    val choices:  List<String>,       // exactly 4 choices
    val answer:   String              // one of the choices (exact text)
)

// ─────────────────────────────────────────────────────────────────────────────
//  ACTIVITY
// ─────────────────────────────────────────────────────────────────────────────

class GroqQuizActivity : ComponentActivity() {

    // ── Groq API ──────────────────────────────────────────────────────────────
    // ★★★  REPLACE WITH YOUR REAL GROQ API KEY  ★★★
    // Get a free key at https://console.groq.com
    private val GROQ_API_KEY = "YOUR_GROQ_API_KEY_HERE"
    private val GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
    private val GROQ_MODEL   = "llama3-8b-8192"

    private val client: OkHttpClient by lazy { OkHttpClient.Builder().connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS).readTimeout(30, java.util.concurrent.TimeUnit.SECONDS).build() }

    // ── State ─────────────────────────────────────────────────────────────────
    private var summaryText   = ""
    private var keyTopicsText = ""
    private var questions     = listOf<QuizQuestion>()

    // Selected answers map: questionIndex → choiceIndex
    private val userAnswers   = mutableMapOf<Int, Int>()
    private var quizSubmitted = false

    // ── Views ─────────────────────────────────────────────────────────────────
    private lateinit var layoutLoading:    LinearLayout
    private lateinit var tvLoadingLabel:   TextView
    private lateinit var layoutSummary:    LinearLayout
    private lateinit var layoutQuiz:       LinearLayout
    private lateinit var tvBookName:       TextView
    private lateinit var tvSummaryText:    TextView
    private lateinit var tvKeyTopics:      TextView
    private lateinit var quizContainer:    LinearLayout
    private lateinit var btnSubmitQuiz:    Button
    private lateinit var btnRetryQuiz:     Button
    private lateinit var cardScore:        CardView
    private lateinit var tvScoreEmoji:     TextView
    private lateinit var tvScoreLabel:     TextView
    private lateinit var tvScoreSub:       TextView
    private lateinit var tabSummary:       TextView
    private lateinit var tabQuiz:          TextView
    private lateinit var tabIndicator:     View
    private lateinit var btnGoToQuiz:      Button

    // Book info passed from LibraryDetailsActivity
    private var bookTitle   = ""
    private var bookAuthor  = ""
    private var bookDesc    = ""
    private var bookCourse  = ""
    private var bookYear    = ""
    private var bookUrl     = ""    // raw.githubusercontent.com URL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_groq_quiz)

        // ── Receive book info ─────────────────────────────────────────────────
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        bookTitle  = intent.getStringExtra(AppConstants.EXTRA_BOOK_TITLE)   ?: prefs.getString("SELECTED_BOOK",    "") ?: ""
        bookAuthor = intent.getStringExtra(AppConstants.EXTRA_BOOK_AUTHOR)  ?: prefs.getString("SELECTED_AUTHOR",  "") ?: ""
        bookDesc   = intent.getStringExtra(AppConstants.EXTRA_BOOK_DESC)    ?: prefs.getString("SELECTED_DESC",    "") ?: ""
        bookCourse = intent.getStringExtra(AppConstants.EXTRA_BOOK_COURSE)  ?: prefs.getString("SELECTED_COURSE",  "") ?: ""
        bookYear   = intent.getStringExtra(AppConstants.EXTRA_BOOK_YEAR)    ?: prefs.getString("SELECTED_YEAR",    "") ?: ""
        bookUrl    = intent.getStringExtra(AppConstants.EXTRA_BOOK_URL)     ?: prefs.getString("SELECTED_BOOK_URL","") ?: ""

        // ── Bind views ────────────────────────────────────────────────────────
        layoutLoading  = findViewById(R.id.layout_loading)
        tvLoadingLabel = findViewById(R.id.tv_loading_label)
        layoutSummary  = findViewById(R.id.layout_summary)
        layoutQuiz     = findViewById(R.id.layout_quiz)
        tvBookName     = findViewById(R.id.tv_book_name_summary)
        tvSummaryText  = findViewById(R.id.tv_summary_text)
        tvKeyTopics    = findViewById(R.id.tv_key_topics)
        quizContainer  = findViewById(R.id.quiz_questions_container)
        btnSubmitQuiz  = findViewById(R.id.btn_submit_quiz)
        btnRetryQuiz   = findViewById(R.id.btn_retry_quiz)
        cardScore      = findViewById(R.id.card_score)
        tvScoreEmoji   = findViewById(R.id.tv_score_emoji)
        tvScoreLabel   = findViewById(R.id.tv_score_label)
        tvScoreSub     = findViewById(R.id.tv_score_sub)
        tabSummary     = findViewById(R.id.tab_summary)
        tabQuiz        = findViewById(R.id.tab_quiz)
        tabIndicator   = findViewById(R.id.tab_indicator)
        btnGoToQuiz    = findViewById(R.id.btn_go_to_quiz)

        tvBookName.text = bookTitle

        // ── Back button ───────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        // ── Tab switching ─────────────────────────────────────────────────────
        tabSummary.setOnClickListener { showTab(TAB_SUMMARY) }
        tabQuiz.setOnClickListener    { showTab(TAB_QUIZ)    }
        btnGoToQuiz.setOnClickListener { showTab(TAB_QUIZ)   }

        // ── Submit / Retry ────────────────────────────────────────────────────
        btnSubmitQuiz.setOnClickListener { submitQuiz() }
        btnRetryQuiz.setOnClickListener  { retryQuiz()  }

        // ── Kick off AI generation ────────────────────────────────────────────
        if (bookUrl.isNotBlank()) {
            fetchPdfThenGenerate()
        } else {
            generateFromBookInfo()
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  TAB MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    companion object {
        private const val TAB_SUMMARY = 0
        private const val TAB_QUIZ    = 1
    }

    private var currentTab = TAB_SUMMARY

    private fun showTab(tab: Int) {
        currentTab = tab
        val dp = resources.displayMetrics.density

        if (tab == TAB_SUMMARY) {
            tabSummary.setTextColor(Color.parseColor("#FF6A1B9A"))
            tabSummary.setTypeface(null, Typeface.BOLD)
            tabQuiz.setTextColor(Color.parseColor("#FF888888"))
            tabQuiz.setTypeface(null, Typeface.NORMAL)

            // Slide indicator to Summary half
            val cs = ConstraintSet()
            cs.clone(tabIndicator.parent as androidx.constraintlayout.widget.ConstraintLayout)
            cs.connect(R.id.tab_indicator, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
            cs.connect(R.id.tab_indicator, ConstraintSet.END,   R.id.tab_summary,        ConstraintSet.END)
            cs.applyTo(tabIndicator.parent as androidx.constraintlayout.widget.ConstraintLayout)

            layoutSummary.visibility = if (summaryText.isNotEmpty()) View.VISIBLE else View.GONE
            layoutQuiz.visibility    = View.GONE
            layoutLoading.visibility = if (summaryText.isEmpty())  View.VISIBLE else View.GONE

        } else {
            tabQuiz.setTextColor(Color.parseColor("#FF6A1B9A"))
            tabQuiz.setTypeface(null, Typeface.BOLD)
            tabSummary.setTextColor(Color.parseColor("#FF888888"))
            tabSummary.setTypeface(null, Typeface.NORMAL)

            val cs = ConstraintSet()
            cs.clone(tabIndicator.parent as androidx.constraintlayout.widget.ConstraintLayout)
            cs.connect(R.id.tab_indicator, ConstraintSet.START, R.id.tab_quiz, ConstraintSet.START)
            cs.connect(R.id.tab_indicator, ConstraintSet.END,   ConstraintSet.PARENT_ID, ConstraintSet.END)
            cs.applyTo(tabIndicator.parent as androidx.constraintlayout.widget.ConstraintLayout)

            layoutSummary.visibility = View.GONE
            layoutLoading.visibility = if (questions.isEmpty()) View.VISIBLE else View.GONE
            layoutQuiz.visibility    = if (questions.isNotEmpty()) View.VISIBLE else View.GONE
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PDF FETCHING
    // ─────────────────────────────────────────────────────────────────────────

    private fun fetchPdfThenGenerate() {
        updateLoadingLabel("Downloading PDF from GitHub…")
        val request = Request.Builder().url(bookUrl).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { generateFromBookInfo() }
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread { generateFromBookInfo(); return@runOnUiThread }
                    return
                }
                val file = File(cacheDir, "quiz_temp.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(file).use { out -> input.copyTo(out) }
                    }
                    val text = extractTextFromPdf(file)
                    runOnUiThread {
                        if (text.length > 200) callGroqWithText(text)
                        else                   generateFromBookInfo()
                    }
                } catch (e: Exception) {
                    runOnUiThread { generateFromBookInfo() }
                }
            }
        })
    }

    /** Extract plain text from a PDF using Android's PdfRenderer (renders pages → OCR-free text extraction isn't natively supported,
     *  so we extract the description + chapter titles as context and combine them). */
    private fun extractTextFromPdf(file: File): String {
        // Android's PdfRenderer renders to Bitmap only — no native text extraction.
        // We return a rich context string built from the book metadata + chapter list
        // so Groq can generate meaningful content. For full text extraction, a library
        // like PdfBox-Android would be needed; for now we send all available metadata.
        return buildBookContext()
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GROQ API CALLS
    // ─────────────────────────────────────────────────────────────────────────

    private fun buildBookContext(): String {
        return """
Book Title:  $bookTitle
Author:      $bookAuthor
Course:      $bookCourse ($bookYear)
Description: $bookDesc
        """.trimIndent()
    }

    /** Called when we have real PDF text (or fallback metadata). */
    private fun callGroqWithText(context: String) {
        updateLoadingLabel("Groq AI is generating summary…")

        val summaryPrompt = """
You are an expert academic tutor. Based on the following book/PDF information, generate:

1. A clear, engaging SUMMARY (4-6 sentences) covering the main themes, purpose and key ideas of this academic material.
2. A list of 5 KEY TOPICS (bullet points, each 1 line).

Book Information:
$context

Respond in this EXACT format (no markdown, no extra text):
SUMMARY:
[your summary here]

KEY_TOPICS:
• [topic 1]
• [topic 2]
• [topic 3]
• [topic 4]
• [topic 5]
        """.trimIndent()

        callGroq(summaryPrompt) { responseText ->
            parseSummaryResponse(responseText)
            updateLoadingLabel("Groq AI is generating quiz questions…")
            generateQuizQuestions(context)
        }
    }

    private fun generateFromBookInfo() {
        callGroqWithText(buildBookContext())
    }

    private fun generateQuizQuestions(context: String) {
        val quizPrompt = """
You are an expert academic quiz creator. Based on the following book/course information, generate exactly 10 multiple-choice questions.

Book Information:
$context

Rules:
- Each question must have exactly 4 choices labeled A, B, C, D
- One choice must be the correct answer
- Questions should test understanding of the subject, not trivial facts
- Vary difficulty: mix easy, medium, and hard questions
- Make wrong choices plausible but clearly incorrect

Respond ONLY with valid JSON in this EXACT format (no markdown, no extra text, no comments):
[
  {
    "question": "Question text here?",
    "choices": ["Choice A", "Choice B", "Choice C", "Choice D"],
    "answer": "Choice A"
  }
]

Generate all 10 questions now:
        """.trimIndent()

        callGroq(quizPrompt) { responseText ->
            parseQuizResponse(responseText)
        }
    }

    private fun callGroq(prompt: String, onSuccess: (String) -> Unit) {
        val json = JSONObject().apply {
            put("model", GROQ_MODEL)
            put("max_tokens", 2048)
            put("temperature", 0.7)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role",    "user")
                    put("content", prompt)
                })
            })
        }

        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(GROQ_API_URL)
            .header("Authorization", "Bearer $GROQ_API_KEY")
            .header("Content-Type", "application/json")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showError("Network error: ${e.message}")
                }
            }
            override fun onResponse(call: Call, response: Response) {
                val bodyStr = response.body?.string() ?: ""
                runOnUiThread {
                    if (!response.isSuccessful) {
                        showError("Groq API error ${response.code}: check your API key.")
                        return@runOnUiThread
                    }
                    try {
                        val content = JSONObject(bodyStr)
                            .getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        onSuccess(content)
                    } catch (e: Exception) {
                        showError("Failed to parse Groq response.")
                    }
                }
            }
        })
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RESPONSE PARSERS
    // ─────────────────────────────────────────────────────────────────────────

    private fun parseSummaryResponse(text: String) {
        val summaryMatch = Regex("SUMMARY:\\s*\\n([\\s\\S]*?)(?=KEY_TOPICS:|$)", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.getOrNull(1)?.trim() ?: text.trim()

        val topicsMatch  = Regex("KEY_TOPICS:\\s*\\n([\\s\\S]*)", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.getOrNull(1)?.trim() ?: ""

        summaryText   = summaryMatch
        keyTopicsText = topicsMatch

        tvSummaryText.text = summaryText
        tvKeyTopics.text   = keyTopicsText.ifBlank { "• Topics will appear here" }

        layoutLoading.visibility = View.GONE
        layoutSummary.visibility = View.VISIBLE
    }

    private fun parseQuizResponse(raw: String) {
        // Strip markdown fences if present
        val cleaned = raw
            .replace(Regex("```json\\s*"), "")
            .replace(Regex("```\\s*"), "")
            .trim()

        try {
            val arr = JSONArray(cleaned)
            val parsed = mutableListOf<QuizQuestion>()
            for (i in 0 until arr.length()) {
                val obj     = arr.getJSONObject(i)
                val q       = obj.getString("question")
                val choices = obj.getJSONArray("choices")
                val answer  = obj.getString("answer")
                val choiceList = (0 until choices.length()).map { choices.getString(it) }
                if (choiceList.size == 4) {
                    parsed.add(QuizQuestion(q, choiceList, answer))
                }
            }
            if (parsed.isNotEmpty()) {
                questions = parsed
                buildQuizUI()
            } else {
                showError("No valid questions parsed from AI response.")
            }
        } catch (e: Exception) {
            showError("Quiz parse error: ${e.message}")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  QUIZ UI BUILDER
    // ─────────────────────────────────────────────────────────────────────────

    private fun buildQuizUI() {
        quizContainer.removeAllViews()
        userAnswers.clear()
        quizSubmitted = false

        val dp = resources.displayMetrics.density

        questions.forEachIndexed { qIdx, question ->
            // Question card
            val card = CardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (16 * dp).toInt() }
                radius        = 14 * dp
                cardElevation = 3 * dp
                setCardBackgroundColor(Color.WHITE)
            }

            val cardInner = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
            }

            // Question number + text
            val qHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.TOP
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (12 * dp).toInt() }
            }

            val numBadge = TextView(this).apply {
                text = "${qIdx + 1}"
                layoutParams = LinearLayout.LayoutParams(
                    (28 * dp).toInt(), (28 * dp).toInt()
                ).also { it.marginEnd = (10 * dp).toInt() }
                setBackgroundColor(Color.parseColor("#FFEDE7F6"))
                setTextColor(Color.parseColor("#FF6A1B9A"))
                textSize  = 12f
                setTypeface(null, Typeface.BOLD)
                gravity   = Gravity.CENTER
            }

            val qText = TextView(this).apply {
                text = question.question
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setTextColor(Color.parseColor("#FF1A1A1A"))
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
                lineSpacingMultiplier = 1.4f
            }

            qHeader.addView(numBadge)
            qHeader.addView(qText)
            cardInner.addView(qHeader)

            // Choice buttons
            val choiceLabels = listOf("A", "B", "C", "D")
            val choiceViews  = mutableListOf<CardView>()

            question.choices.forEachIndexed { cIdx, choiceText ->
                val choiceCard = CardView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.bottomMargin = (8 * dp).toInt() }
                    radius        = 10 * dp
                    cardElevation = 1 * dp
                    setCardBackgroundColor(Color.parseColor("#FFF8F4FF"))
                    isClickable = true
                    isFocusable = true
                }

                val choiceRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity     = Gravity.CENTER_VERTICAL
                    setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
                }

                val labelBadge = TextView(this).apply {
                    text = choiceLabels[cIdx]
                    layoutParams = LinearLayout.LayoutParams(
                        (26 * dp).toInt(), (26 * dp).toInt()
                    ).also { it.marginEnd = (10 * dp).toInt() }
                    setBackgroundColor(Color.parseColor("#FFEDE7F6"))
                    setTextColor(Color.parseColor("#FF6A1B9A"))
                    textSize  = 11f
                    setTypeface(null, Typeface.BOLD)
                    gravity   = Gravity.CENTER
                }

                val choiceTv = TextView(this).apply {
                    text = choiceText
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    setTextColor(Color.parseColor("#FF333333"))
                    textSize = 13f
                    lineSpacingMultiplier = 1.3f
                }

                choiceRow.addView(labelBadge)
                choiceRow.addView(choiceTv)
                choiceCard.addView(choiceRow)

                choiceCard.setOnClickListener {
                    if (quizSubmitted) return@setOnClickListener
                    userAnswers[qIdx] = cIdx
                    // Update visual: reset all in this question, highlight selected
                    choiceViews.forEachIndexed { i, cv ->
                        cv.setCardBackgroundColor(
                            if (i == cIdx) Color.parseColor("#FFEDE7F6")
                            else           Color.parseColor("#FFF8F4FF")
                        )
                        cv.cardElevation = if (i == cIdx) 3 * dp else 1 * dp
                        // Tint the label badge
                        val inner = (cv.getChildAt(0) as LinearLayout).getChildAt(0) as TextView
                        inner.setBackgroundColor(
                            if (i == cIdx) Color.parseColor("#FF6A1B9A")
                            else           Color.parseColor("#FFEDE7F6")
                        )
                        inner.setTextColor(
                            if (i == cIdx) Color.WHITE
                            else           Color.parseColor("#FF6A1B9A")
                        )
                    }
                    // Show submit button when all questions answered
                    if (userAnswers.size == questions.size) {
                        btnSubmitQuiz.visibility = View.VISIBLE
                    }
                }

                choiceViews.add(choiceCard)
                cardInner.addView(choiceCard)
            }

            card.addView(cardInner)
            quizContainer.addView(card)
        }

        btnSubmitQuiz.visibility = View.VISIBLE
        btnRetryQuiz.visibility  = View.GONE
        cardScore.visibility     = View.GONE

        layoutLoading.visibility = View.GONE
        layoutQuiz.visibility    = View.VISIBLE

        if (currentTab == TAB_QUIZ) showTab(TAB_QUIZ)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  QUIZ SUBMIT / RETRY / SCORING
    // ─────────────────────────────────────────────────────────────────────────

    private fun submitQuiz() {
        quizSubmitted = true
        btnSubmitQuiz.visibility = View.GONE
        btnRetryQuiz.visibility  = View.VISIBLE

        val dp = resources.displayMetrics.density
        var correct = 0

        questions.forEachIndexed { qIdx, question ->
            val selectedIdx = userAnswers[qIdx] ?: -1

            // Find the card for this question
            val card     = quizContainer.getChildAt(qIdx) as? CardView ?: return@forEachIndexed
            val cardInner = card.getChildAt(0) as? LinearLayout       ?: return@forEachIndexed

            // Choice cards start at index 1 (index 0 is the question header row)
            question.choices.forEachIndexed { cIdx, choiceText ->
                val choiceCard = cardInner.getChildAt(cIdx + 1) as? CardView ?: return@forEachIndexed
                val choiceRow  = choiceCard.getChildAt(0) as? LinearLayout    ?: return@forEachIndexed
                val labelBadge = choiceRow.getChildAt(0) as? TextView          ?: return@forEachIndexed
                val choiceTv   = choiceRow.getChildAt(1) as? TextView          ?: return@forEachIndexed

                val isCorrect  = (choiceText == question.answer)
                val isSelected = (cIdx == selectedIdx)

                when {
                    isCorrect -> {
                        // Always highlight correct answer in green
                        choiceCard.setCardBackgroundColor(Color.parseColor("#FFE8F5E9"))
                        labelBadge.setBackgroundColor(Color.parseColor("#FF4CAF50"))
                        labelBadge.setTextColor(Color.WHITE)
                        choiceTv.setTextColor(Color.parseColor("#FF2E7D32"))
                        choiceTv.setTypeface(null, Typeface.BOLD)
                        if (isSelected) correct++
                    }
                    isSelected && !isCorrect -> {
                        // Wrong selection in red
                        choiceCard.setCardBackgroundColor(Color.parseColor("#FFFCE4EC"))
                        labelBadge.setBackgroundColor(Color.parseColor("#FFF44336"))
                        labelBadge.setTextColor(Color.WHITE)
                        choiceTv.setTextColor(Color.parseColor("#FFC62828"))
                    }
                    else -> {
                        choiceCard.setCardBackgroundColor(Color.parseColor("#FFF8F4FF"))
                        labelBadge.setBackgroundColor(Color.parseColor("#FFEDE7F6"))
                        labelBadge.setTextColor(Color.parseColor("#FF6A1B9A"))
                        choiceTv.setTextColor(Color.parseColor("#FF888888"))
                    }
                }
                choiceCard.isClickable = false
            }
        }

        // Show score card
        val total   = questions.size
        val pct     = (correct * 100) / total
        val (emoji, sub) = when {
            pct >= 90 -> "🏆" to "Outstanding! You've mastered this material."
            pct >= 70 -> "🎉" to "Great job! Review a few more topics."
            pct >= 50 -> "📚" to "Good effort — re-read the summary and try again."
            else      -> "💪" to "Keep studying! Every attempt builds knowledge."
        }

        tvScoreEmoji.text  = emoji
        tvScoreLabel.text  = "$correct / $total Correct  ($pct%)"
        tvScoreSub.text    = sub
        cardScore.visibility = View.VISIBLE

        // Scroll to top of quiz to show score
        findViewById<androidx.core.widget.NestedScrollView>(R.id.scroll_content).smoothScrollTo(0, 0)
    }

    private fun retryQuiz() {
        userAnswers.clear()
        quizSubmitted = false
        cardScore.visibility     = View.GONE
        btnRetryQuiz.visibility  = View.GONE

        // Rebuild question UI with fresh state
        buildQuizUI()
        showTab(TAB_QUIZ)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private fun updateLoadingLabel(msg: String) {
        runOnUiThread { tvLoadingLabel.text = msg }
    }

    private fun showError(msg: String) {
        layoutLoading.visibility = View.GONE
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        // Show a simple retry option
        layoutLoading.visibility = View.VISIBLE
        tvLoadingLabel.text      = "⚠️ $msg"
        findViewById<TextView>(R.id.tv_loading_sub).text = "Check your Groq API key in GroqQuizActivity.kt"
    }
}
