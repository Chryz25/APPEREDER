package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

// BookData lives here as the canonical definition — no other file defines it
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String,
    val downloadUrl: String = ""
)

class ChoosingPhaseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  ONLY EDIT REPO URLS HERE — all other files read from SharedPrefs  ★
    // ════════════════════════════════════════════════════════════════════════
    private val REPO_BSCS_1  = "cyniccccc/UI"
    private val REPO_BSCS_2  = "cyniccccc/UI"
    private val REPO_BSCS_3  = "cyniccccc/UI"
    private val REPO_BSCS_4  = "cyniccccc/UI"
    private val REPO_BSIT_1  = "cyniccccc/UI"
    private val REPO_BSIT_2  = "cyniccccc/UI"
    private val REPO_BSIT_3  = "cyniccccc/UI"
    private val REPO_BSIT_4  = "cyniccccc/UI"
    private val REPO_BSMC_1  = "cyniccccc/UI"
    private val REPO_BSMC_2  = "cyniccccc/UI"
    private val REPO_BSMC_3  = "cyniccccc/UI"
    private val REPO_BSMC_4  = "cyniccccc/UI"
    private val REPO_BSACT_1 = "cyniccccc/UI"
    private val REPO_BSACT_2 = "cyniccccc/UI"
    // ════════════════════════════════════════════════════════════════════════

    private val SLOT_REPOS: Map<String, String> by lazy {
        mapOf(
            "BS Computer Science|1st Year"            to norm(REPO_BSCS_1),
            "BS Computer Science|2nd Year"            to norm(REPO_BSCS_2),
            "BS Computer Science|3rd Year"            to norm(REPO_BSCS_3),
            "BS Computer Science|4th Year"            to norm(REPO_BSCS_4),
            "BS Information Technology|1st Year"      to norm(REPO_BSIT_1),
            "BS Information Technology|2nd Year"      to norm(REPO_BSIT_2),
            "BS Information Technology|3rd Year"      to norm(REPO_BSIT_3),
            "BS Information Technology|4th Year"      to norm(REPO_BSIT_4),
            "BS Multimedia Computing|1st Year"        to norm(REPO_BSMC_1),
            "BS Multimedia Computing|2nd Year"        to norm(REPO_BSMC_2),
            "BS Multimedia Computing|3rd Year"        to norm(REPO_BSMC_3),
            "BS Multimedia Computing|4th Year"        to norm(REPO_BSMC_4),
            "BS Applied Computer Technology|1st Year" to norm(REPO_BSACT_1),
            "BS Applied Computer Technology|2nd Year" to norm(REPO_BSACT_2)
        )
    }

    // OkHttpClient with proper timeouts — shared instance, never created per-request
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private val bookCatalog  = mutableMapOf<String, BookData>()
    private val pendingCount = AtomicInteger(0)
    private val mainHandler  = Handler(Looper.getMainLooper())
    private val MAX_RETRIES  = 2

    private val courseLabels  = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )
    private val allYearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")
    private val BSACT_YEARS   = setOf("1st Year", "2nd Year")
    private val BSACT_INDEX   = 3

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex   = -1
    private var yearIndex     = -1
    private var selectedCourse: MaterialCardView? = null
    private var selectedYear:   MaterialCardView? = null
    private var bookConfirmed = false

    // Views
    private lateinit var tvHint:          TextView
    private lateinit var tvRetryStatus:   TextView
    private lateinit var progressLoading: ProgressBar
    private lateinit var bookGridLayout:  View
    private lateinit var bookCard:        MaterialCardView
    private lateinit var tvBookTitle:     TextView
    private lateinit var tvBookAuthor:    TextView
    private lateinit var tvBookDesc:      TextView
    private lateinit var tvBookChapters:  TextView
    private lateinit var btnContinue:     Button
    private lateinit var btnRetry:        Button
    private lateinit var yearChips:       List<MaterialCardView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        bindViews()
        wireListeners()
        setInitialState()
        fetchAllSlots()
    }

    // ── Binding ───────────────────────────────────────────────────────────────
    private fun bindViews() {
        btnContinue     = findViewById(R.id.btn_continue)
        tvHint          = findViewById(R.id.tv_book_hint)
        bookGridLayout  = findViewById(R.id.book_grid)
        bookCard        = findViewById(R.id.selectionbook_1)
        tvBookTitle     = findViewById(R.id.book_title_label)
        tvBookAuthor    = findViewById(R.id.book_author_label)
        tvBookDesc      = findViewById(R.id.book_desc_label)
        tvBookChapters  = findViewById(R.id.book_chapters_label)
        progressLoading = findViewById(R.id.progress_loading)
        tvRetryStatus   = findViewById(R.id.tv_retry_status)
        btnRetry        = findViewById(R.id.btn_retry_load)
        yearChips = listOf(
            findViewById(R.id.chip_year_1),
            findViewById(R.id.chip_year_2),
            findViewById(R.id.chip_year_3),
            findViewById(R.id.chip_year_4)
        )
    }

    private fun wireListeners() {
        btnContinue.isEnabled = false

        // Retry button — clears state and re-fetches
        btnRetry.setOnClickListener {
            bookCatalog.clear()
            fetchAllSlots()
        }

        // Course cards
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                selectedCourse = toggleCard(card, courses, selectedCourse)
                courseIndex    = if (selectedCourse != null) idx else -1
                yearIndex      = -1
                selectedYear   = null
                bookConfirmed  = false
                applyYearChipVisibility()
                refreshBookCard()
            }
        }

        // Year chips
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                if (chip.visibility != View.VISIBLE || !chip.isEnabled) return@setOnClickListener
                val visible    = yearChips.filter { it.visibility == View.VISIBLE && it.isEnabled }
                selectedYear   = toggleCard(chip, visible, selectedYear)
                yearIndex      = if (selectedYear != null) idx else -1
                bookConfirmed  = false
                refreshBookCard()
            }
        }

        // Book card — tap to confirm / deconfirm
        bookCard.setOnClickListener {
            if (courseIndex < 0 || yearIndex < 0 || !bookCatalog.containsKey(currentKey())) return@setOnClickListener
            bookConfirmed = !bookConfirmed
            val dp = resources.displayMetrics.density
            if (bookConfirmed) {
                bookCard.strokeWidth = (strokeSelected * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                bookCard.setCardBackgroundColor(colorSelected)
                tintChildren(bookCard, "#FF6A1B9A")
            } else {
                bookCard.strokeWidth = (strokeDefault * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                bookCard.setCardBackgroundColor(colorDefault)
                tintChildren(bookCard, "#FF2A2A2A")
            }
        }

        // Continue
        btnContinue.setOnClickListener {
            when {
                courseIndex < 0  -> toast("Please choose a course")
                yearIndex   < 0  -> toast("Please select an academic year")
                !bookConfirmed   -> toast("Please tap the book to confirm your selection")
                else -> proceedToLibrary()
            }
        }
    }

    private fun setInitialState() {
        tvHint.text               = "Select a course and year above to see your starter book."
        tvHint.visibility         = View.VISIBLE
        bookGridLayout.visibility = View.GONE
        btnRetry.visibility       = View.GONE
        tvRetryStatus.visibility  = View.GONE
    }

    // ── Proceed ───────────────────────────────────────────────────────────────
    private fun proceedToLibrary() {
        val book     = bookCatalog[currentKey()] ?: return
        val repoPath = SLOT_REPOS[currentKey()] ?: ""
        with(AppConstants) {
            getSharedPreferences(PREFS_APP, Context.MODE_PRIVATE).edit()
                .putString (KEY_SELECTED_BOOK,       book.title)
                .putString (KEY_SELECTED_AUTHOR,     book.author)
                .putString (KEY_SELECTED_DESC,       book.description)
                .putInt    (KEY_SELECTED_CHAPTERS,   book.chapters)
                .putString (KEY_SELECTED_COURSE,     book.course)
                .putString (KEY_SELECTED_YEAR,       book.year)
                .putString (KEY_SELECTED_BOOK_URL,   book.downloadUrl)
                .putString (KEY_SELECTED_REPO_PATH,  repoPath)
                .putBoolean(KEY_PROFILE_SETUP_DONE,  true)
                .apply()
        }
        startActivity(Intent(this, LibraryActivity::class.java))
        finish()
    }

    // ── Year chip visibility (BSACT = 1st & 2nd only) ────────────────────────
    private fun applyYearChipVisibility() {
        val isBsact = courseIndex == BSACT_INDEX
        val dp      = resources.displayMetrics.density
        yearChips.forEachIndexed { idx, chip ->
            val show = !isBsact || BSACT_YEARS.contains(allYearLabels[idx])
            chip.visibility = if (show) View.VISIBLE else View.GONE
            chip.isEnabled  = show
            if (show) resetCardStyle(chip, dp)
        }
        selectedYear = null
        yearIndex    = -1
    }

    // ── Network ───────────────────────────────────────────────────────────────
    private fun isOnline(): Boolean {
        val cm   = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    // ── Fetching ──────────────────────────────────────────────────────────────
    private fun norm(raw: String) = raw.trim()
        .replace("https://github.com/", "")
        .replace("https://raw.githubusercontent.com/", "")
        .removeSuffix("/main").removeSuffix("/")

    private fun fetchAllSlots() {
        setLoadingState(true)

        if (!isOnline()) {
            setLoadingState(false)
            showRetry("No internet connection.", "Check your connection and tap Retry.")
            return
        }

        // Deduplicate: group all slots by unique repo path so we hit GitHub only once per repo
        val repoToSlots = mutableMapOf<String, MutableList<String>>()
        SLOT_REPOS.forEach { (slot, repo) -> repoToSlots.getOrPut(repo) { mutableListOf() }.add(slot) }

        val uniqueRepos = repoToSlots.keys.toList()
        pendingCount.set(uniqueRepos.size)

        uniqueRepos.forEach { repo -> fetchRepo(repo, repoToSlots[repo]!!, attempt = 1) }
    }

    private fun fetchRepo(repo: String, slots: List<String>, attempt: Int) {
        val req = Request.Builder()
            .url("https://api.github.com/repos/$repo/contents/")
            .header("Accept",     "application/vnd.github.v3+json")
            .header("User-Agent", "404-app-android")
            .build()

        httpClient.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (attempt < MAX_RETRIES) {
                    mainHandler.postDelayed({ fetchRepo(repo, slots, attempt + 1) }, attempt * 2000L)
                } else {
                    runOnUiThread { if (pendingCount.decrementAndGet() == 0) onAllFetched() }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                runOnUiThread {
                    when {
                        response.code == 403 || response.code == 429 -> {
                            if (attempt < MAX_RETRIES) {
                                mainHandler.postDelayed({ fetchRepo(repo, slots, attempt + 1) }, 3500L)
                                return@runOnUiThread
                            }
                        }
                        response.isSuccessful && body != null -> parsePdfFromListing(body, repo, slots)
                        // 404 and other errors: fall through, decrement below
                    }
                    if (pendingCount.decrementAndGet() == 0) onAllFetched()
                }
            }
        })
    }

    private fun parsePdfFromListing(body: String, repo: String, slots: List<String>) {
        try {
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                if (obj.getString("type") == "file" && obj.getString("name").lowercase().endsWith(".pdf")) {
                    val fileName    = obj.getString("name")
                    val downloadUrl = obj.optString("download_url")
                        .ifBlank { "https://raw.githubusercontent.com/$repo/main/$fileName" }
                    slots.forEach { slot ->
                        if (!bookCatalog.containsKey(slot)) {
                            val (course, year) = slot.split("|")
                            bookCatalog[slot]  = makeBookData(fileName, repo, course, year, downloadUrl)
                        }
                    }
                    return // only first PDF per repo
                }
            }
        } catch (_: Exception) {}
    }

    private fun onAllFetched() {
        setLoadingState(false)
        btnContinue.isEnabled = true
        if (bookCatalog.isEmpty()) {
            showRetry("Could not load books from GitHub.", "Check your repo URLs in ChoosingPhaseActivity, then tap Retry.")
        } else {
            refreshBookCard()
        }
    }

    private fun makeBookData(fileName: String, repo: String, course: String, year: String, url: String): BookData {
        val clean = fileName.removeSuffix(".pdf")
            .replace(Regex("[_\\-]+"), " ")
            .split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }.trim()
        return BookData(clean, repo.substringBefore("/"), "PDF from GitHub · $repo", 0, course, year, url)
    }

    // ── Book card display ─────────────────────────────────────────────────────
    private fun currentKey() =
        if (courseIndex >= 0 && yearIndex >= 0) "${courseLabels[courseIndex]}|${allYearLabels[yearIndex]}" else ""

    private fun refreshBookCard() {
        btnRetry.visibility       = View.GONE
        tvRetryStatus.visibility  = View.GONE

        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.text               = if (courseIndex >= 0) "Now select your academic year." else "Select a course and year above to see your starter book."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val book = bookCatalog[currentKey()]
        if (book == null) {
            val loading = pendingCount.get() > 0
            tvHint.text               = if (loading) "Still loading… please wait." else "No PDF found for this course/year in the repository."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            if (!loading) showRetry(tvHint.text.toString(), "Check the repo for this slot and tap Retry.")
            return
        }

        tvBookTitle.text    = book.title
        tvBookAuthor.text   = "from ${book.author}"
        tvBookDesc.text     = book.description
        tvBookChapters.text = if (book.chapters > 0) "${book.chapters} Chapters" else "GitHub Repository"
        resetCardStyle(bookCard, resources.displayMetrics.density)
        bookConfirmed             = false
        tvHint.visibility         = View.GONE
        bookGridLayout.visibility = View.VISIBLE
    }

    // ── UI state helpers ──────────────────────────────────────────────────────
    private fun setLoadingState(loading: Boolean) {
        progressLoading.visibility = if (loading) View.VISIBLE else View.GONE
        if (loading) {
            tvHint.text              = "Loading books from GitHub…"
            tvHint.visibility        = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            btnRetry.visibility      = View.GONE
            tvRetryStatus.visibility = View.GONE
        }
    }

    private fun showRetry(hint: String, detail: String) {
        tvHint.text              = hint
        tvHint.visibility        = View.VISIBLE
        tvRetryStatus.text       = detail
        tvRetryStatus.visibility = View.VISIBLE
        btnRetry.visibility      = View.VISIBLE
    }

    private fun toggleCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val dp = resources.displayMetrics.density
        all.forEach { resetCardStyle(it, dp) }
        return if (clicked == current) null else {
            clicked.strokeWidth = (strokeSelected * dp).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintChildren(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun resetCardStyle(card: MaterialCardView, dp: Float) {
        card.strokeWidth = (strokeDefault * dp).toInt()
        card.strokeColor = Color.parseColor("#FFD6C5B4")
        card.setCardBackgroundColor(colorDefault)
        tintChildren(card, "#FF2A2A2A")
    }

    private fun tintChildren(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        when (view) {
            is TextView              -> view.setTextColor(color)
            is android.view.ViewGroup -> (0 until view.childCount).forEach { tintChildren(view.getChildAt(it), hex) }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
