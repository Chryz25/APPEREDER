package com.example.a404

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.edit
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class PdfViewerActivity : ComponentActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar:  ProgressBar
    private lateinit var tvTitle:      TextView
    private lateinit var tvZoomLevel:  TextView

    private var pdfRenderer:          PdfRenderer?          = null
    private var parcelFileDescriptor: ParcelFileDescriptor? = null

    private var pdfUrl   = ""
    private var fileName = "document.pdf"
    private var isLocal  = false

    // Single shared OkHttpClient — created once, reused for both fetch and download
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)  // PDFs can be large
            .retryOnConnectionFailure(true)
            .build()
    }

    // ── Zoom ──────────────────────────────────────────────────────────────────
    private fun visibleZoomView(): ZoomableImageView? {
        val lm  = recyclerView.layoutManager as? LinearLayoutManager ?: return null
        val pos = lm.findFirstCompletelyVisibleItemPosition()
            .takeIf { it != RecyclerView.NO_ID }
            ?: lm.findFirstVisibleItemPosition()
        if (pos == RecyclerView.NO_POSITION) return null
        return recyclerView.findViewHolderForAdapterPosition(pos)
            ?.itemView?.findViewById(R.id.pdf_page_image)
    }

    private fun updateZoomLabel() {
        tvZoomLevel.text = "${(visibleZoomView()?.currentScale?.times(100))?.toInt() ?: 100}%"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_pdf_viewer)

        pdfUrl  = intent.getStringExtra(AppConstants.EXTRA_PDF_URL)  ?: ""
        isLocal = intent.getBooleanExtra(AppConstants.EXTRA_IS_LOCAL, false)

        if (pdfUrl.isEmpty()) { toast("No PDF path or URL provided"); finish(); return }

        fileName = Uri.decode(pdfUrl.substringAfterLast("/"))
        if (!fileName.lowercase().endsWith(".pdf")) fileName += ".pdf"

        recyclerView = findViewById(R.id.pdf_recycler_view)
        progressBar  = findViewById(R.id.progress_bar)
        tvTitle      = findViewById(R.id.tv_title)
        tvZoomLevel  = findViewById(R.id.tv_zoom_level)
        recyclerView.layoutManager = LinearLayoutManager(this)

        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        val btnDownload = findViewById<ImageView>(R.id.btn_download)
        if (isLocal) btnDownload.visibility = View.GONE
        else         btnDownload.setOnClickListener { downloadToStorage() }

        // Zoom controls
        findViewById<View>(R.id.btn_zoom_in).setOnClickListener    { visibleZoomView()?.zoomIn();    updateZoomLabel() }
        findViewById<View>(R.id.btn_zoom_out).setOnClickListener   { visibleZoomView()?.zoomOut();   updateZoomLabel() }
        findViewById<View>(R.id.btn_zoom_reset).setOnClickListener { visibleZoomView()?.resetZoom(); tvZoomLevel.text = "100%" }

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, s: Int) { if (s == RecyclerView.SCROLL_STATE_IDLE) updateZoomLabel() }
        })

        if (!isLocal) recordBrowseHistory(fileName)
        if (isLocal)  displayPdf(File(pdfUrl)) else fetchPdf()
    }

    // ── Fetch ─────────────────────────────────────────────────────────────────
    private fun fetchPdf() {
        progressBar.visibility = View.VISIBLE
        httpClient.newCall(Request.Builder().url(pdfUrl).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { if (!isFinishing) { progressBar.visibility = View.GONE; toast("Failed to load: ${e.message}") } }
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread { if (!isFinishing) { progressBar.visibility = View.GONE; toast("HTTP ${response.code}") } }
                    return
                }
                val file = File(cacheDir, "temp_render.pdf")
                try {
                    body.byteStream().use { i -> FileOutputStream(file).use { o -> i.copyTo(o) } }
                    runOnUiThread { if (!isFinishing) displayPdf(file) }
                } catch (e: Exception) {
                    runOnUiThread { if (!isFinishing) { progressBar.visibility = View.GONE; toast("Load error: ${e.message}") } }
                }
            }
        })
    }

    private fun displayPdf(file: File) {
        progressBar.visibility = View.GONE
        if (!file.exists()) { toast("File not found"); return }
        try {
            parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer          = PdfRenderer(parcelFileDescriptor!!)
            recyclerView.adapter = PdfPageAdapter(pdfRenderer!!)
            tvTitle.text         = fileName
            tvZoomLevel.text     = "100%"
        } catch (e: Exception) { toast("Render error: ${e.message}") }
    }

    // ── Download ──────────────────────────────────────────────────────────────
    private fun downloadToStorage() {
        toast("Downloading…")
        httpClient.newCall(Request.Builder().url(pdfUrl).build()).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { if (!isFinishing) toast("Download failed: ${e.message}") }
            }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread { if (!isFinishing) toast("Download error: ${response.code}") }
                    return
                }
                val tmp = File(cacheDir, "dl_${System.currentTimeMillis()}.pdf")
                try {
                    body.byteStream().use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o) } }
                    saveToStorage(tmp)
                    tmp.delete()
                } catch (e: Exception) {
                    runOnUiThread { if (!isFinishing) toast("Save error: ${e.message}") }
                }
            }
        })
    }

    private fun saveToStorage(src: File) {
        try {
            val dir  = File(filesDir, "Sources").also { if (!it.exists()) it.mkdirs() }
            val book = matchCatalogBook(fileName)
            val name = if (book != null) "${book.title}.pdf" else fileName
            src.inputStream().use { i -> FileOutputStream(File(dir, name)).use { o -> i.copyTo(o) } }

            val prefs = getSharedPreferences(AppConstants.PREFS_APP, Context.MODE_PRIVATE)
            val list  = JSONArray(prefs.getString(AppConstants.KEY_DOWNLOADED_BOOKS, "[]") ?: "[]")
            val obj   = JSONObject().apply {
                if (book != null) {
                    put("title", book.title); put("author", book.author); put("description", book.description)
                    put("chapters", book.chapters); put("course", book.course); put("year", book.year)
                } else {
                    put("title", name.removeSuffix(".pdf")); put("author", "Downloaded Source")
                    put("description", "A manually downloaded PDF."); put("chapters", 1)
                    put("course", "Manual Download"); put("year", "")
                }
            }
            val title = obj.getString("title")
            var idx = -1
            for (i in 0 until list.length()) if (list.getJSONObject(i).getString("title") == title) { idx = i; break }
            if (idx >= 0) list.put(idx, obj) else list.put(obj)
            prefs.edit { putString(AppConstants.KEY_DOWNLOADED_BOOKS, list.toString()) }

            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Download Complete!")
                    .setMessage("\"$title\" saved and available offline.")
                    .setPositiveButton("Go to Downloads") { _, _ ->
                        startActivity(Intent(this, DownloadActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_CLEAR_TOP })
                        finish()
                    }
                    .setNegativeButton("Stay Here", null).show()
            }
        } catch (e: Exception) {
            runOnUiThread { toast("Save failed: ${e.message}") }
        }
    }

    // ── History ───────────────────────────────────────────────────────────────
    private fun recordBrowseHistory(displayName: String) {
        val prefs = getSharedPreferences(AppConstants.PREFS_APP, Context.MODE_PRIVATE)
        val arr   = JSONArray(prefs.getString(AppConstants.KEY_BROWSE_HISTORY, "[]") ?: "[]")
        val entry = JSONObject().apply { put("name", displayName); put("url", pdfUrl); put("timestamp", System.currentTimeMillis()) }
        val deduped = JSONArray().apply { put(entry) }
        for (i in 0 until arr.length()) arr.getJSONObject(i).takeIf { it.optString("url") != pdfUrl }?.let { deduped.put(it) }
        prefs.edit {
            putString(AppConstants.KEY_BROWSE_HISTORY, deduped.toString())
            putString(AppConstants.KEY_LAST_READ_BOOK,    displayName.removeSuffix(".pdf"))
            putString(AppConstants.KEY_LAST_READ_CHAPTER, "Browse · Extension")
            putString(AppConstants.KEY_LAST_READ_COURSE,  "Browse Extension")
            putString(AppConstants.KEY_LAST_READ_YEAR,    "")
        }
    }

    // ── Catalog matching ──────────────────────────────────────────────────────
    private fun matchCatalogBook(name: String): BookData? {
        fun norm(s: String) = Uri.decode(s).lowercase().replace("&","and").replace("+", " ").replace(Regex("[^a-z0-9]"), "")
        val n = norm(name)
        return STATIC_CATALOG.find { norm(it.title).let { t -> n.contains(t) || t.contains(n) } }
    }

    override fun onDestroy() {
        try { pdfRenderer?.close(); parcelFileDescriptor?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        // Static catalog — only referenced here and in GroqQuizActivity
        val STATIC_CATALOG = listOf(
            BookData("Foundations of Computing",       "James R. Hawkins", "Entry-level guide to computational thinking, binary systems, and algorithms.", 10, "BS Computer Science", "1st Year"),
            BookData("Data Structures & Algorithms",   "Maria Santos",     "Arrays, linked lists, trees, sorting, and complexity analysis.",                14, "BS Computer Science", "2nd Year"),
            BookData("Operating Systems Concepts",     "Dr. Lena Park",    "Process management, memory models, file systems, and concurrency.",             16, "BS Computer Science", "3rd Year"),
            BookData("Software Engineering Principles","Carlos Mendez",    "Agile, design patterns, testing strategies, and large-scale system design.",    12, "BS Computer Science", "4th Year"),
            BookData("Introduction to IT Systems",     "Grace Villanueva", "Hardware, software, networking basics, and IT support fundamentals.",           10, "BS Information Technology", "1st Year"),
            BookData("Database Management Systems",    "Prof. Alan Reyes", "Relational models, SQL, normalization, and database administration.",           13, "BS Information Technology", "2nd Year"),
            BookData("Network Administration",         "Sandra Kim",       "TCP/IP, LAN/WAN, security policies, and cloud infrastructure.",                 15, "BS Information Technology", "3rd Year"),
            BookData("IT Project Management",          "Roberto Cruz",     "Project planning, risk management, and IT governance.",                         11, "BS Information Technology", "4th Year"),
            BookData("Digital Media Foundations",      "Nina Torres",      "Digital images, audio, video, and media production tools.",                      9, "BS Multimedia Computing", "1st Year"),
            BookData("2D Animation & Design",          "Kenji Watanabe",   "Animation principles, storyboarding, vector design, and Adobe workflows.",       12, "BS Multimedia Computing", "2nd Year"),
            BookData("Interactive Media Development",  "Alicia Fernandez", "HTML5 Canvas, JavaScript, and game-design patterns.",                           14, "BS Multimedia Computing", "3rd Year"),
            BookData("3D Modeling & Visualization",    "Dr. Marcus Webb",  "3D asset creation, rigging, rendering pipelines.",                              13, "BS Multimedia Computing", "4th Year"),
            BookData("Computer Hardware Essentials",   "Dante Reyes",      "PC components, assembly, troubleshooting, and electronics basics.",             10, "BS Applied Computer Technology", "1st Year"),
            BookData("Embedded Systems Programming",   "Prof. Erika Lim",  "Microcontroller programming, GPIO, sensors, and real-time systems.",            13, "BS Applied Computer Technology", "2nd Year"),
            BookData("Industrial Automation & IoT",    "Samuel Okafor",    "PLC programming, IoT protocols, MQTT, and cloud integration.",                  14, "BS Applied Computer Technology", "3rd Year"),
            BookData("Applied Systems Capstone",       "Dr. Yvonne Castillo","End-to-end applied project: design, prototype, test, and deploy.",             8, "BS Applied Computer Technology", "4th Year")
        )
    }
}
