package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

class BrowseActivity : ComponentActivity() {

    // OkHttpClient with timeouts — same pattern as ChoosingPhaseActivity
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private val allBookItems = mutableListOf<Pair<MaterialCardView, String>>()
    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.browse_sources_1)

        // Hamburger
        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss()
            else hamburgerPopup = showHamburgerMenu(anchor)
        }

        // Search
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            imm().showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            showAllBooks()
            imm().hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filterBooks(s?.toString() ?: "", noResults) }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { imm().hideSoftInputFromWindow(searchInput.windowToken, 0); true } else false
        }

        loadRepos()
        setupNavigation()
    }

    // Repo path comes solely from SharedPreferences — set in ChoosingPhaseActivity
    private fun resolvedRepos(): List<String> {
        val path = getSharedPreferences(AppConstants.PREFS_APP, Context.MODE_PRIVATE)
            .getString(AppConstants.KEY_SELECTED_REPO_PATH, "") ?: ""
        return if (path.isNotBlank()) listOf(norm(path)) else emptyList()
    }

    private fun norm(raw: String) = raw.trim()
        .replace("https://github.com/", "")
        .replace("https://raw.githubusercontent.com/", "")
        .removeSuffix("/main").removeSuffix("/")

    private fun loadRepos() {
        val loading   = findViewById<ProgressBar>(R.id.books_loading)
        val container = findViewById<LinearLayout>(R.id.books_list_container)
        val emptyView = findViewById<View>(R.id.empty_view)

        loading.visibility   = View.VISIBLE
        emptyView.visibility = View.GONE
        container.removeAllViews()
        allBookItems.clear()

        val repos = resolvedRepos()
        if (repos.isEmpty()) { loading.visibility = View.GONE; emptyView.visibility = View.VISIBLE; return }

        var pending = repos.size

        repos.forEach { repo ->
            httpClient.newCall(
                Request.Builder()
                    .url("https://api.github.com/repos/$repo/contents/")
                    .header("Accept",     "application/vnd.github.v3+json")
                    .header("User-Agent", "404-app-android")
                    .build()
            ).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread { if (--pending == 0) done(loading, emptyView, container) }
                }
                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    runOnUiThread {
                        if (response.isSuccessful && body != null) {
                            try {
                                val arr = JSONArray(body)
                                for (i in 0 until arr.length()) {
                                    val obj = arr.getJSONObject(i)
                                    if (obj.getString("type") == "file" && obj.getString("name").lowercase().endsWith(".pdf")) {
                                        val url = obj.optString("download_url")
                                            .ifBlank { "https://raw.githubusercontent.com/$repo/main/${obj.getString("name")}" }
                                        addCard(container, obj.getString("name"), repo, url)
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        if (--pending == 0) done(loading, emptyView, container)
                    }
                }
            })
        }
    }

    private fun done(loading: ProgressBar, emptyView: View, container: LinearLayout) {
        loading.visibility   = View.GONE
        emptyView.visibility = if (allBookItems.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun addCard(container: LinearLayout, fileName: String, repo: String, downloadUrl: String) {
        val displayName = fileName.removeSuffix(".pdf")
        val dp = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = (10 * dp).toInt() }
            radius = 12 * dp; cardElevation = 1 * dp; isClickable = true; isFocusable = true
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
        }
        val iconBg = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams((44 * dp).toInt(), (44 * dp).toInt()).also { it.marginEnd = (14 * dp).toInt() }
            gravity = Gravity.CENTER; setBackgroundColor(0xFFEDE7F6.toInt())
        }
        iconBg.addView(TextView(this).apply {
            text = "PDF"; setTextColor(0xFF6A1B9A.toInt()); setTypeface(null, Typeface.BOLD); textSize = 10f; gravity = Gravity.CENTER
        })
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textCol.addView(TextView(this).apply {
            text = displayName; setTextColor(0xFF1A1A1A.toInt()); textSize = 15f
            setTypeface(null, Typeface.BOLD); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        textCol.addView(TextView(this).apply {
            text = repo; setTextColor(0xFF888888.toInt()); textSize = 12f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = (2 * dp).toInt() }
        })
        val viewBtn = Button(this).apply {
            text = "VIEW"; setTextColor(0xFF6A1B9A.toInt()); textSize = 12f
            @Suppress("DEPRECATION") background = getDrawable(R.drawable.bg_rounded_browse_extension_1)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (36 * dp).toInt())
                .also { it.marginStart = (8 * dp).toInt() }
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), 0); isAllCaps = true
            setOnClickListener { openPdf(downloadUrl) }
        }
        row.addView(iconBg); row.addView(textCol); row.addView(viewBtn)
        card.addView(row)
        card.setOnClickListener { openPdf(downloadUrl) }
        container.addView(card)
        allBookItems.add(card to "$displayName $repo")
    }

    private fun openPdf(url: String) {
        startActivity(Intent(this, PdfViewerActivity::class.java).apply {
            putExtra(AppConstants.EXTRA_PDF_URL,  url)
            putExtra(AppConstants.EXTRA_IS_LOCAL, false)
        })
    }

    private fun showAllBooks() {
        allBookItems.forEach { (c, _) -> c.visibility = View.VISIBLE }
        findViewById<View>(R.id.no_results_view).visibility = View.GONE
    }

    private fun filterBooks(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var any = false
        allBookItems.forEach { (c, t) ->
            val m = q.isEmpty() || t.lowercase().contains(q)
            c.visibility = if (m) View.VISIBLE else View.GONE
            if (m) any = true
        }
        noResults.visibility = if (!any && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showHamburgerMenu(anchor: View): PopupWindow {
        val v  = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val pw = PopupWindow(v, (200 * dp).toInt(), -2, true).apply {
            elevation = 12 * dp; animationStyle = R.style.HamburgerDropdownAnimation; isOutsideTouchable = true
        }
        v.findViewById<View>(R.id.menu_item_guide).setOnClickListener    { pw.dismiss(); startActivity(Intent(this, GuideActivity::class.java)) }
        v.findViewById<View>(R.id.menu_item_about_us).setOnClickListener { pw.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java)) }
        val loc = IntArray(2).also { anchor.getLocationInWindow(it) }
        pw.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        return pw
    }

    private fun setupNavigation() {
        findViewById<View>(R.id.nav_library)?.setOnClickListener  { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<View>(R.id.nav_history)?.setOnClickListener  { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.nav_download)?.setOnClickListener { startActivity(Intent(this, DownloadActivity::class.java)) }
    }

    private fun imm() = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
}
