package com.example.a404

/**
 * App-wide shared constants so every Activity reads from one place.
 * No more scattered magic strings across files.
 */
object AppConstants {

    // ── SharedPreferences file names ──────────────────────────────────────
    const val PREFS_APP       = "AppPrefs"
    const val PREFS_BOOKMARKS = "Bookmarks"

    // ── Selected book keys ────────────────────────────────────────────────
    const val KEY_SELECTED_BOOK        = "SELECTED_BOOK"
    const val KEY_SELECTED_AUTHOR      = "SELECTED_AUTHOR"
    const val KEY_SELECTED_DESC        = "SELECTED_DESC"
    const val KEY_SELECTED_CHAPTERS    = "SELECTED_CHAPTERS"
    const val KEY_SELECTED_COURSE      = "SELECTED_COURSE"
    const val KEY_SELECTED_YEAR        = "SELECTED_YEAR"
    const val KEY_SELECTED_BOOK_URL    = "SELECTED_BOOK_URL"
    const val KEY_SELECTED_REPO_PATH   = "SELECTED_REPO_PATH"
    const val KEY_PROFILE_SETUP_DONE   = "PROFILE_SETUP_DONE"

    // ── Last-read keys ────────────────────────────────────────────────────
    const val KEY_LAST_READ_BOOK       = "LAST_READ_BOOK"
    const val KEY_LAST_READ_AUTHOR     = "LAST_READ_AUTHOR"
    const val KEY_LAST_READ_CHAPTER    = "LAST_READ_CHAPTER"
    const val KEY_LAST_READ_COURSE     = "LAST_READ_COURSE"
    const val KEY_LAST_READ_YEAR       = "LAST_READ_YEAR"

    // ── Download & browse history keys ────────────────────────────────────
    const val KEY_DOWNLOADED_BOOKS     = "DOWNLOADED_BOOKS_LIST"
    const val KEY_BROWSE_HISTORY       = "BROWSE_HISTORY"

    // ── Intent extras ─────────────────────────────────────────────────────
    const val EXTRA_BOOK_TITLE   = "BOOK_TITLE"
    const val EXTRA_BOOK_AUTHOR  = "BOOK_AUTHOR"
    const val EXTRA_BOOK_DESC    = "BOOK_DESC"
    const val EXTRA_BOOK_COURSE  = "BOOK_COURSE"
    const val EXTRA_BOOK_YEAR    = "BOOK_YEAR"
    const val EXTRA_BOOK_URL     = "BOOK_URL"
    const val EXTRA_PDF_URL      = "PDF_URL"
    const val EXTRA_IS_LOCAL     = "IS_LOCAL"
    const val EXTRA_CHAPTER_TITLE   = "CHAPTER_TITLE"
    const val EXTRA_CHAPTER_INDEX   = "CHAPTER_INDEX"
    const val EXTRA_TOTAL_CHAPTERS  = "TOTAL_CHAPTERS"
}
