package com.example.a404

import android.content.Context
import android.graphics.Matrix
import android.graphics.PointF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView

/**
 * An ImageView that supports:
 *  • Pinch-to-zoom  (ScaleGestureDetector)
 *  • Pan / drag while zoomed in
 *  • Double-tap to reset to fit-screen
 *
 * Works inside a RecyclerView — vertical scroll is delegated to the parent
 * when the image is not zoomed, preventing scroll conflicts.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : AppCompatImageView(context, attrs, defStyle) {

    private val matrix       = Matrix()
    private val savedMatrix  = Matrix()

    private var mode         = NONE
    private val last         = PointF()
    private val start        = PointF()

    private var minScale     = 1f
    private val maxScale     = 6f
    private var currentScale = 1f

    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            resetZoom()
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        imageMatrix = matrix
    }

    companion object {
        private const val NONE  = 0
        private const val DRAG  = 1
        private const val ZOOM  = 2
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        resetZoom()
    }

    /** Fit the bitmap inside the view and centre it. */
    fun resetZoom() {
        val d = drawable ?: return
        val bw = d.intrinsicWidth.toFloat()
        val bh = d.intrinsicHeight.toFloat()
        if (bw <= 0 || bh <= 0 || width <= 0 || height <= 0) return

        val scale = width / bw          // fit to width
        minScale     = scale
        currentScale = scale

        matrix.reset()
        matrix.postScale(scale, scale)
        // Centre vertically if the scaled height < view height
        val scaledH = bh * scale
        val dy = if (scaledH < height) (height - scaledH) / 2f else 0f
        matrix.postTranslate(0f, dy)

        imageMatrix = matrix
        mode = NONE
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                savedMatrix.set(matrix)
                last.set(event.x, event.y)
                start.set(last)
                mode = DRAG
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                savedMatrix.set(matrix)
                mode = ZOOM
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == DRAG && currentScale > minScale + 0.01f) {
                    // Pan while zoomed
                    matrix.set(savedMatrix)
                    val dx = event.x - start.x
                    val dy = event.y - start.y
                    matrix.postTranslate(dx, dy)
                    clampMatrix()
                    imageMatrix = matrix
                    // Don't consume vertical scrolls when image fits — let RecyclerView scroll
                    parent.requestDisallowInterceptTouchEvent(true)
                } else if (mode == DRAG) {
                    // Not zoomed — allow RecyclerView to scroll vertically
                    parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                mode = DRAG
                savedMatrix.set(matrix)
                last.set(event.x, event.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = NONE
                parent.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    // ── Scale gesture ─────────────────────────────────────────────────────────
    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val scaleFactor = detector.scaleFactor
            val newScale    = currentScale * scaleFactor

            if (newScale in minScale..maxScale) {
                currentScale = newScale
                matrix.postScale(scaleFactor, scaleFactor, detector.focusX, detector.focusY)
                clampMatrix()
                imageMatrix = matrix
            }
            return true
        }
    }

    // ── Clamp translation so the image never drifts entirely off screen ───────
    private fun clampMatrix() {
        val d  = drawable ?: return
        val bw = d.intrinsicWidth.toFloat()
        val bh = d.intrinsicHeight.toFloat()

        val values = FloatArray(9)
        matrix.getValues(values)

        val scaleX = values[Matrix.MSCALE_X]
        val scaleY = values[Matrix.MSCALE_Y]
        var transX = values[Matrix.MTRANS_X]
        var transY = values[Matrix.MTRANS_Y]

        val scaledW = bw * scaleX
        val scaledH = bh * scaleY

        // Horizontal clamp
        transX = when {
            scaledW <= width  -> (width  - scaledW) / 2f   // centre if smaller
            transX > 0f       -> 0f
            transX < width - scaledW -> width - scaledW
            else              -> transX
        }
        // Vertical clamp
        transY = when {
            scaledH <= height -> (height - scaledH) / 2f   // centre if smaller
            transY > 0f       -> 0f
            transY < height - scaledH -> height - scaledH
            else              -> transY
        }

        values[Matrix.MTRANS_X] = transX
        values[Matrix.MTRANS_Y] = transY
        matrix.setValues(values)
    }
}
