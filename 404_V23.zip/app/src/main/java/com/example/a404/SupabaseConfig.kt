package com.example.a404

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║               SUPABASE CONFIGURATION                             ║
 * ║  Replace the placeholders below with your actual credentials.    ║
 * ║                                                                  ║
 * ║  How to find your credentials:                                   ║
 * ║   1. Go to https://supabase.com → open your project             ║
 * ║   2. Navigate to Settings → API                                  ║
 * ║   3. "Project URL"       → paste as SUPABASE_URL                ║
 * ║   4. "anon / public" key → paste as SUPABASE_ANON_KEY           ║
 * ║                                                                  ║
 * ║  Storage bucket:                                                  ║
 * ║   Create a bucket named "books" in Storage → New Bucket          ║
 * ║   Set it to PUBLIC so PDFs can be streamed without auth.         ║
 * ║                                                                  ║
 * ║  Database table – run this SQL in the SQL Editor:                ║
 * ║   See SUPABASE_SETUP.md in the project root for full SQL.        ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */
object SupabaseConfig {

    // ── Step 1: Paste your Supabase project URL here ──────────────────────────
    const val SUPABASE_URL      = "https://YOUR_PROJECT_REF.supabase.co"

    // ── Step 2: Paste your anon/public key here ───────────────────────────────
    const val SUPABASE_ANON_KEY = "YOUR_ANON_PUBLIC_KEY"

    // ── Step 3: Keep this as "books" (must match your bucket name) ────────────
    const val BUCKET_NAME       = "books"
}
