package com.example.a404

import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

// ── Supabase book model ────────────────────────────────────────────────────────
data class SupabaseBook(
    val id:          String,
    val title:       String,
    val author:      String,
    val description: String,
    val course:      String,
    val year:        String,
    val filePath:    String,   // path inside the storage bucket
    val downloadUrl: String    // full public HTTPS URL ready to stream/download
)

/**
 * Single-responsibility repository that wraps all Supabase REST and Storage
 * calls used by the app.
 *
 * All callbacks are delivered on the OkHttp background thread.
 * Callers must switch to the UI thread themselves (runOnUiThread { … }).
 *
 * Storage bucket layout expected:
 *   books/
 *     BS_Computer_Science/
 *       1st_Year/
 *         DataStructures.pdf
 *         Algorithms.pdf
 *       2nd_Year/
 *         OperatingSystems.pdf
 *     BS_Information_Technology/
 *       1st_Year/
 *         ProgrammingFundamentals.pdf
 *     …
 *
 * Database table `books` columns:
 *   id          uuid  (auto)
 *   title       text  – display name shown in the app
 *   author      text  – author / uploader name (can be blank)
 *   description text  – short blurb (can be blank)
 *   course      text  – must match exactly, e.g. "BS Computer Science"
 *   year        text  – must match exactly, e.g. "1st Year"
 *   file_path   text  – bucket-relative path, e.g. "BS_Computer_Science/1st_Year/DataStructures.pdf"
 *   created_at  timestamptz (auto)
 */
object SupabaseRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    // ── URL helpers ───────────────────────────────────────────────────────────

    /** Builds the publicly accessible URL for a file in the 'books' bucket. */
    fun buildPublicUrl(filePath: String): String =
        "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/${SupabaseConfig.BUCKET_NAME}/$filePath"

    // ── Core request builder ──────────────────────────────────────────────────

    private fun buildRequest(url: String): Request =
        Request.Builder()
            .url(url)
            .header("apikey",        SupabaseConfig.SUPABASE_ANON_KEY)
            .header("Authorization", "Bearer ${SupabaseConfig.SUPABASE_ANON_KEY}")
            .header("Content-Type",  "application/json")
            .header("Accept",        "application/json")
            .build()

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Fetch all books for a specific course + year combination.
     * Maps to: SELECT * FROM books WHERE course = ? AND year = ?
     */
    fun fetchBooksForSlot(
        course:    String,
        year:      String,
        onSuccess: (List<SupabaseBook>) -> Unit,
        onError:   (String) -> Unit
    ) {
        val url = buildTableUrl(
            filters = "course=eq.${course.urlEncode()}&year=eq.${year.urlEncode()}",
            select  = "id,title,author,description,course,year,file_path",
            order   = "created_at.asc"
        )
        executeRequest(url, course, year, onSuccess, onError)
    }

    /**
     * Fetch ALL books across every course and year.
     * Used by BrowseActivity to show the full catalogue.
     */
    fun fetchAllBooks(
        onSuccess: (List<SupabaseBook>) -> Unit,
        onError:   (String) -> Unit
    ) {
        val url = buildTableUrl(
            select = "id,title,author,description,course,year,file_path",
            order  = "course.asc,year.asc,title.asc"
        )
        executeRequest(url, "", "", onSuccess, onError)
    }

    /**
     * Fetch books filtered by the user's selected course only (all years).
     * Useful for future extensions.
     */
    fun fetchBooksForCourse(
        course:    String,
        onSuccess: (List<SupabaseBook>) -> Unit,
        onError:   (String) -> Unit
    ) {
        val url = buildTableUrl(
            filters = "course=eq.${course.urlEncode()}",
            select  = "id,title,author,description,course,year,file_path",
            order   = "year.asc,title.asc"
        )
        executeRequest(url, course, "", onSuccess, onError)
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private fun buildTableUrl(
        filters: String = "",
        select:  String = "*",
        order:   String = ""
    ): String {
        val base = "${SupabaseConfig.SUPABASE_URL}/rest/v1/books?select=$select"
        val f    = if (filters.isNotBlank()) "&$filters" else ""
        val o    = if (order.isNotBlank()) "&order=$order" else ""
        return "$base$f$o"
    }

    private fun executeRequest(
        url:        String,
        course:     String,
        year:       String,
        onSuccess:  (List<SupabaseBook>) -> Unit,
        onError:    (String) -> Unit
    ) {
        client.newCall(buildRequest(url)).enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                onError("Network error: ${e.localizedMessage ?: "Unknown"}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = try { response.body?.string() } catch (_: Exception) { null }

                if (!response.isSuccessful || body == null) {
                    onError("Server error ${response.code}: ${body ?: "empty response"}")
                    return
                }

                try {
                    val arr   = JSONArray(body)
                    val books = mutableListOf<SupabaseBook>()

                    for (i in 0 until arr.length()) {
                        val obj      = arr.getJSONObject(i)
                        val filePath = obj.optString("file_path", "")
                        val rawTitle = obj.optString("title", "").ifBlank {
                            filePath.prettyFileName()
                        }
                        books.add(
                            SupabaseBook(
                                id          = obj.optString("id", ""),
                                title       = rawTitle,
                                author      = obj.optString("author", ""),
                                description = obj.optString("description", ""),
                                course      = obj.optString("course", course),
                                year        = obj.optString("year", year),
                                filePath    = filePath,
                                downloadUrl = buildPublicUrl(filePath)
                            )
                        )
                    }
                    onSuccess(books)
                } catch (e: Exception) {
                    onError("Parse error: ${e.localizedMessage}")
                }
            }
        })
    }

    // ── String extensions ─────────────────────────────────────────────────────

    /** URL-encodes a string, converting spaces to %20 (not +). */
    private fun String.urlEncode(): String =
        java.net.URLEncoder.encode(this, "UTF-8").replace("+", "%20")

    /**
     * Converts a storage file path to a pretty display title.
     * e.g. "BSCS/1st_Year/data_structures_v2.pdf" → "Data Structures V2"
     */
    private fun String.prettyFileName(): String =
        substringAfterLast("/")
            .removeSuffix(".pdf")
            .replace(Regex("[_\\-]+"), " ")
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            .trim()
}
