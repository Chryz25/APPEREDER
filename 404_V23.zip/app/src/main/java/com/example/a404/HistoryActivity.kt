package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import android.app.AlertDialog
import androidx.core.content.edit
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

/**
 * History screen – shows recently read books AND a full list of every PDF
 * opened from the Browse tab, each clickable to re-open instantly.
 *
 * V17 upgrades:
 *  1. Layout now has `history_dynamic_container` ID — Browse-PDF cards always
 *     render in the correct parent (was silently no-op in V16).
 *  2. Dedicated pdf_history_container LinearLayout holds all PDF entries;
 *     section header + empty-state label are properly toggled.
 *  3. Book cards (item_1/item_2) are hidden when there is no data to prevent
 *     blank ghost cards; a friendly label replaces them.
 *  4. "Clear PDF History" button with confirmation dialog.
 *  5. Search spans both book cards and all PDF history cards.
 *  6. onResume() refreshes both sections (new PDFs appear without restarting).
 *  7. hamburgerPopup dismissed in onPause (WindowLeaked prevention).
 *  8. nav_history is a no-op (self-guard).
 */
class HistoryActivity : ComponentActivity() {

    private val historyItems   = mutableListOf<Pair<View, String>>()
    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.history___1)

        buildBookSection()
        buildPdfHistorySection()
        setupSearch()
        setupHamburger()
        setupNavigation()
    }

    override fun onResume() {
        super.onResume()
        historyItems.clear()
        buildBookSection()
        buildPdfHistorySection()
    }

    override fun onPause() {
        super.onPause()
        hamburgerPopup?.dismiss()
    }

    // ── Recently Read Books section ───────────────────────────────────────────

    private fun buildBookSection() {
        val prefs       = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val lastBook    = prefs.getString("LAST_READ_BOOK",    null)
        val lastChapter = prefs.getString("LAST_READ_CHAPTER", null)
        val lastCourse  = prefs.getString("LAST_READ_COURSE",  null)
        val selBook     = prefs.getString("SELECTED_BOOK",     null)
        val selCourse   = prefs.getString("SELECTED_COURSE",   null)
        val selYear     = prefs.getString("SELECTED_YEAR",     null)

        val item1     = findViewById<MaterialCardView>(R.id.history_item_1)
        val item2     = findViewById<MaterialCardView>(R.id.history_item_2)
        val tvNoBooks = findViewById<TextView>(R.id.tv_no_books)

        val fromBrowse = lastCourse == "Browse Extension"
        val showItem1  = !lastBook.isNullOrBlank() && !fromBrowse
        val showItem2  = !selBook.isNullOrBlank() && selBook != lastBook

        if (showItem1) {
            val texts = findTextViews(item1)
            if (texts.size >= 2) {
                texts[0].text = lastBook!!
                val chLabel = lastChapter?.substringBefore(":") ?: "Last chapter"
                val crLabel = if (!lastCourse.isNullOrBlank()) " · $lastCourse" else ""
                texts[1].text = "$chLabel · Just now$crLabel"
            }
            item1.visibility = View.VISIBLE
            item1.setOnClickListener {
                startActivity(Intent(this, LibraryDetailsActivity::class.java)
                    .putExtra("BOOK_TITLE", lastBook))
            }
            historyItems.add(Pair(item1, buildSearchText(item1)))
        } else {
            item1.visibility = View.GONE
        }

        if (showItem2) {
            val texts = findTextViews(item2)
            if (texts.size >= 2) {
                texts[0].text = selBook!!
                val yearLabel = if (!selYear.isNullOrBlank()) " · $selYear" else ""
                val crLabel   = if (!selCourse.isNullOrBlank()) " · $selCourse" else ""
                texts[1].text = "Selected book$yearLabel$crLabel"
            }
            item2.visibility = View.VISIBLE
            item2.setOnClickListener {
                startActivity(Intent(this, LibraryDetailsActivity::class.java)
                    .putExtra("BOOK_TITLE", selBook))
            }
            historyItems.add(Pair(item2, buildSearchText(item2)))
        } else {
            item2.visibility = View.GONE
        }

        tvNoBooks.visibility = if (!showItem1 && !showItem2) View.VISIBLE else View.GONE
    }

    // ── PDF Browsing History section ──────────────────────────────────────────

    private fun buildPdfHistorySection() {
        val pdfContainer = findViewById<LinearLayout>(R.id.pdf_history_container) ?: return
        val tvNoPdf      = findViewById<TextView>(R.id.tv_no_pdf_history)
        val btnClear     = findViewById<TextView>(R.id.btn_clear_history)

        pdfContainer.removeAllViews()

        val prefs       = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val browseJson  = prefs.getString("BROWSE_HISTORY", "[]") ?: "[]"
        val browseArr   = try { JSONArray(browseJson) } catch (_: Exception) { JSONArray() }

        if (browseArr.length() == 0) {
            tvNoPdf.visibility  = View.VISIBLE
            btnClear.visibility = View.GONE
            return
        }

        tvNoPdf.visibility  = View.GONE
        btnClear.visibility = View.VISIBLE

        val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())

        for (i in 0 until browseArr.length()) {
            val entry       = browseArr.getJSONObject(i)
            val rawName     = entry.optString("name",      "PDF Document")
            val url         = entry.optString("url",       "")
            val ts          = entry.optLong  ("timestamp", 0L)
            val displayName = rawName.removeSuffix(".pdf")
            val dateStr     = if (ts > 0L) sdf.format(Date(ts)) else "Recently viewed"
            val sourceLabel = parseRepoLabel(url)

            val card = buildPdfCard(displayName, dateStr, sourceLabel, url)
            pdfContainer.addView(card)
            historyItems.add(Pair(card as View, "$displayName $dateStr $sourceLabel"))
        }

        val totalCount = browseArr.length()
        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear PDF History")
                .setMessage("Remove all $totalCount PDF entries from browsing history?")
                .setPositiveButton("Clear All") { _, _ ->
                    prefs.edit { putString("BROWSE_HISTORY", "[]") }
                    historyItems.removeAll { (v, _) -> pdfContainer.indexOfChild(v) >= 0 }
                    buildPdfHistorySection()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── PDF card factory ──────────────────────────────────────────────────────

    private fun buildPdfCard(
        title: String,
        dateStr: String,
        source: String,
        url: String
    ): MaterialCardView {
        val dp = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { lp -> lp.bottomMargin = (8 * dp).toInt() }
            radius        = 12 * dp
            cardElevation = 2 * dp
            isClickable   = true
            isFocusable   = true
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding((14 * dp).toInt(), (12 * dp).toInt(), (14 * dp).toInt(), (12 * dp).toInt())
        }

        // Purple "PDF" badge
        val badge = TextView(this).apply {
            text = "PDF"
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize = 9f
            gravity  = Gravity.CENTER
            setBackgroundColor(0xFF6A1B9A.toInt())
            setPadding((5 * dp).toInt(), (4 * dp).toInt(), (5 * dp).toInt(), (4 * dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                (38 * dp).toInt(), (28 * dp).toInt()
            ).also { lp -> lp.marginEnd = (12 * dp).toInt() }
        }

        // Text column
        val textCol = LinearLayout(this).apply {
            orientation  = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        textCol.addView(TextView(this).apply {
            text = title
            setTextColor(0xFF1A1A1A.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize  = 14f
            maxLines  = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        if (source.isNotBlank()) {
            textCol.addView(TextView(this).apply {
                text = source
                setTextColor(0xFF6A1B9A.toInt())
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { lp -> lp.topMargin = (1 * dp).toInt() }
            })
        }
        textCol.addView(TextView(this).apply {
            text = dateStr
            setTextColor(0xFF999999.toInt())
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { lp -> lp.topMargin = (2 * dp).toInt() }
        })

        // Chevron
        val chevron = TextView(this).apply {
            text = "›"
            setTextColor(0xFFCCCCCC.toInt())
            textSize = 22f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { lp -> lp.marginStart = (6 * dp).toInt() }
        }

        row.addView(badge)
        row.addView(textCol)
        row.addView(chevron)
        card.addView(row)

        card.setOnClickListener {
            if (url.isNotEmpty()) {
                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                    putExtra("PDF_URL",   url)
                    putExtra("IS_LOCAL",  false)
                    putExtra("PDF_TITLE", title)
                })
            } else {
                Toast.makeText(this, "URL no longer available", Toast.LENGTH_SHORT).show()
            }
        }

        return card
    }

    // ── Search ────────────────────────────────────────────────────────────────

    private fun setupSearch() {
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }

        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            noResults.visibility       = View.GONE
            showAllItems()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(searchInput.windowToken, 0)
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterItems(s?.toString() ?: "", noResults)
            }
        })

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }
    }

    private fun filterItems(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        historyItems.forEach { (view, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            view.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAllItems() {
        historyItems.forEach { (view, _) -> view.visibility = View.VISIBLE }
    }

    // ── Hamburger ─────────────────────────────────────────────────────────────

    private fun setupHamburger() {
        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss()
            else showHamburgerMenu(anchor)
        }
    }

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp        = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView,
            (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation          = 12 * dp
            animationStyle     = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY,
            loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        hamburgerPopup = popup
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private fun setupNavigation() {
        // nav_history omitted — already here
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun findTextViews(view: View): List<TextView> {
        val result = mutableListOf<TextView>()
        if (view is TextView) { result.add(view); return result }
        if (view is android.view.ViewGroup)
            for (i in 0 until view.childCount) result.addAll(findTextViews(view.getChildAt(i)))
        return result
    }

    private fun buildSearchText(card: MaterialCardView): String =
        findTextViews(card).joinToString(" ") { it.text }

    private fun parseRepoLabel(url: String): String {
        // Extract "owner/repo" from raw GitHub URLs for a tidy source label
        val path = url
            .removePrefix("https://raw.githubusercontent.com/")
            .removePrefix("https://github.com/")
        val parts = path.split("/")
        return if (parts.size >= 2) "${parts[0]}/${parts[1]}" else
            runCatching {
                android.net.Uri.parse(url).host ?: ""
            }.getOrElse { "" }
    }
}
