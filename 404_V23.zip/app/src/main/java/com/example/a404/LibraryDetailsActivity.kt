package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

/**
 * Book detail / PDF list screen – Supabase Edition (V20) - Redesigned UI
 *
 * Upgraded to focus on UI/UX, removed visible chapters list, 
 * and ensures specific PDF content is passed to Learn/Quiz.
 */
class LibraryDetailsActivity : ComponentActivity() {

    private var activeChapterPopup: PopupWindow? = null
    private var specificPdfUrl: String = ""

    // ── Cover URL ─────────────────────────────────────────────────────────────

    private fun getCoverUrl(title: String): String {
        val encoded = title.replace(" ", "+").replace("&", "%26")
        return "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_2)

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        val bookTitle  = intent.getStringExtra("BOOK_TITLE")
                         ?: prefs.getString("SELECTED_BOOK",    "Unknown Book") ?: "Unknown Book"
        val bookAuthor = prefs.getString("SELECTED_AUTHOR",  "") ?: ""
        val bookDesc   = prefs.getString("SELECTED_DESC",    "") ?: ""
        val bookCourse = prefs.getString("SELECTED_COURSE",  "") ?: ""
        val bookYear   = prefs.getString("SELECTED_YEAR",    "") ?: ""
        val bookUrl    = prefs.getString("SELECTED_BOOK_URL","") ?: ""
        val bookChapters = prefs.getInt("SELECTED_CHAPTERS", 0)
        
        // Store initial URL
        specificPdfUrl = bookUrl

        // ── Header ────────────────────────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text      = bookTitle
        findViewById<TextView>(R.id.author_label).text      =
            if (bookAuthor.isNotBlank()) "by $bookAuthor" else "Supabase Library"
        findViewById<TextView>(R.id.course_year_label).text = "$bookCourse · $bookYear"

        Glide.with(this)
            .load(getCoverUrl(bookTitle))
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(findViewById(R.id.book_cover_image))

        findViewById<TextView>(R.id.book_description).text = bookDesc.ifBlank {
            "A collection of PDF resources for $bookCourse students in their $bookYear."
        }

        // ── Toolbar actions ───────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // "Add to Library"
        findViewById<View>(R.id.addlibrarybutton).setOnClickListener {
            addBookToLibrary(bookTitle, bookAuthor, bookDesc, bookChapters, bookCourse, bookYear)
        }

        // "Learn" → AI quiz (using specificPdfUrl)
        findViewById<View>(R.id.learnbuttn).setOnClickListener {
            startActivity(Intent(this, GroqQuizActivity::class.java).apply {
                putExtra("BOOK_TITLE",  bookTitle)
                putExtra("BOOK_AUTHOR", bookAuthor)
                putExtra("BOOK_DESC",   bookDesc)
                putExtra("BOOK_COURSE", bookCourse)
                putExtra("BOOK_YEAR",   bookYear)
                putExtra("BOOK_URL",    specificPdfUrl) // Pass the specific PDF URL found
            })
        }

        // ── Three-dots overlay ────────────────────────────────────────────────
        val threeDots   = findViewById<ImageView>(R.id.three_dots)
        val menuOverlay = findViewById<View>(R.id.three_dots_menu)
        threeDots.setOnClickListener { menuOverlay.visibility = View.VISIBLE }
        menuOverlay.findViewById<View>(R.id.menu_close).setOnClickListener {
            menuOverlay.visibility = View.GONE
        }
        menuOverlay.findViewById<View>(R.id.menu_download).setOnClickListener {
            menuOverlay.visibility = View.GONE
            if (specificPdfUrl.isNotBlank()) {
                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                    putExtra("PDF_URL",   specificPdfUrl)
                    putExtra("IS_LOCAL",  false)
                    putExtra("PDF_TITLE", bookTitle)
                })
            } else {
                Toast.makeText(this, "No download URL available.", Toast.LENGTH_SHORT).show()
            }
        }

        // ── Background PDF Fetch (to get specific URL for Learn/Quiz) ─────────
        if (bookCourse.isNotBlank() && bookYear.isNotBlank()) {
            fetchSpecificPdf(bookCourse, bookYear)
        }
    }

    private fun fetchSpecificPdf(course: String, year: String) {
        SupabaseRepository.fetchBooksForSlot(
            course = course,
            year = year,
            onSuccess = { books ->
                if (books.isNotEmpty()) {
                    // Grab the first PDF found for this specific book slot
                    specificPdfUrl = books[0].downloadUrl
                }
            },
            onError = { /* Fail silently, will fallback to metadata in Quiz */ }
        )
    }

    private fun addBookToLibrary(title: String, author: String, desc: String, chapters: Int, course: String, year: String) {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val list  = prefs.getString("DOWNLOADED_BOOKS_LIST", "") ?: ""
        val newItem = "$title|$author|$desc|$chapters|$course|$year|$specificPdfUrl"
        
        if (!list.contains(title)) {
            val newList = if (list.isEmpty()) newItem else "$list#$newItem"
            prefs.edit().putString("DOWNLOADED_BOOKS_LIST", newList).apply()
            Toast.makeText(this, "Saved to Library!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Already in Library", Toast.LENGTH_SHORT).show()
        }
    }
}
