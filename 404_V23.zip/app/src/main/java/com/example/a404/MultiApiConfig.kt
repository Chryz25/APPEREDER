package com.example.a404

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║           MULTI-API CONFIGURATION (Gemini + ApiFreeLLM + Grok)  ║
 * ║                                                                  ║
 * ║  Fallback Priority:                                              ║
 * ║   1. Gemini (primary - best quality)                             ║
 * ║   2. ApiFreeLLM (backup - unlimited free tier)                   ║
 * ║   3. Grok (last resort - paid/limited)                           ║
 * ║                                                                  ║
 * ║  How to set up:                                                   ║
 * ║   1. Get Gemini API key from: https://ai.google.dev/              ║
 * ║   2. Get ApiFreeLLM from: https://www.apifreellm.com/             ║
 * ║   3. Grok key from: https://console.groq.com                      ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */
object MultiApiConfig {

    // ── Gemini Configuration (Primary) ─────────────────────────────────────────
    const val GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
    const val GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    const val GEMINI_MODEL = "gemini-1.5-flash"

    // ── ApiFreeLLM Configuration (Backup/Unlimited) ───────────────────────────
    const val APIFREELLM_API_KEY = "YOUR_APIFREELLM_API_KEY"
    const val APIFREELLM_API_URL = "https://api.apifreellm.com/v1/chat/completions"
    const val APIFREELLM_MODEL = "meta-llama/Llama-2-70b-chat-hf"

    // ── Grok Configuration (Last Resort) ───────────────────────────────────────
    // ⚠️ IMPORTANT: Never hardcode API keys in source code!
    // Set this via environment variable or secure config at runtime
    const val GROK_API_KEY = "YOUR_GROK_API_KEY"
    const val GROK_API_URL = "https://api.groq.com/openai/v1/chat/completions"
    const val GROK_MODEL = "llama-3.3-70b-versatile"

    // ── Rate Limiting & Thresholds ─────────────────────────────────────────────
    const val RATE_LIMIT_THRESHOLD_GEMINI = 50  // Switch after 50 requests
    const val RATE_LIMIT_THRESHOLD_APIFREELLM = 100  // Switch after 100 requests

    // ── Request Timeouts ──────────────────────────────────────────────────────
    const val CONNECT_TIMEOUT_SECONDS = 20L
    const val READ_TIMEOUT_SECONDS = 60L
    const val WRITE_TIMEOUT_SECONDS = 20L

    // ── API Provider Enum ─────────────────────────────────────────────────────
    enum class ApiProvider {
        GEMINI, APIFREELLM, GROK
    }
}
