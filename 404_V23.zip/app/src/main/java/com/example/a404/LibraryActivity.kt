package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Library screen – shows the user's main "selected" book and any downloaded books.
 *
 * Fixes / upgrades vs V15:
 *  1. Book removal of the "main" book now also clears PROFILE_SETUP_DONE so the
 *     user is re-routed to ChoosingPhaseActivity on next launch (was silently broken).
 *  2. Deduplication logic uses a stable key (title+course+year) instead of
 *     just title, so books with the same title but different courses don't clash.
 *  3. Search bar now also hides itself properly when re-opened (toggle worked
 *     but didn't clear text on collapse in all paths).
 *  4. Hamburger popup is dismissed in onPause to prevent window-leak crashes.
 *  5. Bottom nav no longer creates a new task when already on this screen.
 */
class LibraryActivity : ComponentActivity() {

    private var hamburgerPopup: PopupWindow? = null
    private lateinit var libraryGrid: GridLayout
    private val allLibraryCards = mutableListOf<Pair<MaterialCardView, JSONObject>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_1)

        libraryGrid = findViewById(R.id.library_grid)

        val searchIcon      = findViewById<ImageView>(R.id.search_icon)
        val searchContainer = findViewById<CardView>(R.id.search_bar_container)
        val searchEditText  = findViewById<EditText>(R.id.search_edit_text)

        loadLibraryItems()

        // ── Search toggle ─────────────────────────────────────────────────────
        searchIcon.setOnClickListener {
            val visible = searchContainer.visibility == View.VISIBLE
            searchContainer.visibility = if (visible) View.GONE else View.VISIBLE
            if (!visible) {
                searchEditText.requestFocus()
            } else {
                searchEditText.setText("")
                filterLibrary("")
            }
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterLibrary(s?.toString()?.trim()?.lowercase() ?: "")
            }
        })

        // ── Hamburger menu ────────────────────────────────────────────────────
        val menuButton = findViewById<ImageView>(R.id.menu_button)
        menuButton.setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) {
                hamburgerPopup?.dismiss()
            } else {
                showHamburgerMenu(anchor)
            }
        }

        setupBottomNavigation()
    }

    override fun onResume() {
        super.onResume()
        // Refresh the grid every time we return here (e.g. after a download completes)
        loadLibraryItems()
    }

    override fun onPause() {
        super.onPause()
        // Dismiss popup to prevent WindowLeaked crash
        hamburgerPopup?.dismiss()
    }

    // ── Load / populate ───────────────────────────────────────────────────────

    private fun loadLibraryItems() {
        libraryGrid.removeAllViews()
        allLibraryCards.clear()

        val prefs        = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val selectedBook = prefs.getString("SELECTED_BOOK", null)

        // Track titles already added to avoid duplicates
        val addedKeys = mutableSetOf<String>()

        // 1. Main "selected" book from ChoosingPhase
        if (!selectedBook.isNullOrBlank() && selectedBook != "Unknown Book") {
            val course = prefs.getString("SELECTED_COURSE", "") ?: ""
            val year   = prefs.getString("SELECTED_YEAR",   "") ?: ""
            val key    = "$selectedBook|$course|$year"
            if (addedKeys.add(key)) {
                val bookObj = JSONObject().apply {
                    put("title",    selectedBook)
                    put("author",   prefs.getString("SELECTED_AUTHOR",   ""))
                    put("course",   course)
                    put("year",     year)
                    put("chapters", prefs.getInt("SELECTED_CHAPTERS", 0))
                    put("is_main",  true)
                }
                addBookToGrid(bookObj)
            }
        }

        // 2. Downloaded books
        val downloadedJson = prefs.getString("DOWNLOADED_BOOKS_LIST", "[]") ?: "[]"
        try {
            val jsonArray = JSONArray(downloadedJson)
            for (i in 0 until jsonArray.length()) {
                val bookObj = jsonArray.getJSONObject(i)
                val title   = bookObj.optString("title")
                val course  = bookObj.optString("course")
                val year    = bookObj.optString("year")
                val key     = "$title|$course|$year"
                if (addedKeys.add(key)) {
                    addBookToGrid(bookObj)
                }
            }
        } catch (_: Exception) {}
    }

    private fun addBookToGrid(bookObj: JSONObject) {
        val title    = bookObj.optString("title", "Unknown Book")
        val author   = bookObj.optString("author", "")
        val course   = bookObj.optString("course", "")
        val year     = bookObj.optString("year", "")
        val chapters = bookObj.optInt("chapters", 0)
        val isMain   = bookObj.optBoolean("is_main", false)

        val card = LayoutInflater.from(this)
            .inflate(R.layout.library_grid_item_template, libraryGrid, false) as MaterialCardView

        card.findViewById<TextView>(R.id.chosen_book_title).text    = title
        card.findViewById<TextView>(R.id.chosen_book_author).text   = if (author.isNotEmpty()) "by $author" else ""
        card.findViewById<TextView>(R.id.chosen_book_course).text   = if (year.isNotEmpty()) "$course · $year" else course
        card.findViewById<TextView>(R.id.chosen_book_chapters).text = if (chapters > 0) "$chapters Chapters" else "PDF Book"

        Glide.with(this)
            .load("https://covers.openlibrary.org/b/title/${title.replace(" ", "+")}-M.jpg?default=false")
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(card.findViewById(R.id.chosen_book_cover))

        card.setOnClickListener {
            // Persist selection so LibraryDetailsActivity reads the right book
            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                .putString("SELECTED_BOOK",     title)
                .putString("SELECTED_AUTHOR",   author)
                .putString("SELECTED_COURSE",   course)
                .putString("SELECTED_YEAR",     year)
                .putInt("SELECTED_CHAPTERS",    chapters)
                .putString("SELECTED_DESC",     bookObj.optString("description", ""))
                .putString("SELECTED_BOOK_URL", bookObj.optString("downloadUrl", ""))
                .apply()
            startActivity(
                Intent(this, LibraryDetailsActivity::class.java)
                    .putExtra("BOOK_TITLE", title)
            )
        }

        card.findViewById<ImageView>(R.id.btn_delete_book).setOnClickListener {
            removeBook(title, course, year, isMain)
        }

        libraryGrid.addView(card)
        allLibraryCards.add(Pair(card, bookObj))
    }

    private fun removeBook(title: String, course: String, year: String, isMain: Boolean) {
        val prefs  = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()

        if (isMain) {
            // Clear all main-book keys AND reset profile so the user goes back
            // to ChoosingPhaseActivity on next launch instead of landing on an
            // empty library.
            editor.remove("SELECTED_BOOK")
                  .remove("SELECTED_AUTHOR")
                  .remove("SELECTED_COURSE")
                  .remove("SELECTED_YEAR")
                  .remove("SELECTED_CHAPTERS")
                  .remove("SELECTED_DESC")
                  .remove("SELECTED_BOOK_URL")
                  .remove("SELECTED_FILE_PATH")
                  .remove("SELECTED_REPO_PATH")
                  .remove("PROFILE_SETUP_DONE")
        } else {
            val downloadedJson = prefs.getString("DOWNLOADED_BOOKS_LIST", "[]") ?: "[]"
            try {
                val jsonArray = JSONArray(downloadedJson)
                val newList   = JSONArray()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    // Match on title + course + year for precise dedup
                    if (!(obj.optString("title") == title &&
                          obj.optString("course") == course &&
                          obj.optString("year")   == year)) {
                        newList.put(obj)
                    }
                }
                editor.putString("DOWNLOADED_BOOKS_LIST", newList.toString())
            } catch (_: Exception) {}
        }

        // Delete physical file if it exists
        File(File(filesDir, "Sources"), "$title.pdf").takeIf { it.exists() }?.delete()

        editor.apply()
        Toast.makeText(this, "Removed "$title"", Toast.LENGTH_SHORT).show()
        loadLibraryItems()
    }

    private fun filterLibrary(query: String) {
        allLibraryCards.forEach { (card, bookObj) ->
            val text = listOf(
                bookObj.optString("title"),
                bookObj.optString("author"),
                bookObj.optString("course")
            ).joinToString(" ").lowercase()
            card.visibility = if (query.isEmpty() || text.contains(query)) View.VISIBLE else View.GONE
        }
    }

    // ── Hamburger popup ───────────────────────────────────────────────────────

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView,
            (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation          = 12 * dp
            animationStyle     = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        hamburgerPopup = popup
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupBottomNavigation() {
        // Avoid re-launching self; just do nothing if already here
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
