package com.example.a404

import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * MULTI-API MANAGER
 * 
 * Smart fallback system with automatic provider switching:
 *   1. Try Gemini (primary) → If rate limited, switch to ApiFreeLLM
 *   2. Try ApiFreeLLM → If rate limited, switch to Grok
 *   3. Try Grok → If fails, return error
 *
 * Features:
 *   - Rate limit tracking per provider
 *   - Automatic fallback on rate limit exceeded
 *   - Request attempt logging
 *   - Configurable thresholds
 * ═══════════════════════════════════════════════════════════════════════════════
 */
object MultiApiManager {
    private const val TAG = "MultiApiManager"

    // Providers
    private val geminiProvider = GeminiProvider()
    private val apiFreeLLMProvider = ApiFreeLLMProvider()
    private val grokProvider = GrokProvider()

    // Rate limit tracking (atomic counters per provider)
    private val requestCounters = ConcurrentHashMap<String, AtomicInteger>()
    private val rateLimitReachedFlags = ConcurrentHashMap<String, Boolean>()

    // Request attempt tracking
    private var lastAttemptedProvider: String? = null
    private var lastErrorMessage: String? = null

    init {
        // Initialize counters
        requestCounters["gemini"] = AtomicInteger(0)
        requestCounters["apifreellm"] = AtomicInteger(0)
        requestCounters["grok"] = AtomicInteger(0)

        // Initialize rate limit flags
        rateLimitReachedFlags["gemini"] = false
        rateLimitReachedFlags["apifreellm"] = false
        rateLimitReachedFlags["grok"] = false
    }

    /**
     * Generate text with automatic fallback to next provider if rate limited
     */
    suspend fun generateText(
        prompt: String,
        systemMessage: String = "You are a helpful assistant.",
        temperature: Float = 0.7f
    ): Result<String> {
        // Priority order: Gemini → ApiFreeLLM → Grok
        val providers = listOf(
            Triple(geminiProvider, "gemini", MultiApiConfig.RATE_LIMIT_THRESHOLD_GEMINI),
            Triple(apiFreeLLMProvider, "apifreellm", MultiApiConfig.RATE_LIMIT_THRESHOLD_APIFREELLM),
            Triple(grokProvider, "grok", Int.MAX_VALUE)  // Grok: last resort, no limit
        )

        for ((provider, providerKey, rateLimit) in providers) {
            // Skip if rate limit already reached
            if (rateLimitReachedFlags[providerKey] == true) {
                Log.i(TAG, "⏭️  Skipping $providerKey (rate limit reached)")
                continue
            }

            // Skip if not configured
            if (!provider.isConfigured) {
                Log.i(TAG, "⏭️  Skipping ${provider.providerName} (not configured)")
                continue
            }

            lastAttemptedProvider = provider.providerName
            val counter = requestCounters[providerKey]!!

            Log.i(TAG, "🔄 Attempting ${provider.providerName} (request #${counter.get() + 1}/$rateLimit)")

            val result = provider.generateText(prompt, systemMessage, temperature)

            return when (result) {
                is Result.Success -> {
                    counter.incrementAndGet()
                    
                    // Check if we've reached the threshold
                    if (counter.get() >= rateLimit) {
                        rateLimitReachedFlags[providerKey] = true
                        Log.w(TAG, "⚠️  ${provider.providerName} rate limit reached (${counter.get()}/$rateLimit)")
                    }

                    Log.i(TAG, "✅ ${provider.providerName} succeeded")
                    result
                }
                is Result.Error -> {
                    lastErrorMessage = result.message
                    Log.w(TAG, "❌ ${provider.providerName} failed: ${result.message}")
                    
                    // Continue to next provider
                    continue
                }
            }
        }

        // All providers failed
        return Result.Error(
            Exception("All providers exhausted"),
            "Tried Gemini → ApiFreeLLM → Grok. Last error: $lastErrorMessage"
        )
    }

    /**
     * Get current request counts for monitoring
     */
    fun getRequestCounts(): Map<String, Int> {
        return mapOf(
            "gemini" to requestCounters["gemini"]!!.get(),
            "apifreellm" to requestCounters["apifreellm"]!!.get(),
            "grok" to requestCounters["grok"]!!.get()
        )
    }

    /**
     * Get rate limit status
     */
    fun getRateLimitStatus(): Map<String, Boolean> {
        return rateLimitReachedFlags.toMap()
    }

    /**
     * Reset rate limit flags (use with caution - e.g., on daily reset)
     */
    fun resetRateLimits() {
        Log.i(TAG, "🔄 Resetting rate limits")
        rateLimitReachedFlags["gemini"] = false
        rateLimitReachedFlags["apifreellm"] = false
        rateLimitReachedFlags["grok"] = false
        requestCounters["gemini"]!!.set(0)
        requestCounters["apifreellm"]!!.set(0)
        requestCounters["grok"]!!.set(0)
    }

    /**
     * Get last attempted provider (for debugging)
     */
    fun getLastAttemptedProvider(): String? = lastAttemptedProvider

    /**
     * Get last error message (for debugging)
     */
    fun getLastErrorMessage(): String? = lastErrorMessage

    /**
     * Log current status
     */
    fun logStatus() {
        val counts = getRequestCounts()
        val limits = getRateLimitStatus()
        Log.i(TAG, """
            ╔════════════════════════════════════════╗
            ║       MULTI-API STATUS REPORT          ║
            ╠════════════════════════════════════════╣
            ║ Gemini:     ${String.format("%3d", counts["gemini"])} requests | Rate limit: ${limits["gemini"]}
            ║ ApiFreeLLM: ${String.format("%3d", counts["apifreellm"])} requests | Rate limit: ${limits["apifreellm"]}
            ║ Grok:       ${String.format("%3d", counts["grok"])} requests | Rate limit: ${limits["grok"]}
            ║ Last provider: ${lastAttemptedProvider ?: "None"}
            ║ Last error: ${lastErrorMessage?.take(50) ?: "None"}
            ╚════════════════════════════════════════╝
        """.trimIndent())
    }
}
