package com.example.a404

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Interface for all API providers (Gemini, ApiFreeLLM, Grok)
 * Ensures consistent request/response handling across providers
 */
interface IApiProvider {
    val providerName: String
    val isConfigured: Boolean
    
    suspend fun generateText(
        prompt: String,
        systemMessage: String = "You are a helpful assistant.",
        temperature: Float = 0.7f
    ): Result<String>
}

/**
 * Result wrapper for success/failure handling
 */
sealed class Result<T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error<T>(val exception: Exception, val message: String) : Result<T>()
}

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * GEMINI PROVIDER (Primary - Best quality, rate limited)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class GeminiProvider : IApiProvider {
    override val providerName = "Gemini"
    override val isConfigured: Boolean
        get() = MultiApiConfig.GEMINI_API_KEY != "YOUR_GEMINI_API_KEY"

    private val client = OkHttpClient.Builder()
        .connectTimeout(MultiApiConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(MultiApiConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(MultiApiConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    override suspend fun generateText(
        prompt: String,
        systemMessage: String,
        temperature: Float
    ): Result<String> {
        return try {
            if (!isConfigured) {
                return Result.Error(
                    Exception("Gemini not configured"),
                    "Gemini API key not set in MultiApiConfig"
                )
            }

            val requestBody = JSONObject().apply {
                put("contents", JSONObject().apply {
                    put("parts", arrayOf(JSONObject().apply {
                        put("text", "$systemMessage\n\n$prompt")
                    }))
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", temperature)
                    put("maxOutputTokens", 2048)
                })
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("${MultiApiConfig.GEMINI_API_URL}/${MultiApiConfig.GEMINI_MODEL}:generateContent?key=${MultiApiConfig.GEMINI_API_KEY}")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return Result.Error(
                Exception("Empty response"),
                "Gemini returned empty response"
            )

            if (!response.isSuccessful) {
                return Result.Error(
                    Exception("HTTP ${response.code}"),
                    "Gemini API error: $responseBody"
                )
            }

            val jsonResponse = JSONObject(responseBody)
            val content = jsonResponse
                .optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text", "")

            if (content.isNullOrEmpty()) {
                return Result.Error(
                    Exception("No content"),
                    "Gemini returned empty content"
                )
            }

            Result.Success(content)
        } catch (e: Exception) {
            Result.Error(e, "Gemini error: ${e.message}")
        }
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * APIFREELLM PROVIDER (Backup - Unlimited free tier)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class ApiFreeLLMProvider : IApiProvider {
    override val providerName = "ApiFreeLLM"
    override val isConfigured: Boolean
        get() = MultiApiConfig.APIFREELLM_API_KEY != "YOUR_APIFREELLM_API_KEY"

    private val client = OkHttpClient.Builder()
        .connectTimeout(MultiApiConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(MultiApiConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(MultiApiConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    override suspend fun generateText(
        prompt: String,
        systemMessage: String,
        temperature: Float
    ): Result<String> {
        return try {
            if (!isConfigured) {
                return Result.Error(
                    Exception("ApiFreeLLM not configured"),
                    "ApiFreeLLM API key not set in MultiApiConfig"
                )
            }

            val requestBody = JSONObject().apply {
                put("model", MultiApiConfig.APIFREELLM_MODEL)
                put("messages", arrayOf(
                    JSONObject().apply {
                        put("role", "system")
                        put("content", systemMessage)
                    },
                    JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    }
                ))
                put("temperature", temperature)
                put("max_tokens", 2048)
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(MultiApiConfig.APIFREELLM_API_URL)
                .post(requestBody)
                .addHeader("Authorization", "Bearer ${MultiApiConfig.APIFREELLM_API_KEY}")
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return Result.Error(
                Exception("Empty response"),
                "ApiFreeLLM returned empty response"
            )

            if (!response.isSuccessful) {
                return Result.Error(
                    Exception("HTTP ${response.code}"),
                    "ApiFreeLLM API error: $responseBody"
                )
            }

            val jsonResponse = JSONObject(responseBody)
            val content = jsonResponse
                .optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")

            if (content.isNullOrEmpty()) {
                return Result.Error(
                    Exception("No content"),
                    "ApiFreeLLM returned empty content"
                )
            }

            Result.Success(content)
        } catch (e: Exception) {
            Result.Error(e, "ApiFreeLLM error: ${e.message}")
        }
    }
}

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * GROK PROVIDER (Last Resort - Limited/Paid)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class GrokProvider : IApiProvider {
    override val providerName = "Grok"
    override val isConfigured: Boolean
        get() = MultiApiConfig.GROK_API_KEY != "YOUR_GROK_API_KEY"

    private val client = OkHttpClient.Builder()
        .connectTimeout(MultiApiConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(MultiApiConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(MultiApiConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    override suspend fun generateText(
        prompt: String,
        systemMessage: String,
        temperature: Float
    ): Result<String> {
        return try {
            if (!isConfigured) {
                return Result.Error(
                    Exception("Grok not configured"),
                    "Grok API key not set in MultiApiConfig"
                )
            }

            val requestBody = JSONObject().apply {
                put("model", MultiApiConfig.GROK_MODEL)
                put("messages", arrayOf(
                    JSONObject().apply {
                        put("role", "system")
                        put("content", systemMessage)
                    },
                    JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    }
                ))
                put("temperature", temperature)
                put("max_tokens", 2048)
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(MultiApiConfig.GROK_API_URL)
                .post(requestBody)
                .addHeader("Authorization", "Bearer ${MultiApiConfig.GROK_API_KEY}")
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return Result.Error(
                Exception("Empty response"),
                "Grok returned empty response"
            )

            if (!response.isSuccessful) {
                return Result.Error(
                    Exception("HTTP ${response.code}"),
                    "Grok API error: $responseBody"
                )
            }

            val jsonResponse = JSONObject(responseBody)
            val content = jsonResponse
                .optJSONArray("choices")
                ?.optJSONObject(0)
                ?.optJSONObject("message")
                ?.optString("content", "")

            if (content.isNullOrEmpty()) {
                return Result.Error(
                    Exception("No content"),
                    "Grok returned empty content"
                )
            }

            Result.Success(content)
        } catch (e: Exception) {
            Result.Error(e, "Grok error: ${e.message}")
        }
    }
}
