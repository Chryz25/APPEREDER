package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import java.util.concurrent.atomic.AtomicInteger

// ── Book data model ───────────────────────────────────────────────────────────
data class BookData(
    val title:       String,
    val author:      String,
    val description: String,
    val chapters:    Int,
    val course:      String,
    val year:        String,
    val downloadUrl: String = "",
    val filePath:    String = ""   // Supabase storage path (e.g. "BSCS/1st_Year/book.pdf")
)

/**
 * ChoosingPhaseActivity – Supabase Edition (V20)
 *
 * Replaces all GitHub API calls with Supabase REST queries via SupabaseRepository.
 * The UI logic (course cards, year chips, book card confirmation) is unchanged.
 *
 * Flow:
 *  1. On create: fetch the first book for every course+year slot from Supabase in
 *     parallel (one query per slot combination).
 *  2. As user selects Course → Year, the matching book is shown from the local cache.
 *  3. User taps the card to confirm, then hits Continue → LibraryActivity.
 *
 * Supabase table required: `books`
 * See SupabaseConfig.kt and SUPABASE_SETUP.md for credentials and SQL schema.
 */
class ChoosingPhaseActivity : ComponentActivity() {

    // ══════════════════════════════════════════════════════════════════════════
    //  ★  COURSES AND YEARS  ★
    //  These must match the `course` and `year` column values in your Supabase
    //  `books` table exactly (case-sensitive).
    //  BSACT only supports 1st and 2nd Year.
    // ══════════════════════════════════════════════════════════════════════════
    private val courseLabels  = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )
    private val allYearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")
    private val BSACT_YEARS   = setOf("1st Year", "2nd Year")
    private val BSACT_INDEX   = 3
    // ══════════════════════════════════════════════════════════════════════════

    // In-memory catalogue: "Course|Year" → BookData (first PDF found)
    private val bookCatalog  = mutableMapOf<String, BookData>()
    private val pendingCount = AtomicInteger(0)

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear:   MaterialCardView? = null
    private var bookConfirmed   = false

    private val colorSelected  = Color.parseColor("#FFFFF0E8")
    private val colorDefault   = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    private lateinit var tvHint:          TextView
    private lateinit var tvRetryStatus:   TextView
    private lateinit var progressLoading: ProgressBar
    private lateinit var bookGridLayout:  View
    private lateinit var bookCard:        MaterialCardView
    private lateinit var tvBookTitle:     TextView
    private lateinit var tvBookAuthor:    TextView
    private lateinit var tvBookDesc:      TextView
    private lateinit var tvBookChapters:  TextView
    private lateinit var btnContinue:     Button
    private lateinit var btnRetry:        Button
    private lateinit var yearChips:       List<MaterialCardView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        btnContinue     = findViewById(R.id.btn_continue)
        tvHint          = findViewById(R.id.tv_book_hint)
        bookGridLayout  = findViewById(R.id.book_grid)
        bookCard        = findViewById(R.id.selectionbook_1)
        tvBookTitle     = findViewById(R.id.book_title_label)
        tvBookAuthor    = findViewById(R.id.book_author_label)
        tvBookDesc      = findViewById(R.id.book_desc_label)
        tvBookChapters  = findViewById(R.id.book_chapters_label)
        progressLoading = findViewById(R.id.progress_loading)
        tvRetryStatus   = findViewById(R.id.tv_retry_status)
        btnRetry        = findViewById(R.id.btn_retry_load)

        btnContinue.isEnabled = false

        // ── Retry ─────────────────────────────────────────────────────────────
        btnRetry.setOnClickListener {
            bookCatalog.clear()
            fetchAllSlots()
        }

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                selectedCourse = selectCard(card, courses, selectedCourse)
                courseIndex    = if (selectedCourse != null) idx else -1
                yearIndex      = -1
                selectedYear   = null
                bookConfirmed  = false
                btnContinue.isEnabled = false
                applyYearChipVisibility()
                refreshBookCard()
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        yearChips = listOf(
            findViewById(R.id.chip_year_1),
            findViewById(R.id.chip_year_2),
            findViewById(R.id.chip_year_3),
            findViewById(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                if (chip.visibility != View.VISIBLE || !chip.isEnabled) return@setOnClickListener
                val visible = yearChips.filter { it.visibility == View.VISIBLE && it.isEnabled }
                selectedYear  = selectCard(chip, visible, selectedYear)
                yearIndex     = if (selectedYear != null) idx else -1
                bookConfirmed = false
                btnContinue.isEnabled = false
                refreshBookCard()
            }
        }

        // ── Book card: tap to confirm ─────────────────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex < 0 || yearIndex < 0) return@setOnClickListener
            if (!bookCatalog.containsKey(currentKey())) return@setOnClickListener

            bookConfirmed = !bookConfirmed
            val dp = resources.displayMetrics.density
            if (bookConfirmed) {
                bookCard.strokeWidth = (strokeSelected * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                bookCard.setCardBackgroundColor(colorSelected)
                tintCardText(bookCard, "#FF6A1B9A")
            } else {
                bookCard.strokeWidth = (strokeDefault * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                bookCard.setCardBackgroundColor(colorDefault)
                tintCardText(bookCard, "#FF2A2A2A")
            }
            btnContinue.isEnabled = bookConfirmed
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            when {
                courseIndex < 0 -> Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                yearIndex   < 0 -> Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                !bookConfirmed  -> Toast.makeText(this, "Please tap the book card to confirm your selection", Toast.LENGTH_SHORT).show()
                else -> {
                    val book = bookCatalog[currentKey()] ?: return@setOnClickListener
                    getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                        .putString ("SELECTED_BOOK",      book.title)
                        .putString ("SELECTED_AUTHOR",    book.author)
                        .putString ("SELECTED_DESC",      book.description)
                        .putInt    ("SELECTED_CHAPTERS",  book.chapters)
                        .putString ("SELECTED_COURSE",    book.course)
                        .putString ("SELECTED_YEAR",      book.year)
                        .putString ("SELECTED_BOOK_URL",  book.downloadUrl)
                        .putString ("SELECTED_FILE_PATH", book.filePath)
                        // Keep legacy key empty so old code does not break
                        .putString ("SELECTED_REPO_PATH", "")
                        .putBoolean("PROFILE_SETUP_DONE", true)
                        .apply()
                    startActivity(Intent(this, LibraryActivity::class.java))
                    finish()
                }
            }
        }

        tvHint.text               = "Select a course and year above to see your starter book."
        tvHint.visibility         = View.VISIBLE
        bookGridLayout.visibility = View.GONE

        fetchAllSlots()
    }

    // ── Year chip visibility ──────────────────────────────────────────────────

    private fun applyYearChipVisibility() {
        val isBsact = courseIndex == BSACT_INDEX
        val dp      = resources.displayMetrics.density
        yearChips.forEachIndexed { idx, chip ->
            val yearLabel  = allYearLabels[idx]
            val shouldShow = !isBsact || BSACT_YEARS.contains(yearLabel)
            chip.visibility = if (shouldShow) View.VISIBLE else View.GONE
            chip.isEnabled  = shouldShow
            if (shouldShow) {
                chip.strokeWidth = (strokeDefault * dp).toInt()
                chip.strokeColor = Color.parseColor("#FFD6C5B4")
                chip.setCardBackgroundColor(colorDefault)
                tintCardText(chip, "#FF2A2A2A")
            }
        }
        selectedYear = null
        yearIndex    = -1
    }

    // ── Network check ─────────────────────────────────────────────────────────

    private fun isNetworkAvailable(): Boolean {
        val cm      = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps    = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ── Fetch all course+year slots from Supabase in parallel ─────────────────

    private fun fetchAllSlots() {
        progressLoading.visibility = View.VISIBLE
        tvHint.text                = "Loading books from Supabase…"
        tvHint.visibility          = View.VISIBLE
        bookGridLayout.visibility  = View.GONE
        btnRetry.visibility        = View.GONE
        tvRetryStatus.visibility   = View.GONE
        btnContinue.isEnabled      = false
        bookConfirmed              = false

        if (!isNetworkAvailable()) {
            progressLoading.visibility = View.GONE
            tvHint.text                = "No internet connection."
            tvRetryStatus.text         = "Please check your connection and tap Retry."
            tvRetryStatus.visibility   = View.VISIBLE
            btnRetry.visibility        = View.VISIBLE
            return
        }

        // Build valid slots list
        val allSlots = mutableListOf<Pair<String, String>>()
        courseLabels.forEachIndexed { cIdx, course ->
            allYearLabels.forEach { year ->
                val isBsact = cIdx == BSACT_INDEX
                if (!isBsact || BSACT_YEARS.contains(year)) {
                    allSlots.add(course to year)
                }
            }
        }

        pendingCount.set(allSlots.size)
        allSlots.forEach { (course, year) -> fetchSlot(course, year) }
    }

    private fun fetchSlot(course: String, year: String) {
        val key = "$course|$year"

        SupabaseRepository.fetchBooksForSlot(
            course    = course,
            year      = year,
            onSuccess = { books ->
                runOnUiThread {
                    if (isFinishing || isDestroyed) { pendingCount.decrementAndGet(); return@runOnUiThread }
                    val first = books.firstOrNull()
                    if (first != null && !bookCatalog.containsKey(key)) {
                        bookCatalog[key] = BookData(
                            title       = first.title,
                            author      = first.author.ifBlank { "Supabase Library" },
                            description = first.description.ifBlank { "PDF resource for $course · $year" },
                            chapters    = books.size,
                            course      = first.course,
                            year        = first.year,
                            downloadUrl = first.downloadUrl,
                            filePath    = first.filePath
                        )
                    }
                    if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
                }
            },
            onError = { _ ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
                    } else {
                        pendingCount.decrementAndGet()
                    }
                }
            }
        )
    }

    private fun onAllSlotsFetched() {
        progressLoading.visibility = View.GONE
        if (bookCatalog.isEmpty()) {
            tvHint.text               = "Could not load books from Supabase."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            tvRetryStatus.text        = "Check your Supabase credentials and that the `books` table has data, then tap Retry."
            tvRetryStatus.visibility  = View.VISIBLE
            btnRetry.visibility       = View.VISIBLE
        } else {
            refreshBookCard()
        }
    }

    // ── Book card refresh ─────────────────────────────────────────────────────

    private fun currentKey() =
        if (courseIndex >= 0 && yearIndex >= 0)
            "${courseLabels[courseIndex]}|${allYearLabels[yearIndex]}"
        else ""

    private fun refreshBookCard() {
        btnRetry.visibility      = View.GONE
        tvRetryStatus.visibility = View.GONE

        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.text = if (courseIndex >= 0)
                "Now select your academic year."
            else
                "Select a course and year above to see your starter book."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val key          = currentKey()
        val book         = bookCatalog[key]
        val stillLoading = pendingCount.get() > 0

        if (book == null) {
            tvHint.text = if (stillLoading)
                "Still loading from Supabase… please wait."
            else
                "No PDF found for this course/year in Supabase."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE

            if (!stillLoading) {
                tvRetryStatus.text       = "Make sure the `books` table in Supabase has an entry for this course and year."
                tvRetryStatus.visibility = View.VISIBLE
                btnRetry.visibility      = View.VISIBLE
            }
            return
        }

        tvBookTitle.text    = book.title
        tvBookAuthor.text   = if (book.author.isNotBlank()) "by ${book.author}" else "Supabase Library"
        tvBookDesc.text     = book.description
        tvBookChapters.text = if (book.chapters > 1) "${book.chapters} PDFs available" else "Supabase Cloud Library"

        val dp = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * dp).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")
        bookConfirmed         = false
        btnContinue.isEnabled = false

        tvHint.visibility         = View.GONE
        bookGridLayout.visibility = View.VISIBLE
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun selectCard(
        clicked: MaterialCardView,
        all:     List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val dp = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * dp).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) null
        else {
            clicked.strokeWidth = (strokeSelected * dp).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
