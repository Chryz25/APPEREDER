package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Splash / router screen.
 * – Uses lifecycleScope.launch instead of Handler/postDelayed so the delayed
 *   navigation is automatically cancelled if the Activity is destroyed early
 *   (no memory leak, no "Window already focused" crash).
 * – Clears the back-stack properly so the user can't go back to the splash.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.titleloadingscreen)

        lifecycleScope.launch {
            delay(2000L)
            if (isFinishing || isDestroyed) return@launch

            val prefs       = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            val profileDone = prefs.getBoolean("PROFILE_SETUP_DONE", false)
            val savedCourse = prefs.getString("SELECTED_COURSE", null)
            val savedYear   = prefs.getString("SELECTED_YEAR",   null)

            val destination = if (!profileDone || savedCourse == null || savedYear == null)
                Intent(this@MainActivity, ChoosingPhaseActivity::class.java)
            else
                Intent(this@MainActivity, LibraryActivity::class.java)

            startActivity(destination)
            finish()
        }
    }
}
