# 🎨 Multi-API System - Visual Guides

## System Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE LAYER                             │
│  (GroqQuizActivity)                                                     │
│  - Quiz Generation                                                      │
│  - Summary Display                                                      │
│  - Score Calculation                                                    │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                    User clicks "Generate Quiz"
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   MULTI-API MANAGER LAYER                               │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 1. Check Provider Order: Gemini → ApiFreeLLM → Grok           │   │
│  │ 2. For each provider:                                          │   │
│  │    - Is rate limit reached? → Skip                           │   │
│  │    - Is configured? → Skip                                   │   │
│  │    - Call provider.generateText()                             │   │
│  │ 3. On success: return Result.Success(text)                    │   │
│  │ 4. On error: continue to next provider                        │   │
│  │ 5. If all fail: return Result.Error(diagnostics)              │   │
│  └─────────────────────────────────────────────────────────────────┘   │
└────────────┬──────────────────┬──────────────────┬─────────────────────┘
             │                  │                  │
    ┌────────▼────────┐ ┌───────▼───────┐ ┌───────▼───────┐
    │   GEMINI API    │ │   APIFREELLM  │ │  GROK API     │
    │   PROVIDER      │ │   PROVIDER    │ │  PROVIDER     │
    ├─────────────────┤ ├───────────────┤ ├───────────────┤
    │ State:          │ │ State:        │ │ State:        │
    │ Requests: 0/50  │ │ Requests: 0/∞ │ │ Requests: 0/∞ │
    │ Rate limit: ❌   │ │ Rate limit: ❌ │ │ Rate limit: ❌ │
    │ Configured: ✅   │ │ Configured: ✅ │ │ Configured: ✅ │
    │                 │ │               │ │               │
    │ HTTP Client:    │ │ HTTP Client:  │ │ HTTP Client:  │
    │ 20s timeout     │ │ 20s timeout   │ │ 20s timeout   │
    └────────┬────────┘ └───────┬───────┘ └───────┬───────┘
             │                  │                  │
             │                  │                  │
    ┌────────▼──────────────────▼──────────────────▼────────┐
    │          EXTERNAL API SERVICES                        │
    │                                                       │
    │  • google.generativelanguage.googleapis.com           │
    │  • api.apifreellm.com                                 │
    │  • api.groq.com                                       │
    └───────────────────────────────────────────────────────┘
```

## Request Flow - Success Case

```
User Action: Generate Quiz
        │
        ▼
┌──────────────────────────────┐
│ callGroq(prompt)             │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────────────────┐
│ Create background thread for async call   │
└──────────────┬───────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────┐
│ MultiApiManager.generateText(prompt, system, temp)   │
└──────────────┬───────────────────────────────────────┘
               │
               ▼
        ┌──────────────────────────────┐
        │ Provider Priority Check      │
        └──────────────┬───────────────┘
                       │
               ┌───────▼──────────┐
               │ 1. GEMINI        │
               │ Available? ✅     │
               │ Rate limit OK? ✅│
               └───────┬──────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │ GeminiProvider.generateText()│
        │                              │
        │ 1. Build request body        │
        │ 2. Add auth header           │
        │ 3. Make HTTP request         │
        │ 4. Parse response            │
        │ 5. Return Result.Success()   │
        └───────┬──────────────────────┘
                │
                ▼
        ┌──────────────────────────────┐
        │ Result.Success(text)         │
        │                              │
        │ - Increment counter          │
        │ - Check rate limit           │
        │ - Return immediately         │
        └───────┬──────────────────────┘
                │
                ▼
        ┌──────────────────────────────┐
        │ Back in callGroq()            │
        │                              │
        │ - runOnUiThread {}           │
        │ - onSuccess(text)            │
        └───────┬──────────────────────┘
                │
                ▼
        ┌──────────────────────────────┐
        │ Update UI                    │
        │                              │
        │ - parseSummaryResponse()     │
        │ - Display results            │
        │ - Show quiz                  │
        └──────────────────────────────┘
```

## Request Flow - Fallback Case

```
User Action: Generate Quiz
        │
        ▼
┌──────────────────────────────┐
│ callGroq(prompt)             │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────────────────┐
│ MultiApiManager.generateText()            │
└──────────────┬───────────────────────────┘
               │
        ┌──────▼──────────────────────┐
        │ Provider Priority Check     │
        └──────┬───────────────────────┘
               │
        ┌──────▼──────────────┐
        │ 1. GEMINI           │
        │ Rate limit? ⚠️ YES   │
        │ Skip Gemini!        │
        └──────┬──────────────┘
               │
        ┌──────▼─────────────────┐
        │ 2. APIFREELLM          │
        │ Available? ✅          │
        │ Rate limit OK? ✅      │
        └──────┬────────────────┘
               │
               ▼
        ┌──────────────────────────────┐
        │ ApiFreeLLMProvider.generate()│
        │ - Make HTTP request          │
        │ - Parse response             │
        │ - Return Result.Success()    │
        └───────┬──────────────────────┘
                │
                ▼
        ┌──────────────────────────────┐
        │ Result.Success(text)         │
        │ - Increment counter          │
        │ - Return immediately         │
        └───────┬──────────────────────┘
                │
                ▼
        ┌──────────────────────────────┐
        │ Logs show:                   │
        │ ⏭️  Skipping gemini          │
        │ 🔄 Attempting ApiFreeLLM    │
        │ ✅ ApiFreeLLM succeeded      │
        └──────────────────────────────┘
```

## Rate Limit Mechanism

```
REQUEST LIFECYCLE WITH RATE LIMIT TRACKING

Initial State:
  Gemini:     0/50 requests (0%)
  ApiFreeLLM: 0/100 requests (0%)
  Grok:       ∞/∞ requests

Request #1:
  ├─ Check Gemini limit: 0 < 50 ✅
  ├─ Call Gemini ✅
  ├─ Increment counter: 1/50
  └─ Return success

Requests #2-49:
  └─ Same pattern, incrementing counter

Request #50:
  ├─ Check Gemini limit: 49 < 50 ✅
  ├─ Call Gemini ✅
  ├─ Increment counter: 50/50
  ├─ Check if ≥ threshold
  ├─ Set rateLimitReachedFlag = true
  ├─ Log: ⚠️ Gemini rate limit reached
  └─ Return success (last successful Gemini call)

Request #51:
  ├─ Check Gemini limit: rateLimitReachedFlag = true
  ├─ ⏭️ Skip Gemini
  ├─ Check ApiFreeLLM limit: 0 < 100 ✅
  ├─ Call ApiFreeLLM ✅
  ├─ Increment counter: 1/100
  ├─ Log: 🔄 Switched from Gemini to ApiFreeLLM
  └─ Return success

Requests #52-150:
  └─ Same pattern, incrementing ApiFreeLLM counter

Request #151:
  ├─ ⏭️ Skip Gemini (rate limit reached)
  ├─ ⏭️ Skip ApiFreeLLM (rate limit reached)
  ├─ Check Grok: ∞ (no limit)
  ├─ Call Grok ✅
  ├─ Increment counter
  ├─ Log: 🔄 Switched from ApiFreeLLM to Grok
  └─ Return success

Manual Reset (daily):
  └─ MultiApiManager.resetRateLimits()
      ├─ Gemini: 50/50 → 0/50
      ├─ ApiFreeLLM: 100/100 → 0/100
      └─ Grok: counter reset, continue using
```

## Configuration Impact

```
SCENARIO 1: Conservative (Few Switches)
─────────────────────────────────────────
const val RATE_LIMIT_THRESHOLD_GEMINI = 100
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 200

Timeline:
  Req 1-100  → Gemini (100 requests)
  Req 101-200 → ApiFreeLLM (100 requests)
  Req 201+   → Grok


SCENARIO 2: Balanced (Default)
────────────────────────────────
const val RATE_LIMIT_THRESHOLD_GEMINI = 50
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 100

Timeline:
  Req 1-50   → Gemini (50 requests)
  Req 51-100 → ApiFreeLLM (50 requests)
  Req 101+   → Grok


SCENARIO 3: Aggressive (Frequent Switches)
─────────────────────────────────────────
const val RATE_LIMIT_THRESHOLD_GEMINI = 10
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 20

Timeline:
  Req 1-10   → Gemini (10 requests)
  Req 11-20  → ApiFreeLLM (10 requests)
  Req 21+    → Grok
  (Useful for testing/load balancing)


SCENARIO 4: Testing (Immediate Fallback)
──────────────────────────────────────────
const val RATE_LIMIT_THRESHOLD_GEMINI = 1
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 1

Timeline:
  Req 1      → Gemini (1 request)
  Req 2      → ApiFreeLLM (1 request)
  Req 3+     → Grok
  (Perfect for verifying fallback chain)
```

## Request Counter State Machine

```
┌─────────────────────────────┐
│   INITIAL STATE             │
│  Gemini: [0/50]             │
│  ApiFreeLLM: [0/100]        │
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Request #1
             ▼
┌─────────────────────────────┐
│   USING GEMINI              │
│  Gemini: [1/50] ✅          │
│  ApiFreeLLM: [0/100]        │
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Requests #2-50
             ▼
┌─────────────────────────────┐
│   GEMINI ALMOST FULL        │
│  Gemini: [49/50] ✅         │
│  ApiFreeLLM: [0/100]        │
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Request #50
             ▼
┌─────────────────────────────┐
│   GEMINI LIMIT HIT          │
│  Gemini: [50/50] ⚠️ FULL   │
│  ApiFreeLLM: [0/100]        │
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Request #51
             ▼
┌─────────────────────────────┐
│   USING APIFREELLM          │
│  Gemini: [50/50] ⚠️ FULL   │
│  ApiFreeLLM: [1/100] ✅    │
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Requests #52-100
             ▼
┌─────────────────────────────┐
│   APIFREELLM LIMIT HIT      │
│  Gemini: [50/50] ⚠️ FULL   │
│  ApiFreeLLM: [100/100] ⚠️ FULL
│  Grok: [0/∞]                │
└────────────┬────────────────┘
             │
             │ Request #101
             ▼
┌─────────────────────────────┐
│   USING GROK (Last Resort)  │
│  Gemini: [50/50] ⚠️ FULL   │
│  ApiFreeLLM: [100/100] ⚠️ FULL
│  Grok: [1/∞] ✅             │
└─────────────────────────────┘
```

## Error Propagation

```
External API Error
        │
        ▼
Provider throws Exception
        │
        ▼
Provider catches, returns Result.Error
        │
        ▼
MultiApiManager receives Result.Error
        │
        ▼
┌───────────────────────────────────┐
│ Log error for this provider        │
│ Continue to next provider in chain │
└────────────┬──────────────────────┘
             │
    ┌────────┴────────┐
    │                 │
    ▼                 ▼
Next Provider    All Providers Failed
Succeeds              │
    │                 ▼
    │         Return Result.Error with:
    │         - Full error chain
    │         - Diagnostic info
    │         - Last provider tried
    │         - Specific error messages
    │                 │
    └────────┬────────┘
             │
             ▼
        Activity catches Result.Error
             │
             ▼
        showError(message)
             │
             ▼
        Display user-friendly message
             │
             ▼
        Log full diagnostic details
```

---

**Visual Reference Version**: 1.0  
**Last Updated**: April 2026
