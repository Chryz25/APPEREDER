# 🚀 Multi-API Fallback System - Setup Guide

## Overview

This application now uses a **smart multi-API fallback system** with automatic provider switching based on rate limits:

```
Primary   →  Backup     →  Last Resort
Gemini    →  ApiFreeLLM →  Grok
(Best)       (Unlimited)   (Paid)
```

## 🎯 How It Works

### Fallback Priority
1. **Gemini** (primary) - Best quality, rate-limited to configurable threshold
2. **ApiFreeLLM** (backup) - Unlimited free tier, good quality
3. **Grok** (fallback) - Paid/limited, used only when others are exhausted

### Automatic Switching Logic
```kotlin
if (Gemini available AND under rate limit)
    → Use Gemini
else if (Gemini rate limit reached AND ApiFreeLLM available)
    → Use ApiFreeLLM
else if (ApiFreeLLM rate limit reached AND Grok available)
    → Use Grok
else if (all providers failed)
    → Return error with diagnostic info
```

## 📋 Files Added/Modified

### New Files Created
- **`MultiApiConfig.kt`** - Configuration for all API keys and endpoints
- **`ApiProviders.kt`** - Three provider implementations (Gemini, ApiFreeLLM, Grok)
- **`MultiApiManager.kt`** - Manager with fallback logic and rate limit tracking

### Modified Files
- **`GroqQuizActivity.kt`** - Replaced single Grok API calls with multi-API manager

## ⚙️ Setup Instructions

### Step 1: Get API Keys

#### Gemini (Primary)
1. Go to [ai.google.dev](https://ai.google.dev/)
2. Click "Get API Key" or "Get started with Gemini API"
3. Create a new project or select existing
4. Copy your API key

#### ApiFreeLLM (Backup)
1. Go to [apifreellm.com](https://www.apifreellm.com/)
2. Sign up for free account
3. Navigate to API keys section
4. Copy your API key (unlimited free tier!)

#### Grok (Last Resort)
1. Already configured with existing key
2. To update: Go to [console.groq.com](https://console.groq.com)
3. Copy your API key

### Step 2: Update Configuration

Edit `/app/src/main/java/com/example/a404/MultiApiConfig.kt`:

```kotlin
// ── Gemini Configuration (Primary) ─────────────────────────────────────────
const val GEMINI_API_KEY = "paste-your-gemini-key-here"

// ── ApiFreeLLM Configuration (Backup/Unlimited) ───────────────────────────
const val APIFREELLM_API_KEY = "paste-your-apifreellm-key-here"

// ── Grok Configuration (Last Resort) ───────────────────────────────────────
const val GROK_API_KEY = "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"
```

### Step 3: Adjust Rate Limits (Optional)

In `MultiApiConfig.kt`:

```kotlin
// Default: 50 requests before switching to ApiFreeLLM
const val RATE_LIMIT_THRESHOLD_GEMINI = 50

// Default: 100 requests before switching to Grok
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 100
```

## 📊 Monitoring & Debugging

### View Request Statistics
```kotlin
// In your code:
val counts = MultiApiManager.getRequestCounts()
// Output: {gemini: 15, apifreellm: 3, grok: 0}

val limits = MultiApiManager.getRateLimitStatus()
// Output: {gemini: false, apifreellm: false, grok: false}
```

### View Status Report
```kotlin
MultiApiManager.logStatus()
// Prints formatted status with all metrics
```

### Check Last Error
```kotlin
val lastProvider = MultiApiManager.getLastAttemptedProvider()
val lastError = MultiApiManager.getLastErrorMessage()
```

### View Logs
Filter Logcat for:
- `MultiApiManager` - Multi-API system logs
- `GroqQuizActivity` - Activity-level logs

## 🔄 Rate Limit Management

### Automatic Reset
Rate limits are tracked per session. To reset manually:

```kotlin
MultiApiManager.resetRateLimits()  // Use on app restart or daily reset
```

### Custom Thresholds

Edit `MultiApiConfig.kt`:

```kotlin
// More generous (fewer switches)
const val RATE_LIMIT_THRESHOLD_GEMINI = 100
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 200

// More aggressive (more switches)
const val RATE_LIMIT_THRESHOLD_GEMINI = 20
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 50
```

## 🐛 Troubleshooting

### "All providers exhausted"
- Check all three API keys are valid in `MultiApiConfig.kt`
- Verify at least one API key is properly configured
- Check internet connection
- Review logs for specific error messages

### Switches to Grok immediately
- Gemini API key not set or invalid
- Check `MultiApiConfig.GEMINI_API_KEY`
- Verify Gemini account has API access enabled

### Excessive API switching
- Reduce rate limit thresholds in `MultiApiConfig.kt`
- Allow more requests per provider before switching

### Specific provider failing
- Check API key configuration
- Verify API credentials are active on provider's dashboard
- Review provider's status page for outages
- Check network/firewall settings

## 📝 Code Examples

### Using MultiApiManager directly
```kotlin
val result = MultiApiManager.generateText(
    prompt = "Your question here",
    systemMessage = "You are a helpful assistant",
    temperature = 0.7f
)

when (result) {
    is Result.Success -> {
        println("Response: ${result.data}")
    }
    is Result.Error -> {
        println("Error: ${result.message}")
    }
}
```

### Request Flow Example
```
User clicks "Generate Quiz"
    ↓
GroqQuizActivity.callGroq()
    ↓
MultiApiManager.generateText()
    ↓
[1] Try Gemini (count: 25/50)
    ✅ Success → return to activity
    
[If Gemini fails or at limit]
[2] Try ApiFreeLLM (count: 5/100)
    ✅ Success → return to activity
    
[If ApiFreeLLM fails or at limit]
[3] Try Grok (count: 0/∞)
    ✅ Success → return to activity
    
[If all fail]
❌ Return error: "All providers exhausted"
```

## 🎓 Why This Architecture?

### Reliability
- **Automatic fallback** ensures your app keeps working even if one provider fails
- **Multiple providers** reduces dependency on single service

### Cost Optimization
- **Free Gemini tier** for quality responses
- **Unlimited ApiFreeLLM** as backup
- **Grok only as last resort** to minimize costs

### Scalability
- **Rate limit tracking** helps optimize provider usage
- **Easy to add new providers** - just implement `IApiProvider`

### User Experience
- **Transparent switching** - users don't notice provider changes
- **Seamless operation** - app continues working with fallback providers
- **Better error messages** - diagnostics when all providers fail

## 🔐 Security Notes

- **Never commit API keys** to version control
- **Use environment variables** in production (consider BuildConfig)
- **Rotate keys regularly** for production deployments
- **Monitor API usage** for suspicious patterns

## 📞 Support

For issues:
1. Check logs: `adb logcat | grep "MultiApiManager"`
2. Verify all API keys in `MultiApiConfig.kt`
3. Test with curl/Postman to verify API credentials
4. Review specific provider's API documentation

---

**Last Updated**: April 2026  
**Version**: 1.0  
**Status**: Production Ready
