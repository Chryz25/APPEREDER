# Supabase Setup Guide for 404 App (V20)

Follow these steps **once** to connect your app to Supabase.

---

## Step 1 — Create a Supabase Project

1. Go to https://supabase.com and sign in (or create a free account).
2. Click **New Project** → fill in a name, password, and region → **Create Project**.
3. Wait ~1 minute for provisioning to complete.

---

## Step 2 — Get Your Credentials

1. In your project dashboard, go to **Settings → API**.
2. Copy these two values:
   - **Project URL** → looks like `https://abcxyz123.supabase.co`
   - **anon / public** key → a long JWT string
3. Open `app/src/main/java/com/example/a404/SupabaseConfig.kt` and paste them:

```kotlin
const val SUPABASE_URL      = "https://abcxyz123.supabase.co"   // ← your URL
const val SUPABASE_ANON_KEY = "eyJhbGci..."                     // ← your anon key
```

---

## Step 3 — Create the Storage Bucket

1. In the Supabase dashboard, click **Storage** in the left sidebar.
2. Click **New Bucket**.
3. Name it exactly: **`books`** (must match `SupabaseConfig.BUCKET_NAME`).
4. Toggle **Public bucket** → ON (so PDFs stream without authentication).
5. Click **Create Bucket**.

### Upload PDFs

Organize your PDFs in this folder structure inside the `books` bucket:

```
books/
  BS Computer Science/
    1st Year/
      Mathematics.pdf
      Programming Fundamentals.pdf
    2nd Year/
      Data Structures.pdf
  BS Information Technology/
    1st Year/
      Web Development.pdf
  BS Multimedia Computing/
    1st Year/
      Digital Arts.pdf
  BS Applied Computer Technology/
    1st Year/
      Computer Hardware.pdf
    2nd Year/
      Networking.pdf
```

> **Important:** Folder names must match **exactly** what you enter in the `books` database table
> under the `course` and `year` columns (see Step 4).

---

## Step 4 — Create the Database Table

1. In the Supabase dashboard, click **SQL Editor**.
2. Click **New Query** and paste the following SQL, then click **Run**:

```sql
-- Create the books metadata table
CREATE TABLE IF NOT EXISTS books (
    id          UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
    title       TEXT        NOT NULL,
    author      TEXT        DEFAULT '',
    description TEXT        DEFAULT '',
    course      TEXT        NOT NULL,
    year        TEXT        NOT NULL,
    file_path   TEXT        NOT NULL,   -- path inside the 'books' bucket
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Allow the app to read books (anon key access)
ALTER TABLE books ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read" ON books
    FOR SELECT USING (true);

-- Optional: index for fast course+year lookups
CREATE INDEX IF NOT EXISTS idx_books_course_year ON books(course, year);
```

---

## Step 5 — Add Your Books to the Database

For each PDF you uploaded in Step 3, insert a row into the `books` table.

**Method A — SQL Editor (recommended for bulk upload):**

```sql
INSERT INTO books (title, author, description, course, year, file_path) VALUES
-- BS Computer Science / 1st Year
('Mathematics', 'Prof. Cruz', 'Fundamentals of college mathematics.', 'BS Computer Science', '1st Year', 'BS Computer Science/1st Year/Mathematics.pdf'),
('Programming Fundamentals', 'Prof. Reyes', 'Intro to programming concepts.', 'BS Computer Science', '1st Year', 'BS Computer Science/1st Year/Programming Fundamentals.pdf'),

-- BS Computer Science / 2nd Year
('Data Structures', 'Prof. Santos', 'Arrays, trees, graphs and algorithms.', 'BS Computer Science', '2nd Year', 'BS Computer Science/2nd Year/Data Structures.pdf'),

-- BS Information Technology / 1st Year
('Web Development', 'Prof. Garcia', 'HTML, CSS, and JavaScript basics.', 'BS Information Technology', '1st Year', 'BS Information Technology/1st Year/Web Development.pdf'),

-- Add more rows following the same pattern...
('Computer Hardware', 'Prof. Lim', 'PC components and assembly.', 'BS Applied Computer Technology', '1st Year', 'BS Applied Computer Technology/1st Year/Computer Hardware.pdf');
```

**Method B — Table Editor UI:**
1. Go to **Table Editor → books → Insert Row**.
2. Fill in each field manually.

### Column reference

| Column      | Example value                                              | Notes                          |
|-------------|------------------------------------------------------------|--------------------------------|
| title       | `Data Structures`                                          | Shown in the app               |
| author      | `Prof. Santos`                                             | Can be blank                   |
| description | `Arrays, trees, graphs and algorithms.`                    | Can be blank                   |
| course      | `BS Computer Science`                                      | **Must match app exactly**     |
| year        | `2nd Year`                                                 | **Must match app exactly**     |
| file_path   | `BS Computer Science/2nd Year/Data Structures.pdf`         | Path inside the `books` bucket |

### Valid course values (must be exact)
- `BS Computer Science`
- `BS Information Technology`
- `BS Multimedia Computing`
- `BS Applied Computer Technology`

### Valid year values (must be exact)
- `1st Year`
- `2nd Year`
- `3rd Year`
- `4th Year`

> **Note:** `BS Applied Computer Technology` only supports `1st Year` and `2nd Year`.

---

## Step 6 — Test the Connection

1. Build and run the app on a device or emulator with internet access.
2. On the **Choosing Phase** screen, select a course and year.
3. The book card should appear with data fetched from Supabase.
4. Tap the card → confirm → Continue → Library.

### Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| "Could not load books" | Wrong URL or anon key | Double-check `SupabaseConfig.kt` |
| Book card empty | No row in `books` table for that course+year | Insert the missing row in Step 5 |
| PDF doesn't open | Wrong `file_path` in database | Must match exact storage path |
| 401 / 403 error | RLS not configured or wrong key | Re-run the SQL in Step 4 |
| PDF 400 error | Bucket is private | Set bucket to Public in Storage |

---

## Architecture Summary

```
App (Android Kotlin)
  │
  ├── SupabaseConfig.kt        ← your credentials live here
  ├── SupabaseRepository.kt    ← all Supabase REST calls
  │
  ├── ChoosingPhaseActivity    → queries books table (course + year)
  ├── LibraryDetailsActivity   → queries books table (list all PDFs for slot)
  └── BrowseActivity           → queries books table (user's course/year)
         │
         ▼
  Supabase REST API  ←→  PostgreSQL `books` table
  Supabase Storage   ←→  `books` bucket (public PDF files)
```
