# 🏗️ Multi-API System Architecture

## System Overview

```
┌──────────────────────────────────────────────────────────────────────┐
│                          UI Layer                                    │
│  (GroqQuizActivity - Quiz Generation & Display)                      │
└────────────────────┬─────────────────────────────────────────────────┘
                     │
                     │ calls callGroq(prompt)
                     │
┌────────────────────▼─────────────────────────────────────────────────┐
│                    MultiApiManager (Singleton)                        │
│  - Manages fallback chain                                             │
│  - Tracks rate limits per provider                                    │
│  - Routes requests intelligently                                      │
│  - Handles errors gracefully                                          │
└────────────────────┬─────────────────────────────────────────────────┘
                     │
        ┌────────────┼────────────┐
        │            │            │
        ▼            ▼            ▼
    ┌─────────┐  ┌──────────┐  ┌──────┐
    │ Gemini  │  │ApiFreeLLM│  │ Grok │
    │Provider │  │Provider  │  │Provider
    └────┬────┘  └────┬─────┘  └───┬──┘
         │            │            │
         │ (50 req)   │ (100 req)  │ (∞)
         │            │            │
    ┌────┴────────────┴────────────┴────┐
    │                                    │
    │  External API Services             │
    │  - google.generativelanguage API   │
    │  - apifreellm.com API              │
    │  - api.groq.com API                │
    └────────────────────────────────────┘
```

## Component Architecture

### 1. MultiApiConfig.kt
**Purpose**: Centralized configuration

```kotlin
object MultiApiConfig {
    // API Keys & Endpoints
    const val GEMINI_API_KEY
    const val GEMINI_API_URL
    
    const val APIFREELLM_API_KEY
    const val APIFREELLM_API_URL
    
    const val GROK_API_KEY
    const val GROK_API_URL
    
    // Rate Limits
    const val RATE_LIMIT_THRESHOLD_GEMINI
    const val RATE_LIMIT_THRESHOLD_APIFREELLM
    
    // Timeouts
    const val CONNECT_TIMEOUT_SECONDS
    const val READ_TIMEOUT_SECONDS
    
    enum class ApiProvider
}
```

### 2. ApiProviders.kt
**Purpose**: API-specific implementations

```
IApiProvider (Interface)
    ├── GeminiProvider
    │   ├── Uses: Google Generative AI API
    │   ├── Format: JSON with generationConfig
    │   └── Response: candidates[0].content.parts[0].text
    │
    ├── ApiFreeLLMProvider
    │   ├── Uses: OpenAI-compatible API
    │   ├── Format: Standard OpenAI chat format
    │   └── Response: choices[0].message.content
    │
    └── GrokProvider
        ├── Uses: Groq API
        ├── Format: Standard OpenAI chat format
        └── Response: choices[0].message.content
```

**Each Provider**:
- Handles own HTTP client setup
- Converts prompt to provider's format
- Parses provider's response format
- Returns `Result<String>` (Success or Error)

### 3. MultiApiManager.kt
**Purpose**: Orchestration & fallback logic

```kotlin
object MultiApiManager {
    
    // State Management
    private val geminiProvider: GeminiProvider
    private val apiFreeLLMProvider: ApiFreeLLMProvider
    private val grokProvider: GrokProvider
    
    // Rate Limit Tracking
    private val requestCounters: Map<String, AtomicInteger>
    private val rateLimitReachedFlags: Map<String, Boolean>
    
    // Public Interface
    suspend fun generateText(): Result<String>
    fun getRequestCounts(): Map<String, Int>
    fun getRateLimitStatus(): Map<String, Boolean>
    fun resetRateLimits()
    fun logStatus()
}
```

**Fallback Algorithm**:
```
For each provider in [Gemini, ApiFreeLLM, Grok]:
    1. Skip if rate limit already reached
    2. Skip if provider not configured
    3. Call provider.generateText(prompt)
    4. If Success:
       - Increment request counter
       - Check if rate limit reached
       - Return result
    5. If Error:
       - Save error message
       - Continue to next provider
       
If all providers fail:
    Return Error with full diagnostic info
```

### 4. GroqQuizActivity.kt (Modified)
**Purpose**: UI layer using multi-API system

```kotlin
class GroqQuizActivity {
    private val multiApiManager = MultiApiManager
    
    private fun callGroq(prompt: String, onSuccess: (String) -> Unit) {
        // 1. Create background thread
        val thread = Thread {
            try {
                // 2. Call MultiApiManager (with coroutine blocking)
                val result = kotlin.runBlocking {
                    multiApiManager.generateText(
                        prompt = prompt,
                        systemMessage = "...",
                        temperature = 0.7f
                    )
                }
                
                // 3. Return to UI thread
                runOnUiThread {
                    when (result) {
                        is Result.Success -> onSuccess(result.data)
                        is Result.Error -> showError(result.message)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { showError(e.message) }
            }
        }
        thread.start()
    }
}
```

## Data Flow

### Successful Request

```
User Action
    ↓
callGroq(prompt)
    ↓
Create background thread
    ↓
MultiApiManager.generateText()
    ↓
Check Gemini: available & under limit?
    YES ↓
    GeminiProvider.generateText()
        ↓
    Make HTTP request to Google API
        ↓
    Parse response
        ↓
    Return Result.Success(text)
    ↓
Increment Gemini counter
    ↓
Return to UI thread
    ↓
onSuccess(text) → Update UI
    ↓
Display response
```

### Rate Limit Failover

```
User Action
    ↓
callGroq(prompt)
    ↓
MultiApiManager.generateText()
    ↓
Check Gemini: available & under limit?
    NO (limit reached) ↓
    Skip Gemini
    ↓
Check ApiFreeLLM: available & under limit?
    YES ↓
    ApiFreeLLMProvider.generateText()
        ↓
    Make HTTP request to ApiFreeLLM
        ↓
    Parse response
        ↓
    Return Result.Success(text)
    ↓
Increment ApiFreeLLM counter
    ↓
Return to UI thread
    ↓
onSuccess(text) → Update UI
```

## Rate Limiting Mechanism

### Counter Tracking
```kotlin
requestCounters: Map<String, AtomicInteger> = {
    "gemini" → AtomicInteger(0),
    "apifreellm" → AtomicInteger(0),
    "grok" → AtomicInteger(0)
}
```

### Threshold Checking
```
Before request:
    if (requestCounter >= RATE_LIMIT_THRESHOLD)
        rateLimitReachedFlag = true
        Skip provider
    else
        Proceed with request

After successful request:
    requestCounter++
    if (requestCounter >= RATE_LIMIT_THRESHOLD)
        rateLimitReachedFlag = true
        Log warning
```

### Reset Strategy
```
Session-based reset:
    - Counters reset on app restart
    - Manual reset available: MultiApiManager.resetRateLimits()
    
Optional daily reset:
    - Can be implemented with WorkManager
    - Reset at midnight or on app launch
```

## Error Handling Strategy

### Layer 1: Provider Level
Each provider catches exceptions and returns `Result.Error`:
```kotlin
try {
    // Make API call
} catch (e: Exception) {
    Result.Error(e, "Provider-specific error message")
}
```

### Layer 2: Manager Level
MultiApiManager handles provider errors:
```kotlin
when (result) {
    is Result.Success → return result
    is Result.Error → continue to next provider
}
```

### Layer 3: Activity Level
GroqQuizActivity handles manager errors:
```kotlin
when (result) {
    is Result.Success → onSuccess(data)
    is Result.Error → showError(message)
}
```

## Configuration Examples

### Conservative (Few Switches)
```kotlin
const val RATE_LIMIT_THRESHOLD_GEMINI = 100
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 200
// Uses same provider for longer
```

### Aggressive (Frequent Switches)
```kotlin
const val RATE_LIMIT_THRESHOLD_GEMINI = 10
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 20
// Distributes load across providers
```

### Testing (Immediate Fallback)
```kotlin
const val RATE_LIMIT_THRESHOLD_GEMINI = 1
const val RATE_LIMIT_THRESHOLD_APIFREELLM = 1
// For testing fallback chain
```

## Extension Points

### Adding a New Provider

1. **Create provider class** in ApiProviders.kt:
```kotlin
class NewProvider : IApiProvider {
    override val providerName = "NewProvider"
    override val isConfigured = true
    
    override suspend fun generateText(...): Result<String> {
        // Implementation
    }
}
```

2. **Add to config** in MultiApiConfig.kt:
```kotlin
const val NEWPROVIDER_API_KEY = "..."
const val NEWPROVIDER_API_URL = "..."
const val NEWPROVIDER_MODEL = "..."
const val RATE_LIMIT_THRESHOLD_NEWPROVIDER = 50
```

3. **Update manager** in MultiApiManager.kt:
```kotlin
private val newProvider = NewProvider()

private val providers = listOf(
    Triple(geminiProvider, "gemini", ...),
    Triple(newProvider, "newprovider", ...),
    Triple(grokProvider, "grok", ...)
)
```

## Performance Considerations

### Memory
- Each provider has own OkHttpClient: ~1-2 MB
- Counters use AtomicInteger: negligible
- Total overhead: ~5-10 MB

### Network
- Timeouts configured: 20s connect, 60s read, 20s write
- Fallback adds retry latency
- First provider attempt: ~100-500ms
- Fallback retry: additional ~100-500ms

### Concurrency
- Thread-safe counters (AtomicInteger)
- Stateless provider instances
- Safe for concurrent requests

## Monitoring & Observability

### Built-in Logging
```
I/MultiApiManager: 🔄 Attempting Gemini (request #1/50)
I/MultiApiManager: ✅ Gemini succeeded
I/MultiApiManager: ⚠️  Gemini rate limit reached
I/MultiApiManager: ⏭️  Skipping gemini
```

### Programmatic Access
```kotlin
MultiApiManager.getRequestCounts()      // Request statistics
MultiApiManager.getRateLimitStatus()    // Rate limit flags
MultiApiManager.getLastAttemptedProvider()  // Last provider used
MultiApiManager.getLastErrorMessage()   // Last error
MultiApiManager.logStatus()             // Full status report
```

## Security Considerations

### API Key Management
- Keys stored in code (dev) → use BuildConfig for prod
- Consider EncryptedSharedPreferences for storage
- Never log full keys

### Rate Limiting
- Per-provider, not per-user
- Client-side only (not enforced by backend)
- Implement server-side quota for production

### Error Messages
- Don't expose provider details to users
- Log full errors internally
- Show generic messages to users

---

**Architecture Version**: 1.0  
**Last Updated**: April 2026  
**Status**: Production Ready
