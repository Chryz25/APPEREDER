# 🔑 API Key Setup Guide

Complete guide to configure all three AI providers for your mobile app.

---

## 🚀 Quick Start (5 minutes)

### Step 1: Get Gemini API Key (Recommended Primary)
1. Visit: https://ai.google.dev/
2. Click "Get API Key" → "Create API key in new project"
3. Copy the generated key
4. Paste into `MultiApiConfig.kt`:
```kotlin
const val GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"
```

### Step 2: Get ApiFreeLLM API Key (Recommended Backup)
1. Visit: https://www.apifreellm.com/
2. Sign up for free account
3. Go to Dashboard → API Keys
4. Create new key
5. Paste into `MultiApiConfig.kt`:
```kotlin
const val APIFREELLM_API_KEY = "YOUR_APIFREELLM_API_KEY_HERE"
```

### Step 3: Get Grok API Key (Last Resort)
1. Visit: https://console.groq.com
2. Create account (free tier available)
3. Go to API Keys section
4. Generate new key
5. Paste into `MultiApiConfig.kt`:
```kotlin
const val GROK_API_KEY = "YOUR_GROK_API_KEY_HERE"
```

---

## ⚙️ Complete Setup

### Gemini (Google AI)
- **Best for:** Primary provider (fastest, best quality)
- **Free tier:** 15 requests/minute, generous monthly quota
- **Website:** https://ai.google.dev/
- **Setup:**
  1. Go to Google AI Studio
  2. Create new API project
  3. Enable Generative AI API
  4. Create API key (no OAuth needed)
- **Rate limit threshold:** 50 requests (configurable)

### ApiFreeLLM
- **Best for:** Backup provider (unlimited free tier)
- **Free tier:** Unlimited requests (community supported)
- **Website:** https://www.apifreellm.com/
- **Setup:**
  1. Register for free account
  2. Verify email
  3. Navigate to Dashboard
  4. Create API Key
- **Rate limit threshold:** 100 requests (configurable)

### Grok (XAI)
- **Best for:** Last resort provider (guaranteed fallback)
- **Free tier:** Limited (paid plans available)
- **Website:** https://console.groq.com
- **Setup:**
  1. Create Groq account
  2. Go to Console → API Keys
  3. Generate new key
  4. Copy and save securely
- **Rate limit threshold:** Unlimited (configured as last resort)

---

## 🔒 Security Best Practices

### ❌ DO NOT:
```kotlin
// ❌ NEVER hardcode real keys in source code
const val GROK_API_KEY = "gsk_actualKey123456789"

// ❌ NEVER commit keys to git
// Use .gitignore for config files containing real keys

// ❌ NEVER share keys in messages or files
```

### ✅ DO:
```kotlin
// ✅ Use placeholder during development
const val GROK_API_KEY = "YOUR_GROK_API_KEY"

// ✅ Add actual key only in secure build environment
// ✅ Use environment variables for CI/CD
// ✅ Store keys in secure key management system

// ✅ Rotate keys periodically (monthly recommended)
// ✅ Use separate keys for dev/staging/prod
```

---

## 🧪 Testing Your Setup

### Test 1: Check Configuration
```kotlin
// In GroqQuizActivity or any activity:
val isGeminiReady = MultiApiConfig.GEMINI_API_KEY != "YOUR_GEMINI_API_KEY"
val isApiFreeLLMReady = MultiApiConfig.APIFREELLM_API_KEY != "YOUR_APIFREELLM_API_KEY"
val isGrokReady = MultiApiConfig.GROK_API_KEY != "YOUR_GROK_API_KEY"

Log.d("APISetup", "Gemini: $isGeminiReady, ApiFreeLLM: $isApiFreeLLMReady, Grok: $isGrokReady")
```

### Test 2: Generate Quiz
1. Open app
2. Select any book
3. Tap "Take a Quiz"
4. Check logcat for messages:
   ```
   ✅ Gemini succeeded
   // OR
   ✅ ApiFreeLLM succeeded
   // OR
   ✅ Grok succeeded
   ```

### Test 3: Test Fallback Chain
1. Disable Gemini: Set `GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"`
2. Rebuild and test
3. Should see: `✅ ApiFreeLLM succeeded`
4. Disable ApiFreeLLM too
5. Should see: `✅ Grok succeeded`

### Test 4: Check Rate Limits
1. Generate 51 quizzes (or set threshold to 1 for testing)
2. Should see: `⚠️ Gemini rate limit reached`
3. Next quiz should use ApiFreeLLM

---

## 🐛 Troubleshooting

### Issue: "All providers exhausted"

**Cause:** All API keys are invalid or unconfigured

**Fix:**
1. Check all three keys are set correctly
2. Verify no extra spaces or characters
3. Test keys individually on provider's API console
4. Check API permissions in provider dashboard

### Issue: "HTTP 401" Error

**Cause:** Invalid or expired API key

**Fix:**
1. Verify key hasn't been rotated
2. Check key has necessary permissions
3. Generate new key from provider's dashboard
4. Wait 30 seconds after key creation (some providers need time)

### Issue: "HTTP 429" Error (Rate Limited)

**Cause:** Too many requests to single provider

**Fix:**
1. This is expected - app should fallback automatically
2. Check logcat to see fallback working
3. If all providers rate-limited:
   - Wait before retrying
   - Increase rate limit thresholds (if testing locally)
   - Use fewer quiz generations per day

### Issue: Quiz generating but answers are wrong

**Cause:** API key has low-quality model configured

**Fix:**
1. Check model names in MultiApiConfig
2. Verify models still available on provider
3. Try with Gemini first (best quality)
4. Check API tier (free tier might have lower quality)

### Issue: "Cannot connect to API"

**Cause:** Network issue or provider down

**Fix:**
1. Check internet connection
2. Test provider directly: Use `curl` to test API endpoint
3. Check if provider has status page
4. Fallback to next provider should work automatically
5. Check logcat for specific error

---

## 📊 Monitoring

### Check Provider Usage
In GroqQuizActivity, after generating quiz:
```kotlin
multiApiManager.logStatus()
// Outputs:
// ╔════════════════════════════════════════╗
// ║       MULTI-API STATUS REPORT          ║
// ╠════════════════════════════════════════╣
// ║ Gemini:     42 requests | Rate limit: false
// ║ ApiFreeLLM:  8 requests | Rate limit: false
// ║ Grok:        0 requests | Rate limit: false
// ║ Last provider: Gemini
// ║ Last error: None
// ╚════════════════════════════════════════╝
```

### Expected Behavior
1. **First quiz:** Uses Gemini (primary)
2. **Subsequent quizzes:** Continue with Gemini until threshold (50)
3. **After 50 quizzes:** Switches to ApiFreeLLM
4. **After 100 more quizzes:** Switches to Grok
5. **Grok always available:** Last resort (no limit)

---

## 🔄 Rotation & Updates

### Monthly Key Rotation (Recommended)
```
Week 1: Generate new key from provider
Week 2: Update MultiApiConfig with new key
Week 3: Delete old key from provider
Week 4: Monitor for issues
```

### Emergency Key Rotation
If key might be compromised:
1. Immediately delete key from provider dashboard
2. Generate new key
3. Update MultiApiConfig
4. Rebuild and redeploy app
5. Monitor API usage

---

## 📚 Additional Resources

- **Gemini Docs:** https://ai.google.dev/docs
- **ApiFreeLLM Docs:** https://www.apifreellm.com/docs
- **Grok Docs:** https://console.groq.com/docs

---

**Need help?** Check `BUG_FIX_REPORT.md` for troubleshooting steps.
