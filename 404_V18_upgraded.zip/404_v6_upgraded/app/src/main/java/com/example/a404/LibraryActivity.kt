package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

class LibraryActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_1)

        val chosenBookCard   = findViewById<MaterialCardView>(R.id.chosen_book_card)
        val chosenBookCover  = findViewById<ImageView>(R.id.chosen_book_cover)
        val chosenBookTitle  = findViewById<TextView>(R.id.chosen_book_title)
        val tvChosenAuthor   = findViewById<TextView>(R.id.chosen_book_author)
        val tvChosenCourse   = findViewById<TextView>(R.id.chosen_book_course)
        val tvChosenChapters = findViewById<TextView>(R.id.chosen_book_chapters)

        val prefs            = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val selectedBook     = prefs.getString("SELECTED_BOOK",     null)
        val selectedAuthor   = prefs.getString("SELECTED_AUTHOR",   "")
        val selectedCourse   = prefs.getString("SELECTED_COURSE",   "")
        val selectedYear     = prefs.getString("SELECTED_YEAR",     "")
        val selectedChapters = prefs.getInt   ("SELECTED_CHAPTERS",  0)

        if (selectedBook != null) {
            chosenBookTitle.text  = selectedBook
            tvChosenAuthor.text   = "by $selectedAuthor"
            tvChosenCourse.text   = "$selectedCourse · $selectedYear"
            tvChosenChapters.text = "$selectedChapters Chapters"
            chosenBookCard.visibility = View.VISIBLE

            // Load real book cover image
            val coverUrl = "https://covers.openlibrary.org/b/title/${selectedBook.replace(" ", "+")}-M.jpg?default=false"
            Glide.with(this)
                .load(coverUrl)
                .placeholder(R.drawable.ic_logo)
                .error(R.drawable.ic_logo)
                .centerCrop()
                .into(chosenBookCover)

            chosenBookCard.setOnClickListener {
                startActivity(
                    Intent(this, LibraryDetailsActivity::class.java)
                        .putExtra("BOOK_TITLE", selectedBook)
                )
            }
        }

        // ── Search button logic ───────────────────────────────────────────────
        val searchIcon      = findViewById<ImageView>(R.id.search_icon)
        val searchContainer = findViewById<CardView>(R.id.search_bar_container)
        val searchEditText  = findViewById<EditText>(R.id.search_edit_text)
        var searchVisible   = false

        searchIcon.setOnClickListener {
            searchVisible = !searchVisible
            searchContainer.visibility = if (searchVisible) View.VISIBLE else View.GONE
            if (searchVisible) {
                searchEditText.requestFocus()
            } else {
                searchEditText.setText("")
                // Reset filter — show all cards again
                chosenBookCard.visibility = if (selectedBook != null) View.VISIBLE else View.GONE
            }
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim()?.lowercase() ?: ""
                if (selectedBook != null) {
                    val matches = selectedBook.lowercase().contains(query) ||
                                  (selectedAuthor?.lowercase()?.contains(query) == true) ||
                                  (selectedCourse?.lowercase()?.contains(query) == true)
                    chosenBookCard.visibility = if (query.isEmpty() || matches) View.VISIBLE else View.GONE
                }
            }
        })

        // ── Hamburger / Settings button ───────────────────────────────────────
        findViewById<ImageView>(R.id.menu_button).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
