package com.example.a404

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide

class AboutUsActivity : ComponentActivity() {

    // Which member slot is being edited (1-4)
    private var pendingMemberSlot = 0

    private lateinit var photos: Array<ImageView>

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && pendingMemberSlot in 1..4) {
                // Persist permission so the URI survives restarts
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) { /* some providers don't support it */ }

                savePhotoUri(pendingMemberSlot, uri.toString())
                loadPhoto(pendingMemberSlot, uri.toString())
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_about_us)

        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        photos = arrayOf(
            findViewById(R.id.photo_member_1),
            findViewById(R.id.photo_member_2),
            findViewById(R.id.photo_member_3),
            findViewById(R.id.photo_member_4)
        )

        val rows = arrayOf(
            findViewById<LinearLayout>(R.id.member_1_row),
            findViewById(R.id.member_2_row),
            findViewById(R.id.member_3_row),
            findViewById(R.id.member_4_row)
        )

        // Load persisted photos
        for (slot in 1..4) {
            val saved = loadPhotoUri(slot)
            if (!saved.isNullOrEmpty()) loadPhoto(slot, saved)
        }

        // Tap row → pick image for that member
        rows.forEachIndexed { i, row ->
            row.setOnClickListener {
                pendingMemberSlot = i + 1
                pickImageLauncher.launch("image/*")
            }
        }
    }

    private fun loadPhoto(slot: Int, uriString: String) {
        val imageView = photos.getOrNull(slot - 1) ?: return
        Glide.with(this)
            .load(Uri.parse(uriString))
            .circleCrop()
            .placeholder(R.drawable.bg_circle_purple)
            .error(R.drawable.bg_circle_purple)
            .into(imageView)
    }

    private fun savePhotoUri(slot: Int, uriString: String) {
        getSharedPreferences("TeamPhotos", Context.MODE_PRIVATE)
            .edit()
            .putString("member_photo_$slot", uriString)
            .apply()
    }

    private fun loadPhotoUri(slot: Int): String? =
        getSharedPreferences("TeamPhotos", Context.MODE_PRIVATE)
            .getString("member_photo_$slot", null)
}
