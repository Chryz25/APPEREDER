package com.example.a404

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

class DownloadActivity : ComponentActivity() {

    // Map download item titles to cover URLs
    private val downloadItems = listOf(
        "Data Structures & Algorithms"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.download_1)

        // Load cover image for the download item
        val cover1 = findViewById<ImageView>(R.id.download_cover_1)
        Glide.with(this)
            .load("https://covers.openlibrary.org/b/title/Data+Structures+%26+Algorithms-M.jpg?default=false")
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(cover1)

        // ── Search button logic ───────────────────────────────────────────────
        val searchIcon      = findViewById<ImageView>(R.id.search_icon)
        val searchContainer = findViewById<CardView>(R.id.search_bar_container)
        val searchEditText  = findViewById<EditText>(R.id.search_edit_text)
        val downloadItem1   = findViewById<MaterialCardView>(R.id.download_item_1)
        var searchVisible   = false

        searchIcon.setOnClickListener {
            searchVisible = !searchVisible
            searchContainer.visibility = if (searchVisible) View.VISIBLE else View.GONE
            if (searchVisible) {
                searchEditText.requestFocus()
            } else {
                searchEditText.setText("")
                downloadItem1?.visibility = View.VISIBLE
            }
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim()?.lowercase() ?: ""
                if (query.isEmpty()) {
                    downloadItem1?.visibility = View.VISIBLE
                } else {
                    val title = "Data Structures & Algorithms"
                    downloadItem1?.visibility =
                        if (title.lowercase().contains(query)) View.VISIBLE else View.GONE
                }
            }
        })

        // ── Hamburger / Settings button ───────────────────────────────────────
        findViewById<ImageView>(R.id.menu_button).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupNavigation()
    }

    private fun setupNavigation() {
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
    }
}
