package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LibraryActivity : ComponentActivity() {

    private var hamburgerPopup: PopupWindow? = null
    private lateinit var libraryGrid: GridLayout
    private val allLibraryCards = mutableListOf<Pair<MaterialCardView, JSONObject>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_1)

        libraryGrid = findViewById(R.id.library_grid)
        val searchIcon      = findViewById<ImageView>(R.id.search_icon)
        val searchContainer = findViewById<CardView>(R.id.search_bar_container)
        val searchEditText  = findViewById<EditText>(R.id.search_edit_text)

        loadLibraryItems()

        // ── Search button logic ───────────────────────────────────────────────
        searchIcon.setOnClickListener {
            val visible = searchContainer.visibility == View.VISIBLE
            searchContainer.visibility = if (visible) View.GONE else View.VISIBLE
            if (!visible) {
                searchEditText.requestFocus()
            } else {
                searchEditText.setText("")
                filterLibrary("")
            }
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterLibrary(s?.toString()?.trim()?.lowercase() ?: "")
            }
        })

        // ── Hamburger PopupWindow ─────────────────────────────────────────────
        val menuButton = findViewById<ImageView>(R.id.menu_button)
        menuButton.setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) {
                hamburgerPopup?.dismiss()
            } else {
                showHamburgerMenu(anchor)
            }
        }

        setupBottomNavigation()
    }

    private fun loadLibraryItems() {
        libraryGrid.removeAllViews()
        allLibraryCards.clear()

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        
        // 1. Load the main "Selected" book from ChoosingPhase
        val selectedBook = prefs.getString("SELECTED_BOOK", null)
        if (selectedBook != null && selectedBook != "Unknown Book") {
            val bookObj = JSONObject().apply {
                put("title", selectedBook)
                put("author", prefs.getString("SELECTED_AUTHOR", ""))
                put("course", prefs.getString("SELECTED_COURSE", ""))
                put("year", prefs.getString("SELECTED_YEAR", ""))
                put("chapters", prefs.getInt("SELECTED_CHAPTERS", 0))
                put("is_main", true)
            }
            addBookToGrid(bookObj)
        }

        // 2. Load all "Downloaded" books
        val downloadedJson = prefs.getString("DOWNLOADED_BOOKS_LIST", "[]")
        try {
            val jsonArray = JSONArray(downloadedJson)
            for (i in 0 until jsonArray.length()) {
                val bookObj = jsonArray.getJSONObject(i)
                val title = bookObj.optString("title")
                // Avoid duplicating the main book if it's already there
                if (title != selectedBook) {
                    addBookToGrid(bookObj)
                }
            }
        } catch (e: Exception) {}
    }

    private fun addBookToGrid(bookObj: JSONObject) {
        val title = bookObj.optString("title", "Unknown Book")
        val author = bookObj.optString("author", "")
        val course = bookObj.optString("course", "")
        val year = bookObj.optString("year", "")
        val chapters = bookObj.optInt("chapters", 0)
        val isMain = bookObj.optBoolean("is_main", false)

        val inflater = LayoutInflater.from(this)
        val card = inflater.inflate(R.layout.library_grid_item_template, libraryGrid, false) as MaterialCardView
        
        val tvTitle = card.findViewById<TextView>(R.id.chosen_book_title)
        val tvAuthor = card.findViewById<TextView>(R.id.chosen_book_author)
        val tvCourse = card.findViewById<TextView>(R.id.chosen_book_course)
        val tvChapters = card.findViewById<TextView>(R.id.chosen_book_chapters)
        val ivCover = card.findViewById<ImageView>(R.id.chosen_book_cover)
        val btnDelete = card.findViewById<ImageView>(R.id.btn_delete_book)

        tvTitle.text = title
        tvAuthor.text = if (author.isNotEmpty()) "by $author" else ""
        tvCourse.text = if (year.isNotEmpty()) "$course · $year" else course
        tvChapters.text = "$chapters Chapters"

        val coverUrl = "https://covers.openlibrary.org/b/title/${title.replace(" ", "+")}-M.jpg?default=false"
        Glide.with(this)
            .load(coverUrl)
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(ivCover)

        card.setOnClickListener {
            // Set as current selected book for Details and Reading activities
            val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("SELECTED_BOOK", title)
                .putString("SELECTED_AUTHOR", author)
                .putString("SELECTED_COURSE", course)
                .putString("SELECTED_YEAR", year)
                .putInt("SELECTED_CHAPTERS", chapters)
                .apply()

            startActivity(Intent(this, LibraryDetailsActivity::class.java).putExtra("BOOK_TITLE", title))
        }

        btnDelete.setOnClickListener {
            removeBook(title, isMain)
        }

        libraryGrid.addView(card)
        allLibraryCards.add(Pair(card, bookObj))
    }

    private fun removeBook(title: String, isMain: Boolean) {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()

        if (isMain) {
            editor.remove("SELECTED_BOOK")
            editor.remove("SELECTED_AUTHOR")
            editor.remove("SELECTED_COURSE")
            editor.remove("SELECTED_YEAR")
            editor.remove("SELECTED_CHAPTERS")
        } else {
            val downloadedJson = prefs.getString("DOWNLOADED_BOOKS_LIST", "[]")
            try {
                val jsonArray = JSONArray(downloadedJson)
                val newList = JSONArray()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    if (obj.getString("title") != title) {
                        newList.put(obj)
                    }
                }
                editor.putString("DOWNLOADED_BOOKS_LIST", newList.toString())
            } catch (e: Exception) {}
        }
        
        // Also delete the physical file if it exists
        val file = File(File(filesDir, "Sources"), "$title.pdf")
        if (file.exists()) file.delete()

        editor.apply()
        Toast.makeText(this, "Removed $title", Toast.LENGTH_SHORT).show()
        loadLibraryItems()
    }

    private fun filterLibrary(query: String) {
        allLibraryCards.forEach { (card, bookObj) ->
            val title = bookObj.optString("title", "").lowercase()
            val author = bookObj.optString("author", "").lowercase()
            val course = bookObj.optString("course", "").lowercase()
            
            val matches = query.isEmpty() || title.contains(query) || author.contains(query) || course.contains(query)
            card.visibility = if (matches) View.VISIBLE else View.GONE
        }
    }

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this)
            .inflate(R.layout.hamburger_dropdown_menu, null)

        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView,
            (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        ).apply {
            elevation = 12 * dp
            animationStyle = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }

        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, AboutUsActivity::class.java))
        }

        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(
            anchor,
            Gravity.NO_GRAVITY,
            loc[0],
            loc[1] + anchor.height + (4 * dp).toInt()
        )
        hamburgerPopup = popup
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
