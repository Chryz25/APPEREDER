package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

class BrowseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  HARDCODED GITHUB REPOSITORIES  ★
    //  Add or remove repository paths below before building the app.
    //  Format: "username/repository-name"   (no leading slash, no .git)
    //  You can also paste a full GitHub URL — it will be normalised.
    //
    //  Examples:
    //    "octocat/Hello-World"
    //    "https://github.com/cyniccccc/UI"
    // ════════════════════════════════════════════════════════════════════════
    private val HARDCODED_REPOS = listOf(
        "cyniccccc/UI"
        // ADD MORE REPOS HERE ↓
        // "another-user/another-repo",
    )
    // ════════════════════════════════════════════════════════════════════════

    private val client = OkHttpClient()

    /** All book cards currently rendered, used for search filtering. */
    private val allBookItems = mutableListOf<Pair<MaterialCardView, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.browse_sources_1)

        // ── Hamburger menu ────────────────────────────────────────────────────
        var hamburgerPopup: PopupWindow? = null
        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) {
                hamburgerPopup?.dismiss()
            } else {
                hamburgerPopup = showHamburgerMenu(anchor)
            }
        }

        // ── Search bar ────────────────────────────────────────────────────────
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            showAllBooks()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterBooks(s?.toString() ?: "", noResults)
            }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }

        // ── Load books from all hardcoded repos ───────────────────────────────
        loadAllRepos()

        setupNavigation()
    }

    // ── Normalise a repo entry to "user/repo" format ──────────────────────────
    private fun normaliseRepo(raw: String): String =
        raw.trim()
            .replace("https://github.com/", "")
            .replace("https://raw.githubusercontent.com/", "")
            .removeSuffix("/main")
            .removeSuffix("/")

    // ── Fetch each repo in sequence and populate the list ─────────────────────
    private fun loadAllRepos() {
        val loading   = findViewById<ProgressBar>(R.id.books_loading)
        val container = findViewById<LinearLayout>(R.id.books_list_container)
        val emptyView = findViewById<View>(R.id.empty_view)

        loading.visibility   = View.VISIBLE
        emptyView.visibility = View.GONE
        container.removeAllViews()
        allBookItems.clear()

        val repos = HARDCODED_REPOS.map { normaliseRepo(it) }.filter { it.isNotEmpty() }

        if (repos.isEmpty()) {
            loading.visibility   = View.GONE
            emptyView.visibility = View.VISIBLE
            return
        }

        var pending = repos.size

        repos.forEach { repoPath ->
            val apiUrl  = "https://api.github.com/repos/$repoPath/contents/"
            val request = Request.Builder()
                .url(apiUrl)
                .header("Accept", "application/vnd.github.v3+json")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        pending--
                        if (pending == 0) finishLoading(loading, emptyView, container)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    runOnUiThread {
                        pending--
                        if (response.isSuccessful && body != null) {
                            try {
                                val jsonArray = JSONArray(body)
                                for (i in 0 until jsonArray.length()) {
                                    val fileObj = jsonArray.getJSONObject(i)
                                    if (fileObj.getString("type") == "file" &&
                                        fileObj.getString("name").lowercase().endsWith(".pdf")) {
                                        addBookCard(container, fileObj.getString("name"), repoPath)
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        if (pending == 0) finishLoading(loading, emptyView, container)
                    }
                }
            })
        }
    }

    private fun finishLoading(loading: ProgressBar, emptyView: View, container: LinearLayout) {
        loading.visibility   = View.GONE
        emptyView.visibility = if (allBookItems.isEmpty()) View.VISIBLE else View.GONE
    }

    // ── Build and add a single book card ─────────────────────────────────────
    private fun addBookCard(container: LinearLayout, fileName: String, repoPath: String) {
        val displayName = fileName.removeSuffix(".pdf")
        val downloadUrl = "https://raw.githubusercontent.com/$repoPath/main/$fileName"
        val dp = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (10 * dp).toInt() }
            radius        = 12 * dp
            cardElevation = 1 * dp
            isClickable   = true
            isFocusable   = true
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
        }

        // PDF icon badge
        val iconBg = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams((44 * dp).toInt(), (44 * dp).toInt()).also {
                it.marginEnd = (14 * dp).toInt()
            }
            gravity = Gravity.CENTER
            setBackgroundColor(0xFFEDE7F6.toInt())
            // Rounded corners via a background drawable would be ideal; using solid colour is fine
        }
        val iconLabel = TextView(this).apply {
            text = "PDF"
            setTextColor(0xFF6A1B9A.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize = 10f
            gravity  = Gravity.CENTER
        }
        iconBg.addView(iconLabel)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleView = TextView(this).apply {
            text = displayName
            setTextColor(0xFF1A1A1A.toInt())
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            maxLines  = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val infoView = TextView(this).apply {
            text = repoPath
            setTextColor(0xFF888888.toInt())
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = (2 * dp).toInt() }
        }
        textCol.addView(titleView)
        textCol.addView(infoView)

        // VIEW button
        val viewBtn = android.widget.Button(this).apply {
            text = "VIEW"
            setTextColor(0xFF6A1B9A.toInt())
            textSize = 12f
            background = getDrawable(R.drawable.bg_rounded_browse_extension_1)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (36 * dp).toInt()
            ).also { it.marginStart = (8 * dp).toInt() }
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), 0)
            isAllCaps = true
            setOnClickListener { openPdf(downloadUrl, displayName) }
        }

        row.addView(iconBg)
        row.addView(textCol)
        row.addView(viewBtn)
        card.addView(row)
        card.setOnClickListener { openPdf(downloadUrl, displayName) }

        container.addView(card)
        allBookItems.add(Pair(card, "$displayName $repoPath"))
    }

    private fun openPdf(url: String, title: String) {
        startActivity(Intent(this, PdfViewerActivity::class.java).apply {
            putExtra("PDF_URL", url)
            putExtra("IS_LOCAL", false)
        })
    }

    // ── Search helpers ────────────────────────────────────────────────────────
    private fun showAllBooks() {
        allBookItems.forEach { (card, _) -> card.visibility = View.VISIBLE }
        findViewById<View>(R.id.no_results_view).visibility = View.GONE
    }

    private fun filterBooks(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        allBookItems.forEach { (card, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            card.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    // ── Hamburger popup ───────────────────────────────────────────────────────
    private fun showHamburgerMenu(anchor: View): PopupWindow {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView, (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true
        ).apply {
            elevation = 12 * dp
            animationStyle = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        return popup
    }

    // ── Bottom navigation ─────────────────────────────────────────────────────
    private fun setupNavigation() {
        findViewById<View>(R.id.nav_library)?.setOnClickListener  { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<View>(R.id.nav_history)?.setOnClickListener  { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.nav_download)?.setOnClickListener { startActivity(Intent(this, DownloadActivity::class.java)) }
    }
}
