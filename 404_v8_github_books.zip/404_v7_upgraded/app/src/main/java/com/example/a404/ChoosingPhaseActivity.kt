package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

// ── Book data model (kept for compatibility) ──────────────────────────────────
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String
)

// ── GitHub-sourced book model ─────────────────────────────────────────────────
data class GitHubBook(
    val fileName: String,
    val displayName: String,
    val downloadUrl: String,
    val repoPath: String
)

class ChoosingPhaseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  SAME HARDCODED REPOS AS BrowseActivity  ★
    //  Keep these in sync with BrowseActivity.HARDCODED_REPOS
    // ════════════════════════════════════════════════════════════════════════
    private val HARDCODED_REPOS = listOf(
        "cyniccccc/UI"
        // ADD MORE REPOS HERE ↓
        // "another-user/another-repo",
    )
    // ════════════════════════════════════════════════════════════════════════

    private val client = OkHttpClient()

    private var selectedCourse: MaterialCardView? = null
    private var selectedBookCard: MaterialCardView? = null
    private var selectedBook: GitHubBook? = null

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1

    private val courseLabels = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        val btnContinue = findViewById<Button>(R.id.btn_continue)
        val tvHint      = findViewById<TextView>(R.id.tv_book_hint)
        val bookGrid    = findViewById<LinearLayout>(R.id.book_grid)

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                val newSelected = selectCard(card, courses, selectedCourse)
                selectedCourse = newSelected
                courseIndex = if (newSelected != null) idx else -1
            }
        }

        // ── Hide year section (not needed — books come from GitHub, not by year) ──
        listOf<Int>(
            R.id.id_02,
            R.id.academic_year,
            R.id.year_grid,
            R.id.divider_01,
            R.id.divider_02
        ).forEach { id ->
            findViewById<View>(id)?.visibility = View.GONE
        }

        // ── Prepare book list container ───────────────────────────────────────
        bookGrid.removeAllViews()
        bookGrid.orientation = LinearLayout.VERTICAL
        bookGrid.gravity     = Gravity.TOP
        bookGrid.visibility  = View.VISIBLE
        tvHint.visibility    = View.GONE

        // Show loading spinner
        val loadingBar = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also {
                it.gravity      = Gravity.CENTER_HORIZONTAL
                it.topMargin    = dpToPx(20)
                it.bottomMargin = dpToPx(20)
            }
            isIndeterminate = true
        }
        bookGrid.addView(loadingBar)

        // ── Fetch and populate books ──────────────────────────────────────────
        loadBooksFromGitHub { books ->
            bookGrid.removeAllViews()

            if (books.isEmpty()) {
                val emptyMsg = TextView(this).apply {
                    text     = "No books found in the configured repositories."
                    textSize = 13f
                    setTextColor(Color.parseColor("#FFAAAAAA"))
                    gravity  = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.topMargin = dpToPx(16) }
                }
                bookGrid.addView(emptyMsg)
            } else {
                books.forEach { book ->
                    bookGrid.addView(buildBookCard(book))
                }
            }
        }

        // ── Continue button ───────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            if (courseIndex < 0) {
                Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (selectedBook == null) {
                Toast.makeText(this, "Please tap a book to confirm your selection",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val book = selectedBook!!

            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                .putString ("SELECTED_BOOK",     book.displayName)
                .putString ("SELECTED_AUTHOR",   book.repoPath)
                .putString ("SELECTED_DESC",     "PDF from ${book.repoPath}")
                .putInt    ("SELECTED_CHAPTERS", 0)
                .putString ("SELECTED_COURSE",   courseLabels[courseIndex])
                .putString ("SELECTED_YEAR",     "")
                .putString ("SELECTED_PDF_URL",  book.downloadUrl)
                .putBoolean("PROFILE_SETUP_DONE", true)
                .apply()

            startActivity(Intent(this, LibraryActivity::class.java))
            finish()
        }
    }

    // ── Build a tappable book row card ────────────────────────────────────────
    private fun buildBookCard(book: GitHubBook): MaterialCardView {
        val dp = resources.displayMetrics.density

        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dpToPx(10) }
            radius        = 12 * dp
            cardElevation = 2 * dp
            strokeWidth   = (strokeDefault * dp).toInt()
            strokeColor   = Color.parseColor("#FFD6C5B4")
            setCardBackgroundColor(colorDefault)
            isClickable   = true
            isFocusable   = true
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14))
        }

        // PDF icon badge
        val iconBg = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(44), dpToPx(44)).also {
                it.marginEnd = dpToPx(14)
            }
            gravity = Gravity.CENTER
            setBackgroundColor(0xFFEDE7F6.toInt())
        }
        val iconLabel = TextView(this).apply {
            text = "PDF"
            setTextColor(0xFF6A1B9A.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize = 10f
            gravity  = Gravity.CENTER
        }
        iconBg.addView(iconLabel)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleView = TextView(this).apply {
            text = book.displayName
            setTextColor(0xFF1A1A1A.toInt())
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            maxLines  = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val repoView = TextView(this).apply {
            text = book.repoPath
            setTextColor(0xFF888888.toInt())
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dpToPx(2) }
        }
        textCol.addView(titleView)
        textCol.addView(repoView)

        row.addView(iconBg)
        row.addView(textCol)
        card.addView(row)

        // Select / deselect on tap
        card.setOnClickListener {
            val wasSelected = (selectedBook == book)
            val density = resources.displayMetrics.density

            // Deselect previously selected card
            selectedBookCard?.let { prev ->
                prev.strokeWidth = (strokeDefault * density).toInt()
                prev.strokeColor = Color.parseColor("#FFD6C5B4")
                prev.setCardBackgroundColor(colorDefault)
                tintCardText(prev, "#FF2A2A2A")
            }

            if (wasSelected) {
                selectedBook     = null
                selectedBookCard = null
            } else {
                card.strokeWidth = (strokeSelected * density).toInt()
                card.strokeColor = Color.parseColor("#FF6A1B9A")
                card.setCardBackgroundColor(colorSelected)
                tintCardText(card, "#FF6A1B9A")
                selectedBook     = book
                selectedBookCard = card
            }
        }

        return card
    }

    // ── Fetch PDFs from all configured GitHub repos ───────────────────────────
    private fun loadBooksFromGitHub(onComplete: (List<GitHubBook>) -> Unit) {
        val repos = HARDCODED_REPOS.map { normaliseRepo(it) }.filter { it.isNotEmpty() }

        if (repos.isEmpty()) {
            runOnUiThread { onComplete(emptyList()) }
            return
        }

        val result  = mutableListOf<GitHubBook>()
        var pending = repos.size

        repos.forEach { repoPath ->
            val apiUrl  = "https://api.github.com/repos/$repoPath/contents/"
            val request = Request.Builder()
                .url(apiUrl)
                .header("Accept", "application/vnd.github.v3+json")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        pending--
                        if (pending == 0) onComplete(result)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    runOnUiThread {
                        pending--
                        if (response.isSuccessful && body != null) {
                            try {
                                val jsonArray = JSONArray(body)
                                for (i in 0 until jsonArray.length()) {
                                    val fileObj = jsonArray.getJSONObject(i)
                                    val name = fileObj.getString("name")
                                    if (fileObj.getString("type") == "file" &&
                                        name.lowercase().endsWith(".pdf")) {
                                        result.add(
                                            GitHubBook(
                                                fileName    = name,
                                                displayName = name.removeSuffix(".pdf"),
                                                downloadUrl = "https://raw.githubusercontent.com/$repoPath/main/$name",
                                                repoPath    = repoPath
                                            )
                                        )
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        if (pending == 0) onComplete(result)
                    }
                }
            })
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun normaliseRepo(raw: String): String =
        raw.trim()
            .replace("https://github.com/", "")
            .replace("https://raw.githubusercontent.com/", "")
            .removeSuffix("/main")
            .removeSuffix("/")

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val density = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * density).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) {
            null
        } else {
            clicked.strokeWidth = (strokeSelected * density).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
