package com.example.a404

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import java.io.File

class DownloadActivity : ComponentActivity() {

    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.download_1)

        // ── Always show offline content (downloads are always accessible) ──────
        val offlineContent = findViewById<View>(R.id.offline_content)
        val onlineWarning  = findViewById<View>(R.id.online_warning)
        offlineContent.visibility = View.VISIBLE
        onlineWarning.visibility  = View.GONE

        val container      = findViewById<LinearLayout>(R.id.downloads_container)
        val searchEditText = findViewById<EditText>(R.id.search_edit_text)
        val emptyView      = findViewById<View?>(R.id.empty_downloads_view)

        // Populate downloads
        refreshDownloads(container, emptyView)

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterDownloads(container, s?.toString() ?: "")
            }
        })

        findViewById<ImageView>(R.id.menu_button).setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss() else showHamburgerMenu(anchor)
        }

        setupNavigation()
    }

    private fun refreshDownloads(container: LinearLayout, emptyView: View?) {
        // Keep the first child (section label / header) if it exists
        val label = if (container.childCount > 0) container.getChildAt(0) else null
        container.removeAllViews()
        if (label != null) container.addView(label)

        val sourcesDir = File(filesDir, "Sources")
        val files = if (sourcesDir.exists() && sourcesDir.isDirectory) {
            sourcesDir.listFiles { f -> f.isFile && f.name.endsWith(".pdf") }
                ?.sortedBy { it.name } ?: emptyList()
        } else emptyList()

        if (files.isEmpty()) {
            emptyView?.visibility = View.VISIBLE
        } else {
            emptyView?.visibility = View.GONE
            files.forEach { file -> addDownloadItem(container, file) }
        }
    }

    private fun addDownloadItem(container: LinearLayout, file: File) {
        val itemView  = LayoutInflater.from(this).inflate(R.layout.item_download_file, container, false)
        val titleView = itemView.findViewById<TextView>(R.id.download_title_text)
        val infoView  = itemView.findViewById<TextView>(R.id.download_info_text)

        val displayName = file.name.removeSuffix(".pdf")
        titleView.text = displayName
        val sizeMb = String.format("%.1f", file.length() / (1024.0 * 1024.0))
        infoView.text = "Available Offline • $sizeMb MB"

        itemView.setOnClickListener {
            startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                putExtra("PDF_URL", file.absolutePath)
                putExtra("IS_LOCAL", true)
            })
        }

        container.addView(itemView)
    }

    private fun filterDownloads(container: LinearLayout, query: String) {
        for (i in 1 until container.childCount) {
            val child = container.getChildAt(i)
            val title = child.findViewById<TextView>(R.id.download_title_text)?.text?.toString() ?: ""
            child.visibility = if (title.lowercase().contains(query.lowercase())) View.VISIBLE else View.GONE
        }
    }

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(popupView, (200 * dp).toInt(), -2, true).apply {
            elevation = 12 * dp
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener    { popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java)) }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener { popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java)) }
        val loc = IntArray(2).apply { anchor.getLocationInWindow(this) }
        popup.showAtLocation(anchor, 0, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        hamburgerPopup = popup
    }

    private fun setupNavigation() {
        findViewById<View>(R.id.nav_library)?.setOnClickListener { startActivity(Intent(this, LibraryActivity::class.java)) }
        findViewById<View>(R.id.nav_history)?.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.nav_browse)?.setOnClickListener  { startActivity(Intent(this, BrowseActivity::class.java)) }
    }
}
