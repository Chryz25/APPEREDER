package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

/**
 * Book detail / chapter list screen.
 *
 * Fixes / upgrades vs V15:
 *  1. hamburgerPopup-style per-chapter popup dismissed cleanly; parent PopupWindow
 *     references are nulled after dismiss to avoid WindowLeaked crashes.
 *  2. Bottom navigation uses finish() before startActivity() only when
 *     appropriate; navigating to Library no longer orphans the back-stack.
 *  3. "addlibrarybutton" now actually adds the book to the downloaded list in
 *     SharedPreferences (was showing a Toast but doing nothing).
 *  4. "menu_download" in the three-dots overlay now launches PdfViewerActivity
 *     which handles the real download — was just showing a Toast.
 *  5. Book cover URL uses the same Open Library pattern consistently.
 *  6. Chapter card ripple uses android:attr/selectableItemBackground correctly
 *     (unchanged, but guard added for API < 21 where resolveAttribute may fail).
 *  7. Popup window for per-chapter three-dots is dismissed in onPause to
 *     prevent WindowLeaked if the user navigates away while it is open.
 */
class LibraryDetailsActivity : ComponentActivity() {

    // Active per-chapter popup (at most one open at a time)
    private var activeChapterPopup: PopupWindow? = null

    // ── Bookmark helpers ──────────────────────────────────────────────────────

    private fun bookmarkKey(bookTitle: String, chapterIndex: Int) =
        "bookmark_${bookTitle}_chapter_$chapterIndex"

    private fun isBookmarked(prefs: android.content.SharedPreferences, bookTitle: String, chapterIndex: Int) =
        prefs.getBoolean(bookmarkKey(bookTitle, chapterIndex), false)

    private fun setBookmark(bookTitle: String, chapterIndex: Int, bookmarked: Boolean) {
        getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)
            .edit()
            .putBoolean(bookmarkKey(bookTitle, chapterIndex), bookmarked)
            .apply()
    }

    // ── Cover URL ─────────────────────────────────────────────────────────────

    private fun getCoverUrl(title: String): String {
        val encoded = title.replace(" ", "+").replace("&", "%26")
        return "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
    }

    // ── Chapter title maps ────────────────────────────────────────────────────

    private val chapterTitles = mapOf(
        10 to listOf("Introduction & Overview","Core Concepts","Fundamentals in Practice","Key Principles","Applied Methods","Tools & Techniques","Problem Solving","Case Studies","Advanced Topics","Review & Assessment"),
        8  to listOf("Introduction","Planning & Design","Implementation","Testing & Validation","Integration","Deployment","Evaluation","Final Presentation"),
        9  to listOf("Digital Foundations","Image & Color Theory","Audio Fundamentals","Video Basics","Media Tools Overview","Production Workflow","Editing Techniques","Distribution Methods","Capstone Project"),
        11 to listOf("Project Scope & Initiation","Stakeholder Management","Planning & Scheduling","Risk Assessment","Resource Allocation","Agile Frameworks","Monitoring & Control","Communication Strategies","Quality Assurance","Project Closure","Review & Reflection"),
        12 to listOf("Introduction to the Field","Historical Context","Theoretical Foundations","Core Methodologies","Design Patterns","Implementation Strategies","Testing & Debugging","Performance Optimization","Security Considerations","Team Collaboration","Deployment Practices","Capstone & Review"),
        13 to listOf("Introduction & Setup","Core Fundamentals","Data Modeling","Query Design","Optimization Basics","Security & Access Control","Backup & Recovery","Transactions & Integrity","Distributed Systems","Performance Tuning","Practical Lab Work","Case Study Analysis","Final Assessment"),
        14 to listOf("Course Introduction","Environment Setup","Core Concepts I","Core Concepts II","Data Structures","Algorithms & Logic","Applied Exercises","Debugging Techniques","Real-World Use Cases","Group Projects","Advanced Topics I","Advanced Topics II","Performance & Scale","Final Review"),
        15 to listOf("Network Fundamentals","OSI Model & Protocols","TCP/IP Deep Dive","LAN Configuration","WAN & Routing","Wireless Networks","Network Security Basics","Firewalls & VPNs","Cloud Networking","Network Monitoring","Troubleshooting Methods","Virtualization","Automation & Scripting","Disaster Recovery","Capstone Lab"),
        16 to listOf("OS Architecture Overview","Processes & Threads","CPU Scheduling","Memory Management","Virtual Memory","File Systems","I/O Management","Deadlocks & Avoidance","Concurrency & Synchronization","Security & Protection","Distributed OS Concepts","Virtualization","Linux Internals","Case Studies","Lab Exercises","Final Exam Prep")
    )

    // ─────────────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_2)

        val prefs         = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val bookmarkPrefs = getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)

        val bookTitle    = intent.getStringExtra("BOOK_TITLE")
                          ?: prefs.getString("SELECTED_BOOK",    "Unknown Book") ?: "Unknown Book"
        val bookAuthor   = prefs.getString("SELECTED_AUTHOR",  "") ?: ""
        val bookDesc     = prefs.getString("SELECTED_DESC",    "") ?: ""
        val bookChapters = prefs.getInt("SELECTED_CHAPTERS", 3)
        val bookCourse   = prefs.getString("SELECTED_COURSE",  "") ?: ""
        val bookYear     = prefs.getString("SELECTED_YEAR",    "") ?: ""
        val bookUrl      = prefs.getString("SELECTED_BOOK_URL","") ?: ""

        // ── Header ────────────────────────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text      = bookTitle
        findViewById<TextView>(R.id.author_label).text      = "by $bookAuthor"
        findViewById<TextView>(R.id.course_year_label).text = "$bookCourse · $bookYear"

        Glide.with(this)
            .load(getCoverUrl(bookTitle))
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(findViewById(R.id.book_cover_image))

        findViewById<TextView>(R.id.book_description).text = bookDesc.ifBlank {
            "This module covers the essential knowledge and skills for $bookCourse students in their $bookYear."
        }

        // Hide bottom nav on this detail screen
        findViewById<LinearLayout>(R.id.bottom_navigation)?.visibility = View.GONE

        // ── Toolbar actions ───────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // "Add to Library" — persist book so it shows in LibraryActivity
        findViewById<View>(R.id.addlibrarybutton).setOnClickListener {
            addBookToLibrary(bookTitle, bookAuthor, bookDesc, bookChapters, bookCourse, bookYear)
        }

        // "Learn" → AI quiz
        findViewById<View>(R.id.learnbuttn).setOnClickListener {
            startActivity(
                Intent(this, GroqQuizActivity::class.java).apply {
                    putExtra("BOOK_TITLE",  bookTitle)
                    putExtra("BOOK_AUTHOR", bookAuthor)
                    putExtra("BOOK_DESC",   bookDesc)
                    putExtra("BOOK_COURSE", bookCourse)
                    putExtra("BOOK_YEAR",   bookYear)
                    putExtra("BOOK_URL",    bookUrl)
                }
            )
        }

        // ── Three-dots overlay ────────────────────────────────────────────────
        val threeDots   = findViewById<ImageView>(R.id.three_dots)
        val menuOverlay = findViewById<View>(R.id.three_dots_menu)
        threeDots.setOnClickListener { menuOverlay.visibility = View.VISIBLE }
        menuOverlay.findViewById<View>(R.id.menu_close).setOnClickListener {
            menuOverlay.visibility = View.GONE
        }
        menuOverlay.findViewById<View>(R.id.menu_download).setOnClickListener {
            menuOverlay.visibility = View.GONE
            if (bookUrl.isNotBlank()) {
                // Launch PdfViewerActivity which handles actual download
                startActivity(
                    Intent(this, PdfViewerActivity::class.java).apply {
                        putExtra("PDF_URL",   bookUrl)
                        putExtra("IS_LOCAL",  false)
                        putExtra("PDF_TITLE", bookTitle)
                    }
                )
            } else {
                Toast.makeText(this, "No download URL available for this book.", Toast.LENGTH_SHORT).show()
            }
        }

        // ── Build chapter cards ────────────────────────────────────────────────
        val container = findViewById<LinearLayout>(R.id.chapters_container)
        container.removeAllViews()

        val titles      = chapterTitles[bookChapters] ?: buildGenericTitles(bookChapters)
        val dp          = resources.displayMetrics.density
        val marginBottom = (12 * dp).toInt()

        titles.forEachIndexed { index, chapterName ->
            val chapterTitle = "Chapter ${index + 1}: $chapterName"

            // ── Card ──────────────────────────────────────────────────────────
            val card = MaterialCardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (64 * dp).toInt()
                ).also { it.bottomMargin = marginBottom }
                radius        = 12 * dp
                cardElevation = 2 * dp
                isClickable   = true
                isFocusable   = true
                foreground    = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
                }
            }

            // ── Number badge ──────────────────────────────────────────────────
            val badge = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (40 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT
                )
                text = "${index + 1}"
                setTextColor(0xFF6A1B9A.toInt())
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.CENTER
            }

            // ── Chapter label ─────────────────────────────────────────────────
            val label = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                text     = chapterTitle
                setTextColor(0xFF1A1A1A.toInt())
                textSize = 14f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity  = Gravity.CENTER_VERTICAL
                setPadding(0, 0, (8 * dp).toInt(), 0)
            }

            // ── Bookmark icon ─────────────────────────────────────────────────
            val bookmarkIcon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (32 * dp).toInt(), (32 * dp).toInt()
                ).also { lp ->
                    lp.gravity    = Gravity.CENTER_VERTICAL
                    lp.marginEnd  = (2 * dp).toInt()
                }
                val saved = isBookmarked(bookmarkPrefs, bookTitle, index)
                if (saved) {
                    setImageResource(R.drawable.ic_bookmark_filled)
                    clearColorFilter()
                } else {
                    setImageResource(R.drawable.ic_bookmark)
                    setColorFilter(0xFFAAAAAA.toInt())
                }
                background = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                    try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
                }
                isClickable = true
                isFocusable = true
                setPadding((4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt())
            }

            // ── Per-chapter 3-dots ────────────────────────────────────────────
            val chapterDots = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (36 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT
                ).also { lp -> lp.marginEnd = (4 * dp).toInt() }
                setImageResource(R.drawable.ic_more_vert)
                setColorFilter(0xFF888888.toInt())
                background = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                    try { getDrawable(tv.resourceId) } catch (_: Exception) { null }
                }
                isClickable = true
                isFocusable = true
                setPadding((6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt())
            }

            // ── Row ───────────────────────────────────────────────────────────
            val row = LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
                )
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                addView(badge)
                addView(label)
                addView(bookmarkIcon)
                addView(chapterDots)
            }
            card.addView(row)

            // ── Bookmark toggle helper ────────────────────────────────────────
            fun applyBookmark(bookmarked: Boolean) {
                setBookmark(bookTitle, index, bookmarked)
                if (bookmarked) {
                    bookmarkIcon.setImageResource(R.drawable.ic_bookmark_filled)
                    bookmarkIcon.clearColorFilter()
                    Toast.makeText(this, "Bookmarked: Chapter ${index + 1}", Toast.LENGTH_SHORT).show()
                } else {
                    bookmarkIcon.setImageResource(R.drawable.ic_bookmark)
                    bookmarkIcon.setColorFilter(0xFFAAAAAA.toInt())
                    Toast.makeText(this, "Bookmark removed from Chapter ${index + 1}", Toast.LENGTH_SHORT).show()
                }
            }

            bookmarkIcon.setOnClickListener {
                applyBookmark(!isBookmarked(bookmarkPrefs, bookTitle, index))
            }

            // ── Per-chapter popup (3-dots) ────────────────────────────────────
            chapterDots.setOnClickListener { anchor ->
                // Dismiss any previously open popup first
                activeChapterPopup?.dismiss()
                activeChapterPopup = null

                val popupView = LayoutInflater.from(this)
                    .inflate(R.layout.chapter_3dots_menu, null)

                val popup = PopupWindow(
                    popupView,
                    (220 * dp).toInt(),
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
                ).apply {
                    elevation          = 12 * dp
                    isOutsideTouchable = true
                    setOnDismissListener { activeChapterPopup = null }
                }
                activeChapterPopup = popup

                val bookmarkRow = popupView.findViewById<View>(R.id.chapter_menu_bookmark)
                val bookmarkLbl = popupView.findViewById<TextView>(R.id.chapter_menu_bookmark_label)
                val bookmarkIco = popupView.findViewById<ImageView>(R.id.chapter_menu_bookmark_icon)

                val currentlyBookmarked = isBookmarked(bookmarkPrefs, bookTitle, index)
                bookmarkLbl.text = if (currentlyBookmarked) "Remove Bookmark" else "Add Bookmark"
                if (currentlyBookmarked) {
                    bookmarkIco.setImageResource(R.drawable.ic_bookmark_filled)
                    bookmarkIco.clearColorFilter()
                } else {
                    bookmarkIco.setImageResource(R.drawable.ic_bookmark)
                    bookmarkIco.setColorFilter(0xFF6A1B9A.toInt())
                }

                bookmarkRow.setOnClickListener {
                    applyBookmark(!isBookmarked(bookmarkPrefs, bookTitle, index))
                    popup.dismiss()
                }
                popupView.findViewById<View>(R.id.chapter_menu_close).setOnClickListener {
                    popup.dismiss()
                }

                popup.showAsDropDown(anchor, -(170 * dp).toInt(), 0, Gravity.START)
            }

            // ── Chapter tap → Reading screen ──────────────────────────────────
            card.setOnClickListener {
                prefs.edit()
                    .putString("LAST_READ_BOOK",    bookTitle)
                    .putString("LAST_READ_AUTHOR",  bookAuthor)
                    .putString("LAST_READ_CHAPTER", chapterTitle)
                    .putString("LAST_READ_COURSE",  bookCourse)
                    .putString("LAST_READ_YEAR",    bookYear)
                    .apply()

                startActivity(
                    Intent(this, ReadingActivity::class.java).apply {
                        putExtra("CHAPTER_TITLE",  chapterTitle)
                        putExtra("CHAPTER_INDEX",  index + 1)
                        putExtra("TOTAL_CHAPTERS", bookChapters)
                        putExtra("BOOK_TITLE",     bookTitle)
                        putExtra("BOOK_COURSE",    bookCourse)
                    }
                )
            }

            container.addView(card)
        }

        setupBottomNavigation()
    }

    override fun onPause() {
        super.onPause()
        activeChapterPopup?.dismiss()
        activeChapterPopup = null
    }

    // ── Add book to library ───────────────────────────────────────────────────

    private fun addBookToLibrary(
        title: String, author: String, desc: String,
        chapters: Int, course: String, year: String
    ) {
        val prefs     = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val jsonArray = try {
            org.json.JSONArray(prefs.getString("DOWNLOADED_BOOKS_LIST", "[]"))
        } catch (_: Exception) {
            org.json.JSONArray()
        }

        // Check if already present
        for (i in 0 until jsonArray.length()) {
            if (jsonArray.getJSONObject(i).optString("title") == title) {
                Toast.makeText(this, "\"$title\" is already in your Library.", Toast.LENGTH_SHORT).show()
                return
            }
        }

        val bookObj = org.json.JSONObject().apply {
            put("title",       title)
            put("author",      author)
            put("description", desc)
            put("chapters",    chapters)
            put("course",      course)
            put("year",        year)
        }
        jsonArray.put(bookObj)
        prefs.edit().putString("DOWNLOADED_BOOKS_LIST", jsonArray.toString()).apply()
        Toast.makeText(this, "\"$title\" added to your Library!", Toast.LENGTH_SHORT).show()
    }

    // ── Generic chapter title fallback ────────────────────────────────────────

    private fun buildGenericTitles(count: Int): List<String> =
        (1..count).map { n ->
            when (n) {
                1     -> "Introduction"
                count -> "Final Review & Assessment"
                else  -> "Module $n"
            }
        }

    // ── Bottom navigation ─────────────────────────────────────────────────────

    private fun setupBottomNavigation() {
        // Bottom nav is hidden on this screen — wire up defensively
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java)); finish()
        }
    }
}
