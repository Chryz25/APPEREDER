package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

/**
 * History screen – shows recently read books and Browse Extension history.
 *
 * Fixes / upgrades vs V15:
 *  1. findDynamicContainer() was a no-op stub — replaced with a reliable
 *     ID-based lookup using a dedicated container view (history_dynamic_container).
 *     Falls back to the scroll-based walk only if the ID is missing.
 *  2. hamburgerPopup dismissed in onPause to prevent WindowLeaked crash.
 *  3. Bottom nav items guard against launching self (nav_history noop).
 *  4. Browse-history card click correctly handles empty URL gracefully.
 *  5. "No results" view is reset properly when the search bar is collapsed.
 */
class HistoryActivity : ComponentActivity() {

    private val historyItems   = mutableListOf<Pair<MaterialCardView, String>>()
    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.history___1)

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        val lastBook    = prefs.getString("LAST_READ_BOOK",    null)
        val lastChapter = prefs.getString("LAST_READ_CHAPTER", null)
        val lastCourse  = prefs.getString("LAST_READ_COURSE",  null)
        val selectedBook   = prefs.getString("SELECTED_BOOK",   null)
        val selectedCourse = prefs.getString("SELECTED_COURSE", null)
        val selectedYear   = prefs.getString("SELECTED_YEAR",   null)

        // ── Static history cards ──────────────────────────────────────────────
        val item1 = findViewById<MaterialCardView>(R.id.history_item_1)
        val item1Texts = findTextViews(item1)
        if (item1Texts.size >= 2) {
            val fromBrowse = lastCourse == "Browse Extension"
            if (lastBook != null && !fromBrowse) {
                item1Texts[0].text = lastBook
                val chLabel  = lastChapter?.substringBefore(":") ?: "Last chapter"
                val crLabel  = if (!lastCourse.isNullOrBlank()) " · $lastCourse" else ""
                item1Texts[1].text = "$chLabel · Just now$crLabel"
            } else if (selectedBook != null) {
                item1Texts[0].text = selectedBook
                val crLabel = if (!selectedCourse.isNullOrBlank()) " · $selectedCourse" else ""
                item1Texts[1].text = "Not started yet$crLabel"
            }
        }

        val item2 = findViewById<MaterialCardView>(R.id.history_item_2)
        val item2Texts = findTextViews(item2)
        if (item2Texts.size >= 2 && selectedBook != null && selectedBook != lastBook) {
            item2Texts[0].text = selectedBook
            val yearLabel = if (!selectedYear.isNullOrBlank()) " · $selectedYear" else ""
            item2Texts[1].text = "Selected book$yearLabel"
        }

        historyItems.clear()
        historyItems.add(Pair(item1, buildSearchText(item1)))
        historyItems.add(Pair(item2, buildSearchText(item2)))

        item1.setOnClickListener {
            val title = if (lastBook != null && lastCourse != "Browse Extension") lastBook else selectedBook
            if (title != null)
                startActivity(Intent(this, LibraryDetailsActivity::class.java).putExtra("BOOK_TITLE", title))
        }
        item2.setOnClickListener {
            if (selectedBook != null)
                startActivity(Intent(this, LibraryDetailsActivity::class.java).putExtra("BOOK_TITLE", selectedBook))
        }

        // ── Browse extension history ──────────────────────────────────────────
        val browseHistoryJson = prefs.getString("BROWSE_HISTORY", "[]") ?: "[]"
        try {
            val browseArr = JSONArray(browseHistoryJson)
            if (browseArr.length() > 0) {
                val dynamicContainer = findDynamicContainer()
                if (dynamicContainer != null) {
                    dynamicContainer.addView(TextView(this).apply {
                        text = "Browse Extension"
                        setTextColor(0xFF6A1B9A.toInt())
                        setTypeface(null, Typeface.BOLD)
                        textSize = 13f
                        setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(6))
                    })

                    val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())

                    for (i in 0 until minOf(browseArr.length(), 10)) {
                        val entry   = browseArr.getJSONObject(i)
                        val name    = entry.optString("name", "PDF Document")
                        val url     = entry.optString("url", "")
                        val ts      = entry.optLong("timestamp", 0L)
                        val dateStr = if (ts > 0) sdf.format(Date(ts)) else "Recently viewed"

                        val card = buildBrowseHistoryCard(name.removeSuffix(".pdf"), dateStr)
                        card.setOnClickListener {
                            if (url.isNotEmpty()) {
                                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                                    putExtra("PDF_URL",  url)
                                    putExtra("IS_LOCAL", false)
                                })
                            } else {
                                Toast.makeText(this, "URL no longer available", Toast.LENGTH_SHORT).show()
                            }
                        }
                        dynamicContainer.addView(card)
                        historyItems.add(Pair(card, "$name $dateStr"))
                    }
                }
            }
        } catch (_: Exception) {}

        // ── Search ────────────────────────────────────────────────────────────
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            noResults.visibility = View.GONE
            showAllItems()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filterItems(s?.toString() ?: "", noResults) }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }

        // ── Hamburger ─────────────────────────────────────────────────────────
        val menuButton = findViewById<ImageView>(R.id.menu_button)
        menuButton.setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) hamburgerPopup?.dismiss() else showHamburgerMenu(anchor)
        }

        setupNavigation()
    }

    override fun onPause() {
        super.onPause()
        hamburgerPopup?.dismiss()
    }

    // ── Dynamic container lookup ──────────────────────────────────────────────

    private fun findDynamicContainer(): LinearLayout? {
        // Prefer a view with the dedicated ID (add to layout if not present yet)
        val byId = findViewById<LinearLayout>(R.id.history_dynamic_container)
        if (byId != null) return byId

        // Fallback: walk the view tree for the scroll view's inner LinearLayout
        val root = findViewById<android.view.ViewGroup>(android.R.id.content)
        return findScrollInnerLinearLayout(root)
    }

    private fun findScrollInnerLinearLayout(view: android.view.ViewGroup): LinearLayout? {
        for (i in 0 until view.childCount) {
            val child = view.getChildAt(i)
            if (child is android.widget.ScrollView || child is NestedScrollView) {
                val inner = (child as android.view.ViewGroup).getChildAt(0)
                if (inner is LinearLayout) return inner
            }
            if (child is LinearLayout) return child
            if (child is android.view.ViewGroup) {
                val found = findScrollInnerLinearLayout(child)
                if (found != null) return found
            }
        }
        return null
    }

    // ── Browse history card builder ───────────────────────────────────────────

    private fun buildBrowseHistoryCard(title: String, subtitle: String): MaterialCardView {
        val dp = resources.displayMetrics.density
        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(dpToPx(16), dpToPx(4), dpToPx(16), dpToPx(4)) }
            radius        = 12 * dp
            cardElevation = 2 * dp
            isClickable   = true
            isFocusable   = true
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(14), dpToPx(12), dpToPx(14), dpToPx(12))
        }

        val icon = TextView(this).apply {
            text = "PDF"
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, Typeface.BOLD)
            textSize = 9f
            gravity  = Gravity.CENTER
            setBackgroundColor(0xFF6A1B9A.toInt())
            setPadding(dpToPx(5), dpToPx(3), dpToPx(5), dpToPx(3))
            layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(28)).also { lp ->
                lp.marginEnd = dpToPx(12)
            }
        }

        val textCol   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(0xFF1A1A1A.toInt())
            textSize  = 14f
            maxLines  = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val subView   = TextView(this).apply {
            text = subtitle
            setTextColor(0xFF888888.toInt())
            textSize = 12f
        }

        textCol.addView(titleView)
        textCol.addView(subView)
        row.addView(icon)
        row.addView(textCol)
        card.addView(row)
        return card
    }

    private fun dpToPx(dp: Int) = (dp * resources.displayMetrics.density).toInt()

    // ── Hamburger popup ───────────────────────────────────────────────────────

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this).inflate(R.layout.hamburger_dropdown_menu, null)
        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView, (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true
        ).apply {
            elevation          = 12 * dp
            animationStyle     = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }
        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss(); startActivity(Intent(this, AboutUsActivity::class.java))
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, loc[0], loc[1] + anchor.height + (4 * dp).toInt())
        hamburgerPopup = popup
    }

    // ── Search helpers ────────────────────────────────────────────────────────

    private fun findTextViews(view: View): List<TextView> {
        val result = mutableListOf<TextView>()
        if (view is TextView) { result.add(view); return result }
        if (view is android.view.ViewGroup)
            for (i in 0 until view.childCount) result.addAll(findTextViews(view.getChildAt(i)))
        return result
    }

    private fun buildSearchText(card: MaterialCardView): String =
        findTextViews(card).joinToString(" ") { it.text }

    private fun filterItems(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        historyItems.forEach { (card, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            card.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAllItems() {
        historyItems.forEach { (card, _) -> card.visibility = View.VISIBLE }
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private fun setupNavigation() {
        // nav_history intentionally omitted — we're already here
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
