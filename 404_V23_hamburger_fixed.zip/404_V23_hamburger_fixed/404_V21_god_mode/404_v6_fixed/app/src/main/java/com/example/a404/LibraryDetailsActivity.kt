package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

class LibraryDetailsActivity : ComponentActivity() {

    // ── SharedPreferences key helpers ─────────────────────────────────────────
    private fun bookmarkKey(bookTitle: String, chapterIndex: Int) =
        "bookmark_${bookTitle}_chapter_$chapterIndex"

    private fun isBookmarked(prefs: android.content.SharedPreferences, bookTitle: String, chapterIndex: Int): Boolean =
        prefs.getBoolean(bookmarkKey(bookTitle, chapterIndex), false)

    private fun setBookmark(bookTitle: String, chapterIndex: Int, bookmarked: Boolean) {
        getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)
            .edit()
            .putBoolean(bookmarkKey(bookTitle, chapterIndex), bookmarked)
            .apply()
    }

    // ── Real book cover URLs (Open Library / archive.org public covers) ──────
    private val bookCoverUrls = mapOf(
        "Foundations of Computing"       to "https://covers.openlibrary.org/b/id/8739161-L.jpg",
        "Data Structures & Algorithms"   to "https://covers.openlibrary.org/b/id/8108005-L.jpg",
        "Operating Systems Concepts"     to "https://covers.openlibrary.org/b/id/8228611-L.jpg",
        "Software Engineering Principles"to "https://covers.openlibrary.org/b/id/8091016-L.jpg",
        "Introduction to IT Systems"     to "https://covers.openlibrary.org/b/id/7898710-L.jpg",
        "Database Management Systems"    to "https://covers.openlibrary.org/b/id/8739162-L.jpg",
        "Network Administration"         to "https://covers.openlibrary.org/b/id/8091015-L.jpg",
        "IT Project Management"          to "https://covers.openlibrary.org/b/id/8091014-L.jpg",
        "Digital Media Foundations"      to "https://covers.openlibrary.org/b/id/8228612-L.jpg",
        "2D Animation & Design"          to "https://covers.openlibrary.org/b/id/8228613-L.jpg",
        "Interactive Media Development"  to "https://covers.openlibrary.org/b/id/8228614-L.jpg",
        "3D Modeling & Visualization"    to "https://covers.openlibrary.org/b/id/8228615-L.jpg",
        "Computer Hardware Essentials"   to "https://covers.openlibrary.org/b/id/8739163-L.jpg",
        "Embedded Systems Programming"   to "https://covers.openlibrary.org/b/id/8228616-L.jpg",
        "Industrial Automation & IoT"    to "https://covers.openlibrary.org/b/id/8228617-L.jpg",
        "Applied Systems Capstone"       to "https://covers.openlibrary.org/b/id/8091013-L.jpg"
    )

    // ── Open Library search URL builder ──────────────────────────────────────
    private fun getCoverUrl(title: String): String {
        val encoded = title.replace(" ", "+").replace("&", "%26")
        return "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
    }

    private val chapterTitles = mapOf(
        10 to listOf(
            "Introduction & Overview",
            "Core Concepts",
            "Fundamentals in Practice",
            "Key Principles",
            "Applied Methods",
            "Tools & Techniques",
            "Problem Solving",
            "Case Studies",
            "Advanced Topics",
            "Review & Assessment"
        ),
        8 to listOf(
            "Introduction",
            "Planning & Design",
            "Implementation",
            "Testing & Validation",
            "Integration",
            "Deployment",
            "Evaluation",
            "Final Presentation"
        ),
        9 to listOf(
            "Digital Foundations",
            "Image & Color Theory",
            "Audio Fundamentals",
            "Video Basics",
            "Media Tools Overview",
            "Production Workflow",
            "Editing Techniques",
            "Distribution Methods",
            "Capstone Project"
        ),
        11 to listOf(
            "Project Scope & Initiation",
            "Stakeholder Management",
            "Planning & Scheduling",
            "Risk Assessment",
            "Resource Allocation",
            "Agile Frameworks",
            "Monitoring & Control",
            "Communication Strategies",
            "Quality Assurance",
            "Project Closure",
            "Review & Reflection"
        ),
        12 to listOf(
            "Introduction to the Field",
            "Historical Context",
            "Theoretical Foundations",
            "Core Methodologies",
            "Design Patterns",
            "Implementation Strategies",
            "Testing & Debugging",
            "Performance Optimization",
            "Security Considerations",
            "Team Collaboration",
            "Deployment Practices",
            "Capstone & Review"
        ),
        13 to listOf(
            "Introduction & Setup",
            "Core Fundamentals",
            "Data Modeling",
            "Query Design",
            "Optimization Basics",
            "Security & Access Control",
            "Backup & Recovery",
            "Transactions & Integrity",
            "Distributed Systems",
            "Performance Tuning",
            "Practical Lab Work",
            "Case Study Analysis",
            "Final Assessment"
        ),
        14 to listOf(
            "Course Introduction",
            "Environment Setup",
            "Core Concepts I",
            "Core Concepts II",
            "Data Structures",
            "Algorithms & Logic",
            "Applied Exercises",
            "Debugging Techniques",
            "Real-World Use Cases",
            "Group Projects",
            "Advanced Topics I",
            "Advanced Topics II",
            "Performance & Scale",
            "Final Review"
        ),
        15 to listOf(
            "Network Fundamentals",
            "OSI Model & Protocols",
            "TCP/IP Deep Dive",
            "LAN Configuration",
            "WAN & Routing",
            "Wireless Networks",
            "Network Security Basics",
            "Firewalls & VPNs",
            "Cloud Networking",
            "Network Monitoring",
            "Troubleshooting Methods",
            "Virtualization",
            "Automation & Scripting",
            "Disaster Recovery",
            "Capstone Lab"
        ),
        16 to listOf(
            "OS Architecture Overview",
            "Processes & Threads",
            "CPU Scheduling",
            "Memory Management",
            "Virtual Memory",
            "File Systems",
            "I/O Management",
            "Deadlocks & Avoidance",
            "Concurrency & Synchronization",
            "Security & Protection",
            "Distributed OS Concepts",
            "Virtualization",
            "Linux Internals",
            "Case Studies",
            "Lab Exercises",
            "Final Exam Prep"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_2)

        // ── Load book data from SharedPreferences ─────────────────────────────
        val prefs          = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val bookmarkPrefs  = getSharedPreferences("Bookmarks", Context.MODE_PRIVATE)
        val bookTitle      = intent.getStringExtra("BOOK_TITLE")
                             ?: prefs.getString("SELECTED_BOOK", "Unknown Book") ?: "Unknown Book"
        val bookAuthor     = prefs.getString("SELECTED_AUTHOR",  "") ?: ""
        val bookDesc       = prefs.getString("SELECTED_DESC",    "") ?: ""
        val bookChapters   = prefs.getInt   ("SELECTED_CHAPTERS", 3)
        val bookCourse     = prefs.getString("SELECTED_COURSE",  "") ?: ""
        val bookYear       = prefs.getString("SELECTED_YEAR",    "") ?: ""

        // ── Populate header & details ─────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text     = bookTitle
        findViewById<TextView>(R.id.author_label).text     = "by $bookAuthor"
        findViewById<TextView>(R.id.course_year_label).text = "$bookCourse · $bookYear"

        // ── Load real book cover image ─────────────────────────────────────
        val coverImageView = findViewById<ImageView>(R.id.book_cover_image)
        val coverUrl = getCoverUrl(bookTitle)
        Glide.with(this)
            .load(coverUrl)
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(coverImageView)
        findViewById<TextView>(R.id.book_description).text = bookDesc.ifBlank {
            "This module covers the essential knowledge and skills for $bookCourse students in their $bookYear."
        }

        // ── Hide bottom navigation on Book Details screen ─────────────────────
        findViewById<LinearLayout>(R.id.bottom_navigation)?.visibility = View.GONE

        // ── Back button ───────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // ── Action buttons ────────────────────────────────────────────────────
        findViewById<View>(R.id.addlibrarybutton).setOnClickListener {
            Toast.makeText(this, "\"$bookTitle\" added to Library", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.learnbuttn).setOnClickListener {
            Toast.makeText(this, "Starting quiz for $bookTitle…", Toast.LENGTH_SHORT).show()
        }

        // ── Three dots menu (top-right) — Download, Close Menu only ─────────
        val threeDots   = findViewById<ImageView>(R.id.three_dots)
        val menuOverlay = findViewById<View>(R.id.three_dots_menu)
        threeDots.setOnClickListener { menuOverlay.visibility = View.VISIBLE }
        menuOverlay.findViewById<View>(R.id.menu_close).setOnClickListener {
            menuOverlay.visibility = View.GONE
        }
        menuOverlay.findViewById<View>(R.id.menu_download).setOnClickListener {
            Toast.makeText(this, "Download started for $bookTitle…", Toast.LENGTH_SHORT).show()
            menuOverlay.visibility = View.GONE
        }

        // ── Build chapter cards dynamically ──────────────────────────────────
        val container = findViewById<LinearLayout>(R.id.chapters_container)
        container.removeAllViews()

        val titles = chapterTitles[bookChapters] ?: buildGenericTitles(bookChapters)
        val dp     = resources.displayMetrics.density
        val marginBottom = (12 * dp).toInt()

        titles.forEachIndexed { index, chapterName ->
            val chapterTitle = "Chapter ${index + 1}: $chapterName"

            // ── Card ──────────────────────────────────────────────────────────
            val card = MaterialCardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (64 * dp).toInt()
                ).also { it.bottomMargin = marginBottom }
                radius        = 12 * dp
                cardElevation = 2 * dp
                isClickable   = true
                isFocusable   = true
                foreground    = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    getDrawable(tv.resourceId)
                }
            }

            // ── Chapter number badge ──────────────────────────────────────────
            val badge = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (40 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT
                )
                text = "${index + 1}"
                setTextColor(0xFF6A1B9A.toInt())
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.CENTER
            }

            // ── Chapter title ─────────────────────────────────────────────────
            val label = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                text     = chapterTitle
                setTextColor(0xFF1A1A1A.toInt())
                textSize = 14f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity  = Gravity.CENTER_VERTICAL
                setPadding(0, 0, (8 * dp).toInt(), 0)
            }

            // ── Bookmark icon (toggle) ────────────────────────────────────────
            val bookmarkIcon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (32 * dp).toInt(), (32 * dp).toInt()
                ).also { lp ->
                    lp.gravity = Gravity.CENTER_VERTICAL
                    lp.marginEnd = (2 * dp).toInt()
                }
                // ✅ FIX: Read persisted state immediately on creation
                val savedBookmark = isBookmarked(bookmarkPrefs, bookTitle, index)
                if (savedBookmark) {
                    setImageResource(R.drawable.ic_bookmark_filled)
                    clearColorFilter()
                } else {
                    setImageResource(R.drawable.ic_bookmark)
                    setColorFilter(0xFFAAAAAA.toInt())
                }
                background = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                    getDrawable(tv.resourceId)
                }
                isClickable = true
                isFocusable = true
                setPadding((4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt())
            }

            // ── Per-chapter 3-dots button ─────────────────────────────────────
            val chapterDots = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (36 * dp).toInt(), LinearLayout.LayoutParams.MATCH_PARENT
                ).also { lp -> lp.marginEnd = (4 * dp).toInt() }
                setImageResource(R.drawable.ic_more_vert)
                setColorFilter(0xFF888888.toInt())
                background = TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
                    getDrawable(tv.resourceId)
                }
                isClickable = true
                isFocusable = true
                setPadding((6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt(), (6 * dp).toInt())
            }

            // ── Row layout ────────────────────────────────────────────────────
            val row = LinearLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
                )
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                addView(badge)
                addView(label)
                addView(bookmarkIcon)
                addView(chapterDots)
            }

            card.addView(row)

            // ── Helper: apply bookmark visual and persist ─────────────────────
            fun applyBookmark(bookmarked: Boolean) {
                setBookmark(bookTitle, index, bookmarked)
                if (bookmarked) {
                    bookmarkIcon.setImageResource(R.drawable.ic_bookmark_filled)
                    bookmarkIcon.clearColorFilter()
                    Toast.makeText(this, "Bookmarked: Chapter ${index + 1}", Toast.LENGTH_SHORT).show()
                } else {
                    bookmarkIcon.setImageResource(R.drawable.ic_bookmark)
                    bookmarkIcon.setColorFilter(0xFFAAAAAA.toInt())
                    Toast.makeText(this, "Bookmark removed from Chapter ${index + 1}", Toast.LENGTH_SHORT).show()
                }
            }

            // ── Bookmark icon click (direct toggle) ───────────────────────────
            bookmarkIcon.setOnClickListener {
                val nowBookmarked = !isBookmarked(bookmarkPrefs, bookTitle, index)
                applyBookmark(nowBookmarked)
            }

            // ── Per-chapter 3-dots popup (Add Bookmark, Close) ───────────────
            chapterDots.setOnClickListener { anchor ->
                val popupView = LayoutInflater.from(this)
                    .inflate(R.layout.chapter_3dots_menu, null)

                val popup = PopupWindow(
                    popupView,
                    (220 * dp).toInt(),
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
                ).apply {
                    elevation = 12 * dp
                    isOutsideTouchable = true
                }

                val bookmarkRow = popupView.findViewById<View>(R.id.chapter_menu_bookmark)
                val bookmarkLbl = popupView.findViewById<TextView>(R.id.chapter_menu_bookmark_label)
                val bookmarkIco = popupView.findViewById<ImageView>(R.id.chapter_menu_bookmark_icon)

                // ✅ FIX: Read from persistent prefs, not in-memory set
                val currentlyBookmarked = isBookmarked(bookmarkPrefs, bookTitle, index)
                if (currentlyBookmarked) {
                    bookmarkLbl.text = "Remove Bookmark"
                    bookmarkIco.setImageResource(R.drawable.ic_bookmark_filled)
                    bookmarkIco.clearColorFilter()
                } else {
                    bookmarkLbl.text = "Add Bookmark"
                    bookmarkIco.setImageResource(R.drawable.ic_bookmark)
                    bookmarkIco.setColorFilter(0xFF6A1B9A.toInt())
                }

                bookmarkRow.setOnClickListener {
                    val nowBookmarked = !isBookmarked(bookmarkPrefs, bookTitle, index)
                    applyBookmark(nowBookmarked)
                    popup.dismiss()
                }

                popupView.findViewById<View>(R.id.chapter_menu_close).setOnClickListener {
                    popup.dismiss()
                }

                popup.showAsDropDown(anchor, -(170 * dp).toInt(), 0, Gravity.START)
            }

            // ── Chapter card tap → Reading screen ────────────────────────────
            card.setOnClickListener {
                prefs.edit()
                    .putString("LAST_READ_BOOK",    bookTitle)
                    .putString("LAST_READ_AUTHOR",  bookAuthor)
                    .putString("LAST_READ_CHAPTER", chapterTitle)
                    .putString("LAST_READ_COURSE",  bookCourse)
                    .putString("LAST_READ_YEAR",    bookYear)
                    .apply()

                startActivity(
                    Intent(this, ReadingActivity::class.java).apply {
                        putExtra("CHAPTER_TITLE",  chapterTitle)
                        putExtra("CHAPTER_INDEX",  index + 1)
                        putExtra("TOTAL_CHAPTERS", bookChapters)
                        putExtra("BOOK_TITLE",     bookTitle)
                        putExtra("BOOK_COURSE",    bookCourse)
                    }
                )
            }

            container.addView(card)
        }

        setupBottomNavigation()
    }

    private fun buildGenericTitles(count: Int): List<String> =
        (1..count).map { n ->
            when (n) {
                1    -> "Introduction"
                count -> "Final Review & Assessment"
                else -> "Module $n"
            }
        }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java)); finish()
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java)); finish()
        }
    }
}
