package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView

class HistoryActivity : ComponentActivity() {

    private val historyItems = mutableListOf<Pair<MaterialCardView, String>>()
    private var hamburgerPopup: PopupWindow? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.history___1)

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        // ── Populate history items ────────────────────────────────────────────
        val lastBook    = prefs.getString("LAST_READ_BOOK",    null)
        val lastChapter = prefs.getString("LAST_READ_CHAPTER", null)
        val lastCourse  = prefs.getString("LAST_READ_COURSE",  null)

        val selectedBook   = prefs.getString("SELECTED_BOOK",   null)
        val selectedCourse = prefs.getString("SELECTED_COURSE", null)
        val selectedYear   = prefs.getString("SELECTED_YEAR",   null)

        val item1 = findViewById<MaterialCardView>(R.id.history_item_1)
        val item1Texts = findTextViews(item1)
        if (item1Texts.size >= 2) {
            if (lastBook != null) {
                item1Texts[0].text = lastBook
                val chapterLabel = lastChapter?.substringBefore(":") ?: "Last chapter"
                val courseLabel  = if (!lastCourse.isNullOrBlank()) " · $lastCourse" else ""
                item1Texts[1].text = "$chapterLabel · Just now$courseLabel"
            } else if (selectedBook != null) {
                item1Texts[0].text = selectedBook
                val courseLabel = if (!selectedCourse.isNullOrBlank()) " · $selectedCourse" else ""
                item1Texts[1].text = "Not started yet$courseLabel"
            }
        }

        val item2 = findViewById<MaterialCardView>(R.id.history_item_2)
        val item2Texts = findTextViews(item2)
        if (item2Texts.size >= 2 && selectedBook != null && selectedBook != lastBook) {
            item2Texts[0].text = selectedBook
            val yearLabel = if (!selectedYear.isNullOrBlank()) " · $selectedYear" else ""
            item2Texts[1].text = "Selected book$yearLabel"
        }

        historyItems.clear()
        historyItems.add(Pair(item1, buildSearchText(item1)))
        historyItems.add(Pair(item2, buildSearchText(item2)))

        item1.setOnClickListener {
            val title = if (lastBook != null) lastBook else selectedBook
            if (title != null) {
                startActivity(Intent(this, LibraryDetailsActivity::class.java).putExtra("BOOK_TITLE", title))
            }
        }
        item2.setOnClickListener {
            if (selectedBook != null) {
                startActivity(Intent(this, LibraryDetailsActivity::class.java).putExtra("BOOK_TITLE", selectedBook))
            }
        }

        // ── Search setup ──────────────────────────────────────────────────────
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }
        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            showAllItems()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filterItems(s?.toString() ?: "", noResults) }
        })
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }

        // ── Hamburger PopupWindow ─────────────────────────────────────────────
        val menuButton = findViewById<ImageView>(R.id.menu_button)
        menuButton.setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) {
                hamburgerPopup?.dismiss()
            } else {
                showHamburgerMenu(anchor)
            }
        }

        setupNavigation()
    }

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this)
            .inflate(R.layout.hamburger_dropdown_menu, null)

        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView,
            (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true  // focusable = true → blocks ALL background touches until dismissed
        ).apply {
            elevation = 12 * dp
            animationStyle = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }

        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, AboutUsActivity::class.java))
        }

        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(
            anchor,
            Gravity.NO_GRAVITY,
            loc[0],
            loc[1] + anchor.height + (4 * dp).toInt()
        )
        hamburgerPopup = popup
    }

    private fun findTextViews(view: View): List<TextView> {
        val result = mutableListOf<TextView>()
        if (view is TextView) { result.add(view); return result }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) result.addAll(findTextViews(view.getChildAt(i)))
        }
        return result
    }

    private fun buildSearchText(card: MaterialCardView): String =
        findTextViews(card).joinToString(" ") { it.text }

    private fun filterItems(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        historyItems.forEach { (card, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            card.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAllItems() {
        historyItems.forEach { (card, _) -> card.visibility = View.VISIBLE }
    }

    private fun setupNavigation() {
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_browse)?.setOnClickListener {
            startActivity(Intent(this, BrowseActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
