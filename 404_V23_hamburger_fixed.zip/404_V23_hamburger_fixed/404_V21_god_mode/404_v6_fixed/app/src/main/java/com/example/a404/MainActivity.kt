package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Allow our content to draw behind the gesture navigation bar ONLY.
        // The status bar colour is controlled by the theme (#FF6A1B9A) so we
        // do NOT call enableEdgeToEdge() which would make the top bar pink/purple.
        WindowCompat.setDecorFitsSystemWindows(window, true)

        setContentView(R.layout.titleloadingscreen)

        Handler(Looper.getMainLooper()).postDelayed({
            val prefs         = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            val profileDone   = prefs.getBoolean("PROFILE_SETUP_DONE", false)
            val savedCourse   = prefs.getString("SELECTED_COURSE", null)
            val savedYear     = prefs.getString("SELECTED_YEAR", null)

            val destination = if (!profileDone || savedCourse == null || savedYear == null) {
                // First launch — show the Welcome / profile-setup screen
                Intent(this, ChoosingPhaseActivity::class.java)
            } else {
                // Returning user — go straight to Library with their saved course/year
                Intent(this, LibraryActivity::class.java)
            }

            startActivity(destination)
            finish()
        }, 2000) // 2-second splash
    }
}
