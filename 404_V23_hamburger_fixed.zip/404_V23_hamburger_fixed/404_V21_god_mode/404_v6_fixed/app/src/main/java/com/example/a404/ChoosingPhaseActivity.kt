package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView

// ── Book data model ───────────────────────────────────────────────────────────
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String
)

class ChoosingPhaseActivity : ComponentActivity() {

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear: MaterialCardView? = null
    private var bookConfirmed = false

    private val courseLabels = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )

    private val yearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")

    private val bookCatalog: Map<String, BookData> = mapOf(

        // ── BS Computer Science ───────────────────────────────────────────────
        "BS Computer Science|1st Year" to BookData(
            title       = "Foundations of Computing",
            author      = "James R. Hawkins",
            description = "An entry-level guide to computational thinking, binary systems, and basic algorithms.",
            chapters    = 10,
            course      = "BS Computer Science",
            year        = "1st Year"
        ),
        "BS Computer Science|2nd Year" to BookData(
            title       = "Data Structures & Algorithms",
            author      = "Maria Santos",
            description = "Covers arrays, linked lists, trees, sorting, and complexity analysis with practical exercises.",
            chapters    = 14,
            course      = "BS Computer Science",
            year        = "2nd Year"
        ),
        "BS Computer Science|3rd Year" to BookData(
            title       = "Operating Systems Concepts",
            author      = "Dr. Lena Park",
            description = "Deep dive into process management, memory models, file systems, and concurrency.",
            chapters    = 16,
            course      = "BS Computer Science",
            year        = "3rd Year"
        ),
        "BS Computer Science|4th Year" to BookData(
            title       = "Software Engineering Principles",
            author      = "Carlos Mendez",
            description = "Agile methodologies, design patterns, testing strategies, and large-scale system design.",
            chapters    = 12,
            course      = "BS Computer Science",
            year        = "4th Year"
        ),

        // ── BS Information Technology ─────────────────────────────────────────
        "BS Information Technology|1st Year" to BookData(
            title       = "Introduction to IT Systems",
            author      = "Grace Villanueva",
            description = "Overview of hardware, software, networking basics, and IT support fundamentals.",
            chapters    = 10,
            course      = "BS Information Technology",
            year        = "1st Year"
        ),
        "BS Information Technology|2nd Year" to BookData(
            title       = "Database Management Systems",
            author      = "Prof. Alan Reyes",
            description = "Relational models, SQL queries, normalization, and database administration essentials.",
            chapters    = 13,
            course      = "BS Information Technology",
            year        = "2nd Year"
        ),
        "BS Information Technology|3rd Year" to BookData(
            title       = "Network Administration",
            author      = "Sandra Kim",
            description = "TCP/IP protocol stack, LAN/WAN configuration, security policies, and cloud infrastructure.",
            chapters    = 15,
            course      = "BS Information Technology",
            year        = "3rd Year"
        ),
        "BS Information Technology|4th Year" to BookData(
            title       = "IT Project Management",
            author      = "Roberto Cruz",
            description = "Project planning, risk management, team coordination, and IT governance frameworks.",
            chapters    = 11,
            course      = "BS Information Technology",
            year        = "4th Year"
        ),

        // ── BS Multimedia Computing ───────────────────────────────────────────
        "BS Multimedia Computing|1st Year" to BookData(
            title       = "Digital Media Foundations",
            author      = "Nina Torres",
            description = "Introduction to digital images, audio, video, and the tools used in media production.",
            chapters    = 9,
            course      = "BS Multimedia Computing",
            year        = "1st Year"
        ),
        "BS Multimedia Computing|2nd Year" to BookData(
            title       = "2D Animation & Design",
            author      = "Kenji Watanabe",
            description = "Principles of animation, storyboarding, vector design, and Adobe suite workflows.",
            chapters    = 12,
            course      = "BS Multimedia Computing",
            year        = "2nd Year"
        ),
        "BS Multimedia Computing|3rd Year" to BookData(
            title       = "Interactive Media Development",
            author      = "Alicia Fernandez",
            description = "Building interactive experiences with HTML5 Canvas, JavaScript, and game-design patterns.",
            chapters    = 14,
            course      = "BS Multimedia Computing",
            year        = "3rd Year"
        ),
        "BS Multimedia Computing|4th Year" to BookData(
            title       = "3D Modeling & Visualization",
            author      = "Dr. Marcus Webb",
            description = "3D asset creation, rigging, rendering pipelines, and real-time visualization techniques.",
            chapters    = 13,
            course      = "BS Multimedia Computing",
            year        = "4th Year"
        ),

        // ── BS Applied Computer Technology ────────────────────────────────────
        "BS Applied Computer Technology|1st Year" to BookData(
            title       = "Computer Hardware Essentials",
            author      = "Dante Reyes",
            description = "PC components, assembly, troubleshooting, and entry-level electronics fundamentals.",
            chapters    = 10,
            course      = "BS Applied Computer Technology",
            year        = "1st Year"
        ),
        "BS Applied Computer Technology|2nd Year" to BookData(
            title       = "Embedded Systems Programming",
            author      = "Prof. Erika Lim",
            description = "Microcontroller programming, GPIO, sensors, and real-time system concepts using C.",
            chapters    = 13,
            course      = "BS Applied Computer Technology",
            year        = "2nd Year"
        ),
        "BS Applied Computer Technology|3rd Year" to BookData(
            title       = "Industrial Automation & IoT",
            author      = "Samuel Okafor",
            description = "PLC programming, IoT protocols, MQTT, and integrating sensors with cloud platforms.",
            chapters    = 14,
            course      = "BS Applied Computer Technology",
            year        = "3rd Year"
        ),
        "BS Applied Computer Technology|4th Year" to BookData(
            title       = "Applied Systems Capstone",
            author      = "Dr. Yvonne Castillo",
            description = "End-to-end applied project: design, prototype, test, and deploy a complete tech solution.",
            chapters    = 8,
            course      = "BS Applied Computer Technology",
            year        = "4th Year"
        )
    )

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        val btnContinue    = findViewById<Button>(R.id.btn_continue)
        val tvHint         = findViewById<TextView>(R.id.tv_book_hint)
        val bookGridLayout = findViewById<View>(R.id.book_grid)
        val bookCard       = findViewById<MaterialCardView>(R.id.selectionbook_1)
        val tvBookTitle    = findViewById<TextView>(R.id.book_title_label)
        val tvBookAuthor   = findViewById<TextView>(R.id.book_author_label)
        val tvBookDesc     = findViewById<TextView>(R.id.book_desc_label)
        val tvBookChapters = findViewById<TextView>(R.id.book_chapters_label)

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                val newSelected = selectCard(card, courses, selectedCourse)
                selectedCourse = newSelected
                courseIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                refreshBookCard(tvHint, bookGridLayout, bookCard,
                    tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters)
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        val yearChips = listOf(
            findViewById<MaterialCardView>(R.id.chip_year_1),
            findViewById<MaterialCardView>(R.id.chip_year_2),
            findViewById<MaterialCardView>(R.id.chip_year_3),
            findViewById<MaterialCardView>(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                val newSelected = selectCard(chip, yearChips, selectedYear)
                selectedYear = newSelected
                yearIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                refreshBookCard(tvHint, bookGridLayout, bookCard,
                    tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters)
            }
        }

        // ── Book card tap = confirm / deconfirm ───────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex >= 0 && yearIndex >= 0) {
                bookConfirmed = !bookConfirmed
                val density = resources.displayMetrics.density
                if (bookConfirmed) {
                    bookCard.strokeWidth = (strokeSelected * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                    bookCard.setCardBackgroundColor(colorSelected)
                    tintCardText(bookCard, "#FF6A1B9A")
                } else {
                    bookCard.strokeWidth = (strokeDefault * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                    bookCard.setCardBackgroundColor(colorDefault)
                    tintCardText(bookCard, "#FF2A2A2A")
                }
            }
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            if (courseIndex < 0) {
                Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (yearIndex < 0) {
                Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!bookConfirmed) {
                Toast.makeText(this, "Please tap the book to confirm your selection",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val key  = "${courseLabels[courseIndex]}|${yearLabels[yearIndex]}"
            val book = bookCatalog[key] ?: return@setOnClickListener

            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                .putString ("SELECTED_BOOK",       book.title)
                .putString ("SELECTED_AUTHOR",     book.author)
                .putString ("SELECTED_DESC",       book.description)
                .putInt    ("SELECTED_CHAPTERS",   book.chapters)
                .putString ("SELECTED_COURSE",     book.course)
                .putString ("SELECTED_YEAR",       book.year)
                .putBoolean("PROFILE_SETUP_DONE",  true)   // mark first-run complete
                .apply()

            startActivity(Intent(this, LibraryActivity::class.java))
            finish()
        }
    }

    private fun refreshBookCard(
        tvHint: TextView,
        bookGrid: View,
        bookCard: MaterialCardView,
        tvTitle: TextView,
        tvAuthor: TextView,
        tvDesc: TextView,
        tvChapters: TextView
    ) {
        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.visibility   = View.VISIBLE
            bookGrid.visibility = View.GONE
            return
        }

        val key  = "${courseLabels[courseIndex]}|${yearLabels[yearIndex]}"
        val book = bookCatalog[key]

        if (book == null) {
            tvHint.visibility   = View.VISIBLE
            bookGrid.visibility = View.GONE
            return
        }

        tvTitle.text    = book.title
        tvAuthor.text   = "by ${book.author}"
        tvDesc.text     = book.description
        tvChapters.text = "${book.chapters} Chapters"

        // Reset visual state
        val density = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * density).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")

        tvHint.visibility   = View.GONE
        bookGrid.visibility = View.VISIBLE
    }

    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val density = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * density).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) {
            null
        } else {
            clicked.strokeWidth = (strokeSelected * density).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
