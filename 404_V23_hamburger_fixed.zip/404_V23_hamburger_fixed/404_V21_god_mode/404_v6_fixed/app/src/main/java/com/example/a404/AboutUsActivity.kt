package com.example.a404

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat

class AboutUsActivity : ComponentActivity() {

    // ─────────────────────────────────────────────────────────────────────────
    // HARDCODED TEAM PHOTOS
    // To set a profile photo before building, replace the R.drawable.* value
    // for the matching member below with your own drawable resource name.
    //
    //   1. Add your .png file to:  app/src/main/res/drawable/
    //   2. Replace the placeholder below with R.drawable.your_file_name
    //
    // See HOW_TO_SET_TEAM_PHOTOS.md for step-by-step instructions.
    // ─────────────────────────────────────────────────────────────────────────
    private val teamPhotos = arrayOf(
        R.drawable.team_photo_member_1,   // Mike Vargas       ← change this
        R.drawable.team_photo_member_2,   // Rolyn Christian   ← change this
        R.drawable.team_photo_member_3,   // Ediseth Rapis     ← change this
        R.drawable.team_photo_member_4    // Francis Claro     ← change this
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_about_us)

        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        val photoViews = arrayOf(
            findViewById<ImageView>(R.id.photo_member_1),
            findViewById<ImageView>(R.id.photo_member_2),
            findViewById<ImageView>(R.id.photo_member_3),
            findViewById<ImageView>(R.id.photo_member_4)
        )

        // Load each member's hardcoded drawable
        photoViews.forEachIndexed { i, imageView ->
            imageView.setImageResource(teamPhotos[i])
        }

        // Row clicks are intentionally disabled — photos are set at build time.
        // If you re-enable runtime editing, add click listeners here.
    }
}
