# How to Set Team Profile Photos — About Us Screen

This guide explains how to replace the purple placeholder circles with real
profile photos for each team member **before you build and distribute the app**.
No runtime picker or permissions are needed — photos are baked into the APK.

---

## Team Member Slots

| Slot | Member Name      | Drawable constant              | File to add                          |
|------|------------------|--------------------------------|--------------------------------------|
| 1    | Mike Vargas       | `R.drawable.team_photo_member_1` | `team_photo_member_1.png` (or `.jpg`) |
| 2    | Rolyn Christian   | `R.drawable.team_photo_member_2` | `team_photo_member_2.png`            |
| 3    | Ediseth Rapis     | `R.drawable.team_photo_member_3` | `team_photo_member_3.png`            |
| 4    | Francis Claro     | `R.drawable.team_photo_member_4` | `team_photo_member_4.png`            |

---

## Step-by-Step Instructions

### Step 1 — Prepare the image file

- Use a **square** image for best results (e.g. 500 × 500 px or larger).
- Accepted formats: **PNG** (recommended) or JPG.
- The app displays the photo cropped into a circle, so make sure the face
  is centred and not too close to the edges.

### Step 2 — Add the file to the drawable folder

Place your image at:

```
app/
└── src/
    └── main/
        └── res/
            └── drawable/
                ├── team_photo_member_1.png   ← drop your file here
                ├── team_photo_member_2.png
                ├── team_photo_member_3.png
                └── team_photo_member_4.png
```

> **Important:** The filename must match exactly (including the number at the
> end). If you name it something else, the build will fail with a
> "resource not found" error.

### Step 3 — Verify in Android Studio

1. Open **Android Studio**.
2. In the **Project** panel, expand  
   `app → src → main → res → drawable`.
3. You should see your new `.png` files listed alongside the existing XML drawables.
4. If they are missing, right-click the `drawable` folder and choose
   **Synchronize** or press **Ctrl+Alt+Y** (Windows/Linux) / **⌘⌥Y** (Mac).

### Step 4 — Build

Run **Build → Make Project** (or press **Ctrl+F9**) and verify there are no
errors. Then run/install as usual.

---

## Optional: Using Different Density Buckets

For crisp photos on all screen densities, you can supply separate copies in
each density folder:

```
res/drawable-mdpi/team_photo_member_1.png    (baseline ~1×)
res/drawable-xhdpi/team_photo_member_1.png   (2×)
res/drawable-xxhdpi/team_photo_member_1.png  (3×)
res/drawable-xxxhdpi/team_photo_member_1.png (4×)
```

Android will automatically pick the best match for the device. This is
optional — a single file in `drawable/` works fine for most cases.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Build error: `error: resource drawable/team_photo_member_X not found` | The file is missing or misnamed. Check spelling and that it is in `res/drawable/`. |
| Photo looks pixelated | Use a larger source image (at least 500 × 500 px recommended). |
| Photo looks cut off | Make sure the subject is centred — the app crops to a circle. |
| Still see purple circle after adding the file | Press **Build → Clean Project**, then **Build → Rebuild Project**. |

---

## Where the Code Lives

The drawable assignments are in `AboutUsActivity.kt`:

```kotlin
private val teamPhotos = arrayOf(
    R.drawable.team_photo_member_1,   // Mike Vargas
    R.drawable.team_photo_member_2,   // Rolyn Christian
    R.drawable.team_photo_member_3,   // Ediseth Rapis
    R.drawable.team_photo_member_4    // Francis Claro
)
```

To change which image a member uses, simply update the `R.drawable.*`
reference on the matching line and rebuild.
