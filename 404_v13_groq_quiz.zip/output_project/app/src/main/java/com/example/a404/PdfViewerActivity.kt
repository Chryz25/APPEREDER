package com.example.a404

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.edit
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class PdfViewerActivity : ComponentActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar:  ProgressBar
    private lateinit var tvTitle:      TextView
    private lateinit var tvZoomLevel:  TextView

    private var pdfRenderer:          PdfRenderer?          = null
    private var parcelFileDescriptor: ParcelFileDescriptor? = null

    private var pdfUrl   = ""
    private var fileName = "document.pdf"
    private var isLocal  = false

    // ── Zoom helpers ──────────────────────────────────────────────────────────

    /** Returns the ZoomableImageView for the first fully-visible page, or null. */
    private fun visibleZoomView(): ZoomableImageView? {
        val lm     = recyclerView.layoutManager as? LinearLayoutManager ?: return null
        val pos    = lm.findFirstCompletelyVisibleItemPosition()
            .takeIf { it != RecyclerView.NO_ID }
            ?: lm.findFirstVisibleItemPosition()
        if (pos == RecyclerView.NO_POSITION) return null
        return recyclerView.findViewHolderForAdapterPosition(pos)
            ?.itemView?.findViewById(R.id.pdf_page_image)
    }

    private fun updateZoomLabel() {
        val view  = visibleZoomView() ?: return
        val pct   = (view.currentScale / 1f * 100).toInt()   // rough %
        tvZoomLevel.text = "$pct%"
    }

    // ─────────────────────────────────────────────────────────────────────────

    private fun normalizeForMatch(s: String): String {
        return Uri.decode(s).lowercase()
            .replace("&", "and")
            .replace("+", " ")
            .replace(Regex("[^a-z0-9]"), "")
    }

    private fun findBookInCatalog(name: String): BookData? {
        val normalizedName = normalizeForMatch(name)
        val books = listOf(
            BookData("Foundations of Computing", "James R. Hawkins", "An entry-level guide to computational thinking, binary systems, and basic algorithms.", 10, "BS Computer Science", "1st Year"),
            BookData("Data Structures & Algorithms", "Maria Santos", "Covers arrays, linked lists, trees, sorting, and complexity analysis with practical exercises.", 14, "BS Computer Science", "2nd Year"),
            BookData("Operating Systems Concepts", "Dr. Lena Park", "Deep dive into process management, memory models, file systems, and concurrency.", 16, "BS Computer Science", "3rd Year"),
            BookData("Software Engineering Principles", "Carlos Mendez", "Agile methodologies, design patterns, testing strategies, and large-scale system design.", 12, "BS Computer Science", "4th Year"),
            BookData("Introduction to IT Systems", "Grace Villanueva", "Overview of hardware, software, networking basics, and IT support fundamentals.", 10, "BS Information Technology", "1st Year"),
            BookData("Database Management Systems", "Prof. Alan Reyes", "Relational models, SQL queries, normalization, and database administration essentials.", 13, "BS Information Technology", "2nd Year"),
            BookData("Network Administration", "Sandra Kim", "TCP/IP protocol stack, LAN/WAN configuration, security policies, and cloud infrastructure.", 15, "BS Information Technology", "3rd Year"),
            BookData("IT Project Management", "Roberto Cruz", "Project planning, risk management, team coordination, and IT governance frameworks.", 11, "BS Information Technology", "4th Year"),
            BookData("Digital Media Foundations", "Nina Torres", "Introduction to digital images, audio, video, and the tools used in media production.", 9, "BS Multimedia Computing", "1st Year"),
            BookData("2D Animation & Design", "Kenji Watanabe", "Principles of animation, storyboarding, vector design, and Adobe suite workflows.", 12, "BS Multimedia Computing", "2nd Year"),
            BookData("Interactive Media Development", "Alicia Fernandez", "Building interactive experiences with HTML5 Canvas, JavaScript, and game-design patterns.", 14, "BS Multimedia Computing", "3rd Year"),
            BookData("3D Modeling & Visualization", "Dr. Marcus Webb", "3D asset creation, rigging, rendering pipelines, and real-time visualization techniques.", 13, "BS Multimedia Computing", "4th Year"),
            BookData("Computer Hardware Essentials", "Dante Reyes", "PC components, assembly, troubleshooting, and entry-level electronics fundamentals.", 10, "BS Applied Computer Technology", "1st Year"),
            BookData("Embedded Systems Programming", "Prof. Erika Lim", "Microcontroller programming, GPIO, sensors, and real-time system concepts using C.", 13, "BS Applied Computer Technology", "2nd Year"),
            BookData("Industrial Automation & IoT", "Samuel Okafor", "PLC programming, IoT protocols, MQTT, and integrating sensors with cloud platforms.", 14, "BS Applied Computer Technology", "3rd Year"),
            BookData("Applied Systems Capstone", "Dr. Yvonne Castillo", "End-to-end applied project: design, prototype, test, and deploy a complete tech solution.", 8, "BS Applied Computer Technology", "4th Year")
        )
        return books.find {
            val normalizedTitle = normalizeForMatch(it.title)
            normalizedName.contains(normalizedTitle) || normalizedTitle.contains(normalizedName)
        }
    }

    // ── Save PDF to internal Sources/ folder and register in Downloads list ──
    private fun saveToInternalStorage(sourceFile: File) {
        try {
            val sourcesDir = File(filesDir, "Sources")
            if (!sourcesDir.exists()) sourcesDir.mkdirs()

            val catalogBook   = findBookInCatalog(fileName)
            val finalFileName = if (catalogBook != null) "${catalogBook.title}.pdf" else fileName
            val destFile      = File(sourcesDir, finalFileName)

            sourceFile.inputStream().use { input ->
                FileOutputStream(destFile).use { output -> input.copyTo(output) }
            }

            val prefs     = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            val jsonArray = JSONArray(prefs.getString("DOWNLOADED_BOOKS_LIST", "[]"))

            val bookObj = JSONObject().apply {
                if (catalogBook != null) {
                    put("title",       catalogBook.title)
                    put("author",      catalogBook.author)
                    put("description", catalogBook.description)
                    put("chapters",    catalogBook.chapters)
                    put("course",      catalogBook.course)
                    put("year",        catalogBook.year)
                } else {
                    put("title",       finalFileName.removeSuffix(".pdf"))
                    put("author",      "Downloaded Source")
                    put("description", "A manually downloaded PDF book.")
                    put("chapters",    1)
                    put("course",      "Manual Download")
                    put("year",        "")
                }
            }

            var existingIndex = -1
            for (i in 0 until jsonArray.length()) {
                if (jsonArray.getJSONObject(i).getString("title") == bookObj.getString("title")) {
                    existingIndex = i; break
                }
            }
            if (existingIndex != -1) jsonArray.put(existingIndex, bookObj) else jsonArray.put(bookObj)
            prefs.edit { putString("DOWNLOADED_BOOKS_LIST", jsonArray.toString()) }

            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("Download Complete!")
                    .setMessage("\"${bookObj.getString("title")}\" has been saved and is available offline.")
                    .setPositiveButton("Go to Downloads") { _, _ ->
                        startActivity(Intent(this, DownloadActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                        })
                        finish()
                    }
                    .setNegativeButton("Stay Here", null)
                    .show()
            }
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
            e.printStackTrace()
        }
    }

    // ── Save browse-extension view to history ─────────────────────────────────
    private fun saveBrowseHistory(displayName: String) {
        val prefs       = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val historyJson = prefs.getString("BROWSE_HISTORY", "[]") ?: "[]"
        val arr         = JSONArray(historyJson)

        val entry = JSONObject().apply {
            put("name",      displayName)
            put("url",       pdfUrl)
            put("timestamp", System.currentTimeMillis())
        }

        val filtered = JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("url") != pdfUrl) filtered.put(obj)
        }
        val merged = JSONArray()
        merged.put(entry)
        for (i in 0 until filtered.length()) merged.put(filtered.getJSONObject(i))

        prefs.edit { putString("BROWSE_HISTORY", merged.toString()) }

        prefs.edit {
            putString("LAST_READ_BOOK",    displayName.removeSuffix(".pdf"))
            putString("LAST_READ_CHAPTER", "Browse · Extension")
            putString("LAST_READ_COURSE",  "Browse Extension")
            putString("LAST_READ_YEAR",    "")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_pdf_viewer)

        pdfUrl  = intent.getStringExtra("PDF_URL")  ?: ""
        isLocal = intent.getBooleanExtra("IS_LOCAL", false)

        if (pdfUrl.isEmpty()) {
            Toast.makeText(this, "No PDF path or URL provided", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        fileName = Uri.decode(pdfUrl.substringAfterLast("/"))
        if (!fileName.lowercase().endsWith(".pdf")) fileName += ".pdf"

        recyclerView = findViewById(R.id.pdf_recycler_view)
        progressBar  = findViewById(R.id.progress_bar)
        tvTitle      = findViewById(R.id.tv_title)
        tvZoomLevel  = findViewById(R.id.tv_zoom_level)

        recyclerView.layoutManager = LinearLayoutManager(this)

        // ── Back button ───────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        // ── Download button ───────────────────────────────────────────────────
        val btnDownload = findViewById<ImageView>(R.id.btn_download)
        if (isLocal) {
            btnDownload.visibility = View.GONE
        } else {
            btnDownload.setOnClickListener { downloadPdfToInternalStorage() }
        }

        // ── Zoom buttons ──────────────────────────────────────────────────────
        findViewById<View>(R.id.btn_zoom_in).setOnClickListener {
            visibleZoomView()?.let {
                it.zoomIn()
                updateZoomLabel()
            }
        }
        findViewById<View>(R.id.btn_zoom_out).setOnClickListener {
            visibleZoomView()?.let {
                it.zoomOut()
                updateZoomLabel()
            }
        }
        findViewById<View>(R.id.btn_zoom_reset).setOnClickListener {
            visibleZoomView()?.let {
                it.resetZoom()
                tvZoomLevel.text = "100%"
            }
        }

        // Update zoom label when user scrolls to a new page
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) updateZoomLabel()
            }
        })

        // ── Save to history when opened from Browse ───────────────────────────
        if (!isLocal) saveBrowseHistory(fileName)

        if (isLocal) displayPdf(File(pdfUrl)) else fetchAndShowPdf()
    }

    private fun fetchAndShowPdf() {
        progressBar.visibility = View.VISIBLE
        val client  = OkHttpClient()
        val request = Request.Builder().url(pdfUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (!isFinishing) {
                        progressBar.visibility = View.GONE
                        Toast.makeText(this@PdfViewerActivity, "Failed to load: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread {
                        if (!isFinishing) {
                            progressBar.visibility = View.GONE
                            Toast.makeText(this@PdfViewerActivity, "Error: ${response.code}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return
                }
                val file = File(cacheDir, "temp_render.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output) }
                    }
                    runOnUiThread { if (!isFinishing) displayPdf(file) }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!isFinishing) {
                            progressBar.visibility = View.GONE
                            Toast.makeText(this@PdfViewerActivity, "Load error: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        })
    }

    private fun displayPdf(file: File) {
        progressBar.visibility = View.GONE
        if (!file.exists()) {
            Toast.makeText(this, "File not found", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer          = PdfRenderer(parcelFileDescriptor!!)
            recyclerView.adapter = PdfPageAdapter(pdfRenderer!!)
            tvTitle.text         = fileName
            tvZoomLevel.text     = "100%"
        } catch (e: Exception) {
            Toast.makeText(this, "Render Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun downloadPdfToInternalStorage() {
        Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
        val client  = OkHttpClient()
        val request = Request.Builder().url(pdfUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (!isFinishing)
                        Toast.makeText(this@PdfViewerActivity, "Download failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread {
                        if (!isFinishing)
                            Toast.makeText(this@PdfViewerActivity, "Download error: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
                val tempFile = File(cacheDir, "dl_temp_${System.currentTimeMillis()}.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                    }
                    saveToInternalStorage(tempFile)
                    tempFile.delete()
                } catch (e: Exception) {
                    runOnUiThread {
                        if (!isFinishing)
                            Toast.makeText(this@PdfViewerActivity, "Save error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        try {
            pdfRenderer?.close()
            parcelFileDescriptor?.close()
        } catch (e: Exception) {}
        super.onDestroy()
    }
}
