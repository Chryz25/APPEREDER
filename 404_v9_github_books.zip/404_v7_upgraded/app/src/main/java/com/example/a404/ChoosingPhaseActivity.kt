package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

// ── Book data model ───────────────────────────────────────────────────────────
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String,
    val downloadUrl: String = ""   // GitHub raw URL for the PDF
)

class ChoosingPhaseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  GITHUB REPOSITORIES  ★
    //  Books are fetched dynamically from these repos at runtime.
    //  Format: "username/repository-name"   (no leading slash, no .git)
    //  You can also paste a full GitHub URL — it will be normalised.
    //
    //  Examples:
    //    "octocat/Hello-World"
    //    "https://github.com/cyniccccc/UI"
    // ════════════════════════════════════════════════════════════════════════
    private val GITHUB_REPOS = listOf(
        "cyniccccc/UI"
        // ADD MORE REPOS HERE ↓
        // "another-user/another-repo",
    )
    // ════════════════════════════════════════════════════════════════════════

    private val client = OkHttpClient()

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear: MaterialCardView? = null
    private var bookConfirmed = false

    private val courseLabels = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )
    private val yearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")

    // Books loaded from GitHub: key = "Course|Year", value = BookData
    private val bookCatalog = mutableMapOf<String, BookData>()
    // All raw PDF entries fetched from GitHub (filename, repoPath)
    private val allFetchedPdfs = mutableListOf<Pair<String, String>>()

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    // UI references cached for refreshBookCard
    private lateinit var tvHint: TextView
    private lateinit var bookGridLayout: View
    private lateinit var bookCard: MaterialCardView
    private lateinit var tvBookTitle: TextView
    private lateinit var tvBookAuthor: TextView
    private lateinit var tvBookDesc: TextView
    private lateinit var tvBookChapters: TextView
    private lateinit var loadingBar: ProgressBar
    private lateinit var tvLoadingStatus: TextView
    private lateinit var btnContinue: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        btnContinue    = findViewById(R.id.btn_continue)
        tvHint         = findViewById(R.id.tv_book_hint)
        bookGridLayout = findViewById(R.id.book_grid)
        bookCard       = findViewById(R.id.selectionbook_1)
        tvBookTitle    = findViewById(R.id.book_title_label)
        tvBookAuthor   = findViewById(R.id.book_author_label)
        tvBookDesc     = findViewById(R.id.book_desc_label)
        tvBookChapters = findViewById(R.id.book_chapters_label)

        // Loading indicator — reuse the hint TextView or a separate one if it exists
        // We attempt to find a dedicated loading bar; fall back to hiding hint area
        loadingBar     = try { findViewById(R.id.books_loading)  } catch (_: Exception) { createInvisibleProgressBar() }
        tvLoadingStatus = try { findViewById(R.id.tv_loading_status) } catch (_: Exception) { createInvisibleTextView() }

        // Disable continue while loading
        btnContinue.isEnabled = false

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                val newSelected = selectCard(card, courses, selectedCourse)
                selectedCourse = newSelected
                courseIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                refreshBookCard()
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        val yearChips = listOf(
            findViewById<MaterialCardView>(R.id.chip_year_1),
            findViewById<MaterialCardView>(R.id.chip_year_2),
            findViewById<MaterialCardView>(R.id.chip_year_3),
            findViewById<MaterialCardView>(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                val newSelected = selectCard(chip, yearChips, selectedYear)
                selectedYear = newSelected
                yearIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                refreshBookCard()
            }
        }

        // ── Book card tap = confirm / deconfirm ───────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex >= 0 && yearIndex >= 0) {
                bookConfirmed = !bookConfirmed
                val density = resources.displayMetrics.density
                if (bookConfirmed) {
                    bookCard.strokeWidth = (strokeSelected * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                    bookCard.setCardBackgroundColor(colorSelected)
                    tintCardText(bookCard, "#FF6A1B9A")
                } else {
                    bookCard.strokeWidth = (strokeDefault * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                    bookCard.setCardBackgroundColor(colorDefault)
                    tintCardText(bookCard, "#FF2A2A2A")
                }
            }
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            if (courseIndex < 0) {
                Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (yearIndex < 0) {
                Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!bookConfirmed) {
                Toast.makeText(this, "Please tap the book to confirm your selection",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val key  = "${courseLabels[courseIndex]}|${yearLabels[yearIndex]}"
            val book = bookCatalog[key] ?: return@setOnClickListener

            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                .putString ("SELECTED_BOOK",       book.title)
                .putString ("SELECTED_AUTHOR",     book.author)
                .putString ("SELECTED_DESC",       book.description)
                .putInt    ("SELECTED_CHAPTERS",   book.chapters)
                .putString ("SELECTED_COURSE",     book.course)
                .putString ("SELECTED_YEAR",       book.year)
                .putString ("SELECTED_BOOK_URL",   book.downloadUrl)
                .putBoolean("PROFILE_SETUP_DONE",  true)
                .apply()

            startActivity(Intent(this, LibraryActivity::class.java))
            finish()
        }

        // ── Fetch books from GitHub ───────────────────────────────────────────
        fetchBooksFromGitHub()
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GITHUB FETCHING
    // ─────────────────────────────────────────────────────────────────────────

    /** Normalises "https://github.com/user/repo" → "user/repo" */
    private fun normaliseRepo(raw: String): String =
        raw.trim()
            .replace("https://github.com/", "")
            .replace("https://raw.githubusercontent.com/", "")
            .removeSuffix("/main")
            .removeSuffix("/")

    private fun fetchBooksFromGitHub() {
        showLoadingState(true)

        val repos = GITHUB_REPOS.map { normaliseRepo(it) }.filter { it.isNotEmpty() }

        if (repos.isEmpty()) {
            showLoadingState(false)
            tvHint.text = "No repositories configured."
            tvHint.visibility = View.VISIBLE
            return
        }

        var pending = repos.size
        allFetchedPdfs.clear()
        bookCatalog.clear()

        repos.forEach { repoPath ->
            val apiUrl  = "https://api.github.com/repos/$repoPath/contents/"
            val request = Request.Builder()
                .url(apiUrl)
                .header("Accept", "application/vnd.github.v3+json")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        pending--
                        if (pending == 0) onAllReposFetched()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val body = response.body?.string()
                    runOnUiThread {
                        pending--
                        if (response.isSuccessful && body != null) {
                            try {
                                val jsonArray = JSONArray(body)
                                for (i in 0 until jsonArray.length()) {
                                    val fileObj = jsonArray.getJSONObject(i)
                                    if (fileObj.getString("type") == "file" &&
                                        fileObj.getString("name").lowercase().endsWith(".pdf")) {
                                        allFetchedPdfs.add(
                                            Pair(fileObj.getString("name"), repoPath)
                                        )
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                        if (pending == 0) onAllReposFetched()
                    }
                }
            })
        }
    }

    /**
     * Called when every repo has responded.
     * Maps fetched PDFs into bookCatalog using filename-based course/year detection.
     * PDF naming convention (case-insensitive):
     *   • Course abbreviation anywhere in name: cs, it, mmc, act
     *   • Year anywhere in name: 1, 2, 3, 4  (or "1st", "2nd", "3rd", "4th")
     *
     * If a PDF's name contains exactly one matching course + year combo, it is mapped.
     * Otherwise it falls back to sequential slot-filling across course×year combos.
     */
    private fun onAllReposFetched() {
        showLoadingState(false)
        btnContinue.isEnabled = true

        if (allFetchedPdfs.isEmpty()) {
            tvHint.text = "No books found in the configured repositories."
            tvHint.visibility = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val courseKeywords = mapOf(
            "BS Computer Science"              to listOf("cs", "compsci", "computer_science", "computerscience"),
            "BS Information Technology"        to listOf("it", "infotech", "information_technology"),
            "BS Multimedia Computing"          to listOf("mmc", "multimedia"),
            "BS Applied Computer Technology"   to listOf("act", "applied")
        )
        val yearKeywords = mapOf(
            "1st Year" to listOf("1st", "_1_", "-1-", "year1", "yr1", "_1.", "-1."),
            "2nd Year" to listOf("2nd", "_2_", "-2-", "year2", "yr2", "_2.", "-2."),
            "3rd Year" to listOf("3rd", "_3_", "-3-", "year3", "yr3", "_3.", "-3."),
            "4th Year" to listOf("4th", "_4_", "-4-", "year4", "yr4", "_4.", "-4.")
        )

        // Try to match each PDF by filename keywords first
        val unmatched = mutableListOf<Pair<String, String>>()

        allFetchedPdfs.forEach { (fileName, repoPath) ->
            val lower = fileName.lowercase()
            val downloadUrl = "https://raw.githubusercontent.com/$repoPath/main/$fileName"
            val displayName = fileName.removeSuffix(".pdf")

            var matchedCourse: String? = null
            var matchedYear: String? = null

            for ((course, keys) in courseKeywords) {
                if (keys.any { lower.contains(it) }) { matchedCourse = course; break }
            }
            for ((year, keys) in yearKeywords) {
                if (keys.any { lower.contains(it) }) { matchedYear = year; break }
            }

            if (matchedCourse != null && matchedYear != null) {
                val key = "$matchedCourse|$matchedYear"
                if (!bookCatalog.containsKey(key)) {
                    bookCatalog[key] = buildBookData(displayName, repoPath, matchedCourse, matchedYear, downloadUrl)
                }
            } else {
                unmatched.add(Pair(fileName, repoPath))
            }
        }

        // Fill remaining slots with unmatched PDFs sequentially
        var unmatchedIdx = 0
        for (course in courseLabels) {
            for (year in yearLabels) {
                val key = "$course|$year"
                if (!bookCatalog.containsKey(key) && unmatchedIdx < unmatched.size) {
                    val (fileName, repoPath) = unmatched[unmatchedIdx++]
                    val downloadUrl = "https://raw.githubusercontent.com/$repoPath/main/$fileName"
                    val displayName = fileName.removeSuffix(".pdf")
                    bookCatalog[key] = buildBookData(displayName, repoPath, course, year, downloadUrl)
                }
            }
        }

        // Refresh UI if user had already selected course+year before load completed
        refreshBookCard()
    }

    /** Constructs a BookData from a GitHub PDF filename. */
    private fun buildBookData(
        displayName: String,
        repoPath: String,
        course: String,
        year: String,
        downloadUrl: String
    ): BookData {
        val cleanTitle = displayName
            .replace(Regex("[_\\-]+"), " ")
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            .trim()

        return BookData(
            title       = cleanTitle,
            author      = repoPath.substringBefore("/"),   // GitHub username as author
            description = "PDF available from GitHub · $repoPath",
            chapters    = 0,   // unknown until opened
            course      = course,
            year        = year,
            downloadUrl = downloadUrl
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  UI HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private fun showLoadingState(loading: Boolean) {
        if (loading) {
            tvHint.text = "Loading books from GitHub…"
            tvHint.visibility = View.VISIBLE
            bookGridLayout.visibility = View.GONE
        }
        // When done, refreshBookCard() will decide what to show
    }

    private fun refreshBookCard() {
        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.text = "Select a course and year to see the assigned book."
            tvHint.visibility   = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val key  = "${courseLabels[courseIndex]}|${yearLabels[yearIndex]}"
        val book = bookCatalog[key]

        if (book == null) {
            tvHint.text = "No book found for this course & year combination."
            tvHint.visibility   = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        tvBookTitle.text    = book.title
        tvBookAuthor.text   = "from ${book.author}"
        tvBookDesc.text     = book.description
        tvBookChapters.text = if (book.chapters > 0) "${book.chapters} Chapters" else "GitHub Repository"

        // Reset visual state
        val density = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * density).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")
        bookConfirmed = false

        tvHint.visibility         = View.GONE
        bookGridLayout.visibility = View.VISIBLE
    }

    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val density = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * density).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) {
            null
        } else {
            clicked.strokeWidth = (strokeSelected * density).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }

    // Fallback stubs so we don't crash if optional view IDs don't exist
    private fun createInvisibleProgressBar() =
        ProgressBar(this).also { it.visibility = View.GONE }

    private fun createInvisibleTextView() =
        TextView(this).also { it.visibility = View.GONE }
}
