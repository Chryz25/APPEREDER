package com.example.a404

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.cardview.widget.CardView
import androidx.core.view.WindowCompat
import androidx.core.widget.doAfterTextChanged
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

class GroqQuizActivity : ComponentActivity() {

    // NOTE: Keeping the existing project-level setup intact.
    private val GROQ_API_KEY = "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"
    private val GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
    private val GROQ_MODEL = "llama-3.3-70b-versatile"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private var questions = listOf<QuizQuestion>()
    private val userAnswers = mutableMapOf<Int, String>()
    private var quizSubmitted = false

    private var testType = QuizTestType.MULTIPLE_CHOICE
    private var answerWith = QuizSide.DEFINITION
    private var promptWith = QuizSide.TERM

    private var bookTitle = ""
    private var bookAuthor = ""
    private var bookDesc = ""
    private var bookCourse = ""
    private var bookYear = ""
    private var bookUrl = ""

    private var pdfRenderer: PdfRenderer? = null
    private var parcelFileDescriptor: ParcelFileDescriptor? = null

    private lateinit var layoutLoading: LinearLayout
    private lateinit var layoutQuiz: LinearLayout
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvHeaderSubtitle: TextView
    private lateinit var tvLoadingLabel: TextView
    private lateinit var tvBookName: TextView
    private lateinit var tvQuizMode: TextView
    private lateinit var tvQuizInstruction: TextView
    private lateinit var quizContainer: LinearLayout
    private lateinit var btnSubmitQuiz: Button
    private lateinit var btnRetryQuiz: Button
    private lateinit var cardScore: CardView
    private lateinit var tvScoreName: TextView
    private lateinit var tvScoreEmoji: TextView
    private lateinit var tvScoreLabel: TextView
    private lateinit var tvScoreSub: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_groq_quiz)

        readExtras()
        bindViews()
        bindStaticUi()

        if (bookUrl.isNotBlank()) {
            fetchPdfThenGenerate()
        } else {
            generateFromBookInfo()
        }
    }

    override fun onDestroy() {
        closePdfRenderer()
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }

    private fun readExtras() {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        bookTitle = intent.getStringExtra("BOOK_TITLE") ?: prefs.getString("SELECTED_BOOK", "") ?: ""
        bookAuthor = intent.getStringExtra("BOOK_AUTHOR") ?: prefs.getString("SELECTED_AUTHOR", "") ?: ""
        bookDesc = intent.getStringExtra("BOOK_DESC") ?: prefs.getString("SELECTED_DESC", "") ?: ""
        bookCourse = intent.getStringExtra("BOOK_COURSE") ?: prefs.getString("SELECTED_COURSE", "") ?: ""
        bookYear = intent.getStringExtra("BOOK_YEAR") ?: prefs.getString("SELECTED_YEAR", "") ?: ""
        bookUrl = intent.getStringExtra("BOOK_URL") ?: prefs.getString("SELECTED_BOOK_URL", "") ?: ""
        testType = QuizTestType.from(intent.getStringExtra(QuizIntentExtras.EXTRA_TEST_TYPE))
        answerWith = QuizSide.from(intent.getStringExtra(QuizIntentExtras.EXTRA_ANSWER_WITH))
        promptWith = QuizSide.from(intent.getStringExtra(QuizIntentExtras.EXTRA_PROMPT_WITH))
        if (promptWith == answerWith) promptWith = answerWith.opposite()
    }

    private fun bindViews() {
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }
        layoutLoading = findViewById(R.id.layout_loading)
        layoutQuiz = findViewById(R.id.layout_quiz)
        tvHeaderTitle = findViewById(R.id.tv_header_title)
        tvHeaderSubtitle = findViewById(R.id.tv_header_subtitle)
        tvLoadingLabel = findViewById(R.id.tv_loading_label)
        tvBookName = findViewById(R.id.tv_book_name)
        tvQuizMode = findViewById(R.id.tv_quiz_mode)
        tvQuizInstruction = findViewById(R.id.tv_quiz_instruction)
        quizContainer = findViewById(R.id.quiz_questions_container)
        btnSubmitQuiz = findViewById(R.id.btn_submit_quiz)
        btnRetryQuiz = findViewById(R.id.btn_retry_quiz)
        cardScore = findViewById(R.id.card_score)
        tvScoreName = findViewById(R.id.tv_score_name)
        tvScoreEmoji = findViewById(R.id.tv_score_emoji)
        tvScoreLabel = findViewById(R.id.tv_score_label)
        tvScoreSub = findViewById(R.id.tv_score_sub)

        btnSubmitQuiz.setOnClickListener { submitQuiz() }
        btnRetryQuiz.setOnClickListener { retryQuiz() }
    }

    private fun bindStaticUi() {
        tvHeaderTitle.text = testType.displayName
        tvHeaderSubtitle.text = "Prompt with ${promptWith.displayName} • Answer with ${answerWith.displayName}"
        tvBookName.text = bookTitle.ifBlank { "Study test" }
        tvQuizMode.text = "Prompt with ${promptWith.displayName} • Answer with ${answerWith.displayName}"
        tvQuizInstruction.text = when (testType) {
            QuizTestType.TRUE_FALSE -> "Choose True or False for each prompt."
            QuizTestType.MULTIPLE_CHOICE -> "Choose the best answer from 4 choices."
            QuizTestType.WRITTEN -> "Type the best answer for each prompt."
        }
    }

    private fun fetchPdfThenGenerate() {
        updateLoadingLabel("Reading your material…")

        val request = Request.Builder().url(bookUrl).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) generateFromBookInfo()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body
                if (!response.isSuccessful || body == null) {
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) generateFromBookInfo()
                    }
                    return
                }

                val file = File(cacheDir, "quiz_pdf_${System.currentTimeMillis()}.pdf")
                try {
                    body.byteStream().use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output) }
                    }
                    val pdfContext = extractPdfText(file)
                    runOnUiThread {
                        if (isFinishing || isDestroyed) return@runOnUiThread
                        generateQuizQuestions(pdfContext.ifBlank { buildBookContext() })
                    }
                } catch (_: Exception) {
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) generateFromBookInfo()
                    }
                }
            }
        })
    }

    private fun extractPdfText(file: File): String {
        return try {
            closePdfRenderer()
            parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pdfRenderer = PdfRenderer(parcelFileDescriptor!!)
            buildString {
                appendLine("PDF file: ${file.name}")
                appendLine("Page count: ${pdfRenderer?.pageCount ?: 0}")
                appendLine("Book title: $bookTitle")
                appendLine("Course: $bookCourse")
                appendLine("Description: $bookDesc")
                appendLine("Use the material above as the source for a ${testType.displayName.lowercase(Locale.US)} test.")
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun closePdfRenderer() {
        try {
            pdfRenderer?.close()
        } catch (_: Exception) {
        }
        try {
            parcelFileDescriptor?.close()
        } catch (_: Exception) {
        }
        pdfRenderer = null
        parcelFileDescriptor = null
    }

    private fun buildBookContext(): String =
        """
        Book Title: $bookTitle
        Author: $bookAuthor
        Course: $bookCourse
        Year: $bookYear
        Description: ${bookDesc.ifBlank { "A course resource for $bookCourse students." }}
        """.trimIndent()

    private fun generateFromBookInfo() {
        generateQuizQuestions(buildBookContext())
    }

    private fun generateQuizQuestions(context: String) {
        updateLoadingLabel("Generating ${testType.displayName.lowercase(Locale.US)} test…")
        callGroq(buildQuizPrompt(context)) { responseText ->
            parseQuizResponse(responseText)
        }
    }

    private fun buildQuizPrompt(context: String): String {
        val pairingInstruction = when {
            promptWith == QuizSide.TERM && answerWith == QuizSide.DEFINITION ->
                "Show the learner a TERM and assess the matching DEFINITION."
            promptWith == QuizSide.DEFINITION && answerWith == QuizSide.TERM ->
                "Show the learner a DEFINITION and assess the matching TERM."
            else ->
                "Use prompt and answer sides that stay logically different and easy to study."
        }

        return when (testType) {
            QuizTestType.MULTIPLE_CHOICE ->
                """
                You are creating a study test from the academic material below.

                Configuration:
                - Test type: Multiple choice
                - Prompt with: ${promptWith.displayName}
                - Answer with: ${answerWith.displayName}
                - Instruction: $pairingInstruction

                Rules:
                - Create exactly 10 questions.
                - Focus on important terms and definitions from the material.
                - Each question must use the selected prompt side.
                - Each correct answer must use the selected answer side.
                - Provide exactly 4 choices only for every question.
                - Do not add A/B/C/D, numbers, bullets, or labels inside the choices.
                - Wrong choices must be plausible but incorrect.
                - Keep prompt and choices concise.

                Return ONLY valid JSON in this exact format:
                [
                  {
                    "prompt": "Prompt text shown to the learner",
                    "choices": ["Choice 1", "Choice 2", "Choice 3", "Choice 4"],
                    "answer": "Correct choice"
                  }
                ]

                Material:
                $context
                """.trimIndent()

            QuizTestType.TRUE_FALSE ->
                """
                You are creating a study test from the academic material below.

                Configuration:
                - Test type: True / False
                - Prompt with: ${promptWith.displayName}
                - Answer with: ${answerWith.displayName}
                - Instruction: $pairingInstruction

                Rules:
                - Create exactly 10 questions.
                - Focus on important terms and definitions from the material.
                - Each item must show the selected prompt side first.
                - Then write a statement about the selected answer side that is either correct or incorrect.
                - Mix true and false items.
                - Keep each prompt concise.
                - The learner must answer only True or False.
                - Return the answer strictly as either "True" or "False".

                Return ONLY valid JSON in this exact format:
                [
                  {
                    "prompt": "Prompt side followed by a statement to evaluate",
                    "answer": "True"
                  }
                ]

                Material:
                $context
                """.trimIndent()

            QuizTestType.WRITTEN ->
                """
                You are creating a study test from the academic material below.

                Configuration:
                - Test type: Written
                - Prompt with: ${promptWith.displayName}
                - Answer with: ${answerWith.displayName}
                - Instruction: $pairingInstruction

                Rules:
                - Create exactly 10 questions.
                - Focus on important terms and definitions from the material.
                - Each prompt must use the selected prompt side.
                - Each answer must use the selected answer side.
                - Answers should be short, direct, and easy to grade.
                - Do not include explanations.

                Return ONLY valid JSON in this exact format:
                [
                  {
                    "prompt": "Prompt text shown to the learner",
                    "answer": "Expected written answer"
                  }
                ]

                Material:
                $context
                """.trimIndent()
        }
    }

    private fun callGroq(prompt: String, onSuccess: (String) -> Unit) {
        val json = JSONObject().apply {
            put("model", GROQ_MODEL)
            put("max_tokens", 2200)
            put("temperature", 0.6)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
        }

        val requestBody = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(GROQ_API_URL)
            .header("Authorization", "Bearer $GROQ_API_KEY")
            .header("Content-Type", "application/json")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) showError("Network error: ${e.message}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val bodyStr = response.body?.string() ?: ""
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (!response.isSuccessful) {
                        showError("Groq API error ${response.code}: check your API key.")
                        return@runOnUiThread
                    }

                    try {
                        val content = JSONObject(bodyStr)
                            .getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        onSuccess(content)
                    } catch (_: Exception) {
                        showError("Failed to parse Groq response.")
                    }
                }
            }
        })
    }

    private fun parseQuizResponse(raw: String) {
        val cleaned = raw
            .replace(Regex("```json\\s*"), "")
            .replace(Regex("```\\s*"), "")
            .trim()

        try {
            val array = JSONArray(cleaned)
            val parsed = mutableListOf<QuizQuestion>()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val prompt = obj.optString("prompt")
                    .ifBlank { obj.optString("question") }
                    .ifBlank { obj.optString("statement") }
                val answer = when {
                    obj.has("answer") -> obj.optString("answer")
                    obj.has("isTrue") -> if (obj.optBoolean("isTrue")) "True" else "False"
                    else -> ""
                }.trim()
                val choiceList = if (obj.has("choices")) {
                    val choices = obj.getJSONArray("choices")
                    (0 until choices.length()).map { choices.getString(it).trim() }
                } else {
                    emptyList()
                }

                when (testType) {
                    QuizTestType.MULTIPLE_CHOICE -> {
                        if (prompt.isNotBlank() && answer.isNotBlank() && choiceList.size == 4) {
                            parsed.add(QuizQuestion(prompt = prompt, answer = answer, choices = choiceList))
                        }
                    }
                    QuizTestType.TRUE_FALSE -> {
                        if (prompt.isNotBlank() && answer.equals("True", true).or(answer.equals("False", true))) {
                            parsed.add(QuizQuestion(prompt = prompt, answer = answer.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() }, choices = listOf("True", "False")))
                        }
                    }
                    QuizTestType.WRITTEN -> {
                        if (prompt.isNotBlank() && answer.isNotBlank()) {
                            parsed.add(QuizQuestion(prompt = prompt, answer = answer))
                        }
                    }
                }
            }

            if (parsed.isEmpty()) {
                showError("No valid questions parsed from AI response.")
            } else {
                questions = parsed.take(10)
                buildQuizUi()
            }
        } catch (e: Exception) {
            showError("Quiz parse error: ${e.message}")
        }
    }

    private fun buildQuizUi() {
        quizContainer.removeAllViews()
        userAnswers.clear()
        quizSubmitted = false
        cardScore.visibility = View.GONE

        val dp = resources.displayMetrics.density

        questions.forEachIndexed { index, question ->
            val card = CardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (16 * dp).toInt() }
                radius = 22 * dp
                cardElevation = 4 * dp
                setCardBackgroundColor(Color.parseColor("#FF1B1430"))
            }

            val inner = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((18 * dp).toInt(), (18 * dp).toInt(), (18 * dp).toInt(), (18 * dp).toInt())
            }

            val badge = TextView(this).apply {
                text = "Question ${index + 1}"
                setTextColor(Color.parseColor("#FFE3CCFF"))
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setPadding((12 * dp).toInt(), (6 * dp).toInt(), (12 * dp).toInt(), (6 * dp).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 999f
                    setColor(Color.parseColor("#FF2A1A4D"))
                }
            }

            val prompt = TextView(this).apply {
                text = question.prompt
                setTextColor(Color.WHITE)
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setLineSpacing(0f, 1.35f)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = (14 * dp).toInt() }
            }

            inner.addView(badge)
            inner.addView(prompt)

            if (testType == QuizTestType.WRITTEN) {
                val input = EditText(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.topMargin = (16 * dp).toInt() }
                    hint = "Type your answer"
                    setTextColor(Color.WHITE)
                    setHintTextColor(Color.parseColor("#FF9B87CC"))
                    background = getDrawable(R.drawable.bg_quiz_input)
                    setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                    doAfterTextChanged { editable ->
                        if (quizSubmitted) return@doAfterTextChanged
                        val value = editable?.toString()?.trim().orEmpty()
                        if (value.isBlank()) userAnswers.remove(index) else userAnswers[index] = value
                    }
                }
                inner.addView(input)
            } else {
                question.choices.forEach { choiceText ->
                    val optionCard = createChoiceCard(choiceText)
                    optionCard.layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.topMargin = (12 * dp).toInt() }

                    optionCard.setOnClickListener {
                        if (quizSubmitted) return@setOnClickListener
                        userAnswers[index] = choiceText
                        updateChoiceSelection(inner, userAnswers[index])
                    }
                    inner.addView(optionCard)
                }
            }

            card.addView(inner)
            quizContainer.addView(card)
        }

        layoutLoading.visibility = View.GONE
        layoutQuiz.visibility = View.VISIBLE
        btnSubmitQuiz.visibility = View.VISIBLE
        btnRetryQuiz.visibility = View.GONE
    }

    private fun createChoiceCard(choiceText: String): CardView {
        val dp = resources.displayMetrics.density
        return CardView(this).apply {
            radius = 18 * dp
            cardElevation = 1.5f * dp
            setCardBackgroundColor(Color.parseColor("#FF140F26"))
            addView(TextView(context).apply {
                text = choiceText
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setLineSpacing(0f, 1.3f)
                setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
            })
        }
    }

    private fun updateChoiceSelection(container: LinearLayout, selectedChoice: String?) {
        for (childIndex in 2 until container.childCount) {
            val card = container.getChildAt(childIndex) as? CardView ?: continue
            val label = card.getChildAt(0) as? TextView ?: continue
            val isSelected = label.text.toString() == selectedChoice
            card.setCardBackgroundColor(
                if (isSelected) Color.parseColor("#FF6A1B9A") else Color.parseColor("#FF140F26")
            )
            label.setTextColor(Color.WHITE)
            card.cardElevation = if (isSelected) 4f * resources.displayMetrics.density else 1.5f * resources.displayMetrics.density
        }
    }

    private fun submitQuiz() {
        if (!allQuestionsAnswered()) {
            Toast.makeText(this, "Answer all questions before submitting.", Toast.LENGTH_SHORT).show()
            return
        }

        quizSubmitted = true
        btnSubmitQuiz.visibility = View.GONE
        btnRetryQuiz.visibility = View.VISIBLE

        var correct = 0
        val dp = resources.displayMetrics.density

        questions.forEachIndexed { index, question ->
            val answer = userAnswers[index].orEmpty()
            val card = quizContainer.getChildAt(index) as? CardView ?: return@forEachIndexed
            val inner = card.getChildAt(0) as? LinearLayout ?: return@forEachIndexed

            when (testType) {
                QuizTestType.WRITTEN -> {
                    val input = inner.getChildAt(2) as? EditText ?: return@forEachIndexed
                    input.isEnabled = false
                    val isCorrect = answersMatch(answer, question.answer)
                    if (isCorrect) correct++
                    input.background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 16 * dp
                        setColor(if (isCorrect) Color.parseColor("#FF163526") else Color.parseColor("#FF351820"))
                        setStroke((1 * dp).toInt(), if (isCorrect) Color.parseColor("#FF4CAF50") else Color.parseColor("#FFF44336"))
                    }

                    val feedback = TextView(this).apply {
                        text = if (isCorrect) {
                            "Correct answer: ${question.answer}"
                        } else {
                            "Expected answer: ${question.answer}"
                        }
                        setTextColor(if (isCorrect) Color.parseColor("#FFA5E8B3") else Color.parseColor("#FFFFB3B3"))
                        textSize = 13f
                        setLineSpacing(0f, 1.25f)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).also { it.topMargin = (10 * dp).toInt() }
                    }
                    inner.addView(feedback)
                }
                QuizTestType.MULTIPLE_CHOICE,
                QuizTestType.TRUE_FALSE -> {
                    val normalizedCorrectAnswer = question.answer.trim()
                    if (answersMatch(answer, normalizedCorrectAnswer)) correct++

                    for (childIndex in 2 until inner.childCount) {
                        val optionCard = inner.getChildAt(childIndex) as? CardView ?: continue
                        val optionLabel = optionCard.getChildAt(0) as? TextView ?: continue
                        val optionText = optionLabel.text.toString()
                        val isCorrectOption = answersMatch(optionText, normalizedCorrectAnswer)
                        val isChosenOption = answersMatch(optionText, answer)

                        when {
                            isCorrectOption -> {
                                optionCard.setCardBackgroundColor(Color.parseColor("#FF163526"))
                                optionLabel.setTextColor(Color.parseColor("#FFA5E8B3"))
                            }
                            isChosenOption -> {
                                optionCard.setCardBackgroundColor(Color.parseColor("#FF351820"))
                                optionLabel.setTextColor(Color.parseColor("#FFFFB3B3"))
                            }
                            else -> {
                                optionCard.setCardBackgroundColor(Color.parseColor("#FF140F26"))
                                optionLabel.setTextColor(Color.parseColor("#FFBCA6EE"))
                            }
                        }
                        optionCard.cardElevation = 1f * dp
                        optionCard.isClickable = false
                    }
                }
            }
        }

        showScore(correct)
        saveLastScore(correct)

        findViewById<androidx.core.widget.NestedScrollView>(R.id.scroll_content)
            ?.smoothScrollTo(0, 0)
    }

    private fun retryQuiz() {
        buildQuizUi()
    }

    private fun allQuestionsAnswered(): Boolean {
        return questions.indices.all { userAnswers[it]?.trim().isNullOrBlank().not() }
    }

    private fun answersMatch(given: String, expected: String): Boolean {
        val normalizedGiven = normalizeAnswer(given)
        val normalizedExpected = normalizeAnswer(expected)
        return normalizedGiven == normalizedExpected ||
            (normalizedGiven.length > 3 && normalizedGiven.contains(normalizedExpected)) ||
            (normalizedExpected.length > 3 && normalizedExpected.contains(normalizedGiven))
    }

    private fun normalizeAnswer(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun showScore(correct: Int) {
        val total = questions.size
        val percentage = if (total == 0) 0 else (correct * 100) / total

        val (emoji, sub, color) = when {
            percentage >= 90 -> Triple("🎉 Excellent!", "Outstanding work — you clearly know this material.", Color.parseColor("#FF7EE08F"))
            percentage >= 70 -> Triple("👍 Good job", "Strong result. A quick review could push this even higher.", Color.parseColor("#FF9BCBFF"))
            percentage >= 50 -> Triple("📘 Keep going", "You’re getting there. Review a few weak spots and try again.", Color.parseColor("#FFFFD37E"))
            else -> Triple("💪 Try again", "Keep studying — another pass will help lock these ideas in.", Color.parseColor("#FFFF9E9E"))
        }

        tvScoreEmoji.text = emoji
        tvScoreEmoji.setTextColor(color)
        tvScoreLabel.text = "$correct / $total correct ($percentage%)"
        tvScoreSub.text = sub

        val userName = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            .getString("USER_FULLNAME", "")
            .orEmpty()
        if (userName.isBlank()) {
            tvScoreName.visibility = View.GONE
        } else {
            tvScoreName.visibility = View.VISIBLE
            tvScoreName.text = "Results for $userName"
        }

        cardScore.visibility = View.VISIBLE
    }

    private fun saveLastScore(correct: Int) {
        val total = questions.size
        val percentage = if (total == 0) 0 else (correct * 100) / total
        val summary = "$percentage% • $correct/$total • ${testType.displayName}"
        getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            .edit()
            .putString(buildQuizScorePrefKey(bookTitle, bookCourse, bookYear), summary)
            .apply()
    }

    private fun updateLoadingLabel(message: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                tvLoadingLabel.text = message
            }
        }
    }

    private fun showError(message: String) {
        layoutLoading.visibility = View.VISIBLE
        layoutQuiz.visibility = View.GONE
        tvLoadingLabel.text = "⚠️ $message"
        findViewById<TextView>(R.id.tv_loading_sub).text = "Check your API configuration in GroqQuizActivity.kt"
    }
}
