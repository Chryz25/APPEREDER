package com.example.a404

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import org.json.JSONArray

/**
 * Book Detail Screen – shared entry point from Browse and Library screens.
 *
 * Receives extras:
 *  - BOOK_TITLE       : String
 *  - BOOK_AUTHOR      : String
 *  - BOOK_DESCRIPTION : String
 *  - BOOK_COURSE      : String
 *  - BOOK_YEAR        : String
 *  - BOOK_URL         : String  (Supabase public PDF URL)
 *  - SOURCE           : String  ("browse" | "library")
 *
 * Button visibility rules:
 *  - Browse  → "Read Now" + "Save Book"           (no Learn/Quiz)
 *  - Library → "Read Now" + "Save Book" + "Learn / Quiz"
 */
class BookDetailActivity : ComponentActivity() {

    companion object {
        const val SOURCE_BROWSE  = "browse"
        const val SOURCE_LIBRARY = "library"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_book_detail)

        // ── Read extras ───────────────────────────────────────────────────────
        val bookTitle  = intent.getStringExtra("BOOK_TITLE")       ?: "Unknown Book"
        val bookAuthor = intent.getStringExtra("BOOK_AUTHOR")      ?: ""
        val bookDesc   = intent.getStringExtra("BOOK_DESCRIPTION") ?: ""
        val bookCourse = intent.getStringExtra("BOOK_COURSE")      ?: ""
        val bookYear   = intent.getStringExtra("BOOK_YEAR")        ?: ""
        val bookUrl    = intent.getStringExtra("BOOK_URL")         ?: ""
        val source     = intent.getStringExtra("SOURCE")           ?: SOURCE_BROWSE

        // ── Populate UI ───────────────────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text      = bookTitle
        findViewById<TextView>(R.id.author_label).text      =
            if (bookAuthor.isNotBlank()) "by $bookAuthor" else "Supabase Library"
        findViewById<TextView>(R.id.course_year_label).text =
            if (bookCourse.isNotBlank() && bookYear.isNotBlank()) "$bookCourse · $bookYear"
            else if (bookCourse.isNotBlank()) bookCourse
            else "Library"

        val descText = bookDesc.ifBlank {
            if (bookCourse.isNotBlank())
                "A collection of PDF resources for $bookCourse students in their $bookYear."
            else
                "A PDF resource from the library."
        }
        findViewById<TextView>(R.id.book_description).text = descText

        // Cover image
        val encoded = bookTitle.replace(" ", "+").replace("&", "%26")
        val coverUrl = "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
        Glide.with(this)
            .load(coverUrl)
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(findViewById(R.id.book_cover_image))

        // ── Back button ───────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // ── Read Now button ───────────────────────────────────────────────────
        val btnReadNow = findViewById<MaterialButton>(R.id.btn_read_now)
        btnReadNow.setOnClickListener {
            if (bookUrl.isBlank()) {
                Toast.makeText(this, "No PDF URL available.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                putExtra("PDF_URL",   bookUrl)
                putExtra("IS_LOCAL",  false)
                putExtra("PDF_TITLE", bookTitle)
            })
        }

        // ── Save Book button ──────────────────────────────────────────────────
        val btnSaveBook = findViewById<MaterialButton>(R.id.btn_save_book)
        btnSaveBook.setOnClickListener {
            saveBookToLibrary(bookTitle, bookAuthor, bookDesc, bookCourse, bookYear, bookUrl)
        }

        // ── Learn / Quiz button — only visible from Library ───────────────────
        val btnLearn = findViewById<MaterialButton>(R.id.btn_learn_quiz)
        if (source == SOURCE_LIBRARY) {
            btnLearn.visibility = View.VISIBLE
            btnLearn.setOnClickListener {
                startActivity(Intent(this, QuizSetupActivity::class.java).apply {
                    putExtra("BOOK_TITLE",  bookTitle)
                    putExtra("BOOK_AUTHOR", bookAuthor)
                    putExtra("BOOK_DESC",   bookDesc)
                    putExtra("BOOK_COURSE", bookCourse)
                    putExtra("BOOK_YEAR",   bookYear)
                    putExtra("BOOK_URL",    bookUrl)
                })
            }
        } else {
            btnLearn.visibility = View.GONE
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun saveBookToLibrary(
        title: String, author: String, desc: String,
        course: String, year: String, url: String
    ) {
        val prefs = getSharedPreferences("AppPrefs", android.content.Context.MODE_PRIVATE)
        val downloadedJson = prefs.getString("DOWNLOADED_BOOKS_LIST", "[]") ?: "[]"
        try {
            val jsonArray = JSONArray(downloadedJson)
            // Check for duplicate by title + course + year
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                if (obj.optString("title") == title &&
                    obj.optString("course") == course &&
                    obj.optString("year") == year) {
                    Toast.makeText(this, "Already in Library", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            val newBook = org.json.JSONObject().apply {
                put("title",       title)
                put("author",      author)
                put("description", desc)
                put("course",      course)
                put("year",        year)
                put("downloadUrl", url)
            }
            jsonArray.put(newBook)
            prefs.edit().putString("DOWNLOADED_BOOKS_LIST", jsonArray.toString()).apply()
            Toast.makeText(this, "Saved to Library!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save book.", Toast.LENGTH_SHORT).show()
        }
    }
}
