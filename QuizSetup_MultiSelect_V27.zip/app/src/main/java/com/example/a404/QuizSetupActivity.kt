package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.bottomsheet.BottomSheetDialog

class QuizSetupActivity : ComponentActivity() {

    private lateinit var tvBookTitle: TextView
    private lateinit var tvBookMeta: TextView
    private lateinit var cardLastScore: MaterialCardView
    private lateinit var tvLastScoreValue: TextView
    private lateinit var tvAnswerWithValue: TextView
    private lateinit var tvPromptWithValue: TextView
    private lateinit var btnStartTest: MaterialButton

    private lateinit var cardTrueFalse: MaterialCardView
    private lateinit var cardMultipleChoice: MaterialCardView
    private lateinit var cardWritten: MaterialCardView
    private lateinit var tvTrueFalseTitle: TextView
    private lateinit var tvMultipleChoiceTitle: TextView
    private lateinit var tvWrittenTitle: TextView
    private lateinit var icCheckTrueFalse: ImageView
    private lateinit var icCheckMultipleChoice: ImageView
    private lateinit var icCheckWritten: ImageView

    // Multi-select set — starts with Multiple Choice pre-selected
    private val selectedTestTypes = mutableSetOf<QuizTestType>(QuizTestType.MULTIPLE_CHOICE)

    private var answerWith = QuizSide.DEFINITION
    private var promptWith = QuizSide.TERM

    private var bookTitle = ""
    private var bookAuthor = ""
    private var bookDesc = ""
    private var bookCourse = ""
    private var bookYear = ""
    private var bookUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_quiz_setup)

        readBookExtras()
        bindViews()
        bindClicks()
        populateContent()
        updateSelectedTypeUi()
        updatePromptSummaryUi()
        updateLastScoreUi()
    }

    private fun readBookExtras() {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        bookTitle = intent.getStringExtra("BOOK_TITLE") ?: prefs.getString("SELECTED_BOOK", "") ?: ""
        bookAuthor = intent.getStringExtra("BOOK_AUTHOR") ?: prefs.getString("SELECTED_AUTHOR", "") ?: ""
        bookDesc = intent.getStringExtra("BOOK_DESC") ?: prefs.getString("SELECTED_DESC", "") ?: ""
        bookCourse = intent.getStringExtra("BOOK_COURSE") ?: prefs.getString("SELECTED_COURSE", "") ?: ""
        bookYear = intent.getStringExtra("BOOK_YEAR") ?: prefs.getString("SELECTED_YEAR", "") ?: ""
        bookUrl = intent.getStringExtra("BOOK_URL") ?: prefs.getString("SELECTED_BOOK_URL", "") ?: ""
    }

    private fun bindViews() {
        findViewById<ImageView>(R.id.btn_back).setOnClickListener { finish() }

        tvBookTitle = findViewById(R.id.tv_book_title)
        tvBookMeta = findViewById(R.id.tv_book_meta)
        cardLastScore = findViewById(R.id.card_last_score)
        tvLastScoreValue = findViewById(R.id.tv_last_score_value)
        tvAnswerWithValue = findViewById(R.id.tv_answer_with_value)
        tvPromptWithValue = findViewById(R.id.tv_prompt_with_value)
        btnStartTest = findViewById(R.id.btn_start_test)

        cardTrueFalse = findViewById(R.id.card_true_false)
        cardMultipleChoice = findViewById(R.id.card_multiple_choice)
        cardWritten = findViewById(R.id.card_written)
        tvTrueFalseTitle = findViewById(R.id.tv_true_false_title)
        tvMultipleChoiceTitle = findViewById(R.id.tv_multiple_choice_title)
        tvWrittenTitle = findViewById(R.id.tv_written_title)
        icCheckTrueFalse = findViewById(R.id.ic_check_true_false)
        icCheckMultipleChoice = findViewById(R.id.ic_check_multiple_choice)
        icCheckWritten = findViewById(R.id.ic_check_written)
    }

    private fun bindClicks() {
        findViewById<MaterialCardView>(R.id.card_answer_prompt).setOnClickListener {
            showAnswerPromptBottomSheet()
        }

        cardTrueFalse.setOnClickListener { toggleTestType(QuizTestType.TRUE_FALSE) }
        cardMultipleChoice.setOnClickListener { toggleTestType(QuizTestType.MULTIPLE_CHOICE) }
        cardWritten.setOnClickListener { toggleTestType(QuizTestType.WRITTEN) }

        btnStartTest.setOnClickListener {
            if (bookTitle.isBlank() && bookDesc.isBlank() && bookUrl.isBlank()) {
                Toast.makeText(this, "No study material available for this test.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (selectedTestTypes.isEmpty()) {
                Toast.makeText(this, "Please select at least one test type.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val typesString = selectedTestTypes.joinToString(",") { it.name }
            val primaryType = selectedTestTypes.first()

            startActivity(Intent(this, GroqQuizActivity::class.java).apply {
                putExtra("BOOK_TITLE", bookTitle)
                putExtra("BOOK_AUTHOR", bookAuthor)
                putExtra("BOOK_DESC", bookDesc)
                putExtra("BOOK_COURSE", bookCourse)
                putExtra("BOOK_YEAR", bookYear)
                putExtra("BOOK_URL", bookUrl)
                putExtra(QuizIntentExtras.EXTRA_TEST_TYPE, primaryType.name)
                putExtra(QuizIntentExtras.EXTRA_TEST_TYPES, typesString)
                putExtra(QuizIntentExtras.EXTRA_ANSWER_WITH, answerWith.name)
                putExtra(QuizIntentExtras.EXTRA_PROMPT_WITH, promptWith.name)
            })
        }
    }

    private fun toggleTestType(type: QuizTestType) {
        if (selectedTestTypes.contains(type)) {
            if (selectedTestTypes.size == 1) {
                Toast.makeText(this, "At least one test type must be selected.", Toast.LENGTH_SHORT).show()
                return
            }
            selectedTestTypes.remove(type)
        } else {
            selectedTestTypes.add(type)
        }
        updateSelectedTypeUi()
    }

    private fun populateContent() {
        tvBookTitle.text = bookTitle.ifBlank { "Study test" }
        tvBookMeta.text = listOfNotNull(
            bookAuthor.takeIf { it.isNotBlank() },
            bookCourse.takeIf { it.isNotBlank() },
            bookYear.takeIf { it.isNotBlank() }
        ).joinToString(" • ").ifBlank {
            "Choose how this quiz should ask and answer questions"
        }
    }

    private fun updatePromptSummaryUi() {
        val fixed = ensureDistinctSides(answerWith, promptWith)
        answerWith = fixed.first
        promptWith = fixed.second
        tvAnswerWithValue.text = answerWith.displayName
        tvPromptWithValue.text = promptWith.displayName
    }

    private fun updateLastScoreUi() {
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val lastScore = prefs.getString(buildQuizScorePrefKey(bookTitle, bookCourse, bookYear), null)
        if (lastScore.isNullOrBlank()) {
            cardLastScore.visibility = View.GONE
        } else {
            cardLastScore.visibility = View.VISIBLE
            tvLastScoreValue.text = lastScore
        }
    }

    private fun updateSelectedTypeUi() {
        applyTypeCard(cardTrueFalse, tvTrueFalseTitle, icCheckTrueFalse, selectedTestTypes.contains(QuizTestType.TRUE_FALSE))
        applyTypeCard(cardMultipleChoice, tvMultipleChoiceTitle, icCheckMultipleChoice, selectedTestTypes.contains(QuizTestType.MULTIPLE_CHOICE))
        applyTypeCard(cardWritten, tvWrittenTitle, icCheckWritten, selectedTestTypes.contains(QuizTestType.WRITTEN))
    }

    private fun applyTypeCard(card: MaterialCardView, title: TextView, checkIcon: ImageView, selected: Boolean) {
        if (selected) {
            card.setCardBackgroundColor(android.graphics.Color.parseColor("#FF6A1B9A"))
            card.strokeColor = android.graphics.Color.parseColor("#FFD6B3FF")
            title.setTextColor(android.graphics.Color.WHITE)
            checkIcon.visibility = View.VISIBLE
        } else {
            card.setCardBackgroundColor(android.graphics.Color.parseColor("#FF1B1430"))
            card.strokeColor = android.graphics.Color.parseColor("#FF5A3F96")
            title.setTextColor(android.graphics.Color.WHITE)
            checkIcon.visibility = View.GONE
        }
    }

    private fun showAnswerPromptBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_answer_prompt, null)
        dialog.setContentView(view)

        val rbAnswerTerm = view.findViewById<RadioButton>(R.id.rb_answer_term)
        val rbAnswerDefinition = view.findViewById<RadioButton>(R.id.rb_answer_definition)
        val rbPromptTerm = view.findViewById<RadioButton>(R.id.rb_prompt_term)
        val rbPromptDefinition = view.findViewById<RadioButton>(R.id.rb_prompt_definition)
        val btnApply = view.findViewById<MaterialButton>(R.id.btn_apply_sheet)

        if (answerWith == QuizSide.TERM) rbAnswerTerm.isChecked = true else rbAnswerDefinition.isChecked = true
        if (promptWith == QuizSide.TERM) rbPromptTerm.isChecked = true else rbPromptDefinition.isChecked = true

        btnApply.setOnClickListener {
            val selectedAnswer = if (rbAnswerTerm.isChecked) QuizSide.TERM else QuizSide.DEFINITION
            var selectedPrompt = if (rbPromptTerm.isChecked) QuizSide.TERM else QuizSide.DEFINITION

            if (selectedAnswer == selectedPrompt) {
                selectedPrompt = selectedAnswer.opposite()
                Toast.makeText(
                    this,
                    "Prompt with switched to ${selectedPrompt.displayName} so both sides stay different.",
                    Toast.LENGTH_SHORT
                ).show()
            }

            answerWith = selectedAnswer
            promptWith = selectedPrompt
            updatePromptSummaryUi()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun ensureDistinctSides(answer: QuizSide, prompt: QuizSide): Pair<QuizSide, QuizSide> {
        return if (answer == prompt) answer to answer.opposite() else answer to prompt
    }
}
