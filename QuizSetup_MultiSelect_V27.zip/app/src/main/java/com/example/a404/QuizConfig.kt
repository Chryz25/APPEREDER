package com.example.a404

import java.util.Locale

enum class QuizSide(val displayName: String) {
    TERM("Term"),
    DEFINITION("Definition");

    fun opposite(): QuizSide = if (this == TERM) DEFINITION else TERM

    companion object {
        fun from(value: String?): QuizSide = entries.firstOrNull { it.name == value } ?: DEFINITION
    }
}

enum class QuizTestType(val displayName: String) {
    TRUE_FALSE("True / False"),
    MULTIPLE_CHOICE("Multiple choice"),
    WRITTEN("Written");

    companion object {
        fun from(value: String?): QuizTestType = entries.firstOrNull { it.name == value } ?: MULTIPLE_CHOICE
        fun fromSet(value: String?): Set<QuizTestType> {
            if (value.isNullOrBlank()) return setOf(MULTIPLE_CHOICE)
            return value.split(",").mapNotNull { part ->
                entries.firstOrNull { it.name == part.trim() }
            }.toSet().ifEmpty { setOf(MULTIPLE_CHOICE) }
        }
    }
}

data class QuizQuestion(
    val prompt: String,
    val answer: String,
    val choices: List<String> = emptyList()
)

object QuizIntentExtras {
    const val EXTRA_TEST_TYPE = "QUIZ_TEST_TYPE"
    const val EXTRA_TEST_TYPES = "QUIZ_TEST_TYPES"
    const val EXTRA_ANSWER_WITH = "QUIZ_ANSWER_WITH"
    const val EXTRA_PROMPT_WITH = "QUIZ_PROMPT_WITH"
}

fun sanitizeQuizKeyPart(value: String): String = value
    .trim()
    .lowercase(Locale.US)
    .replace(Regex("[^a-z0-9]+"), "_")
    .trim('_')

fun buildQuizScorePrefKey(title: String, course: String, year: String): String {
    val safeTitle = sanitizeQuizKeyPart(title.ifBlank { "untitled" })
    val safeCourse = sanitizeQuizKeyPart(course.ifBlank { "course" })
    val safeYear = sanitizeQuizKeyPart(year.ifBlank { "year" })
    return "QUIZ_LAST_SCORE_${safeTitle}_${safeCourse}_${safeYear}"
}
