package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton

/**
 * Book Detail Screen – V21
 *
 * Supports two entry points:
 *  • SOURCE = "browse"  → came from BrowseActivity    → shows: Read Now, Save Book
 *  • SOURCE = "library" → came from LibraryActivity   → shows: Read Now, Save Book, Learn/Quiz
 *
 * The three-dots overlay (top-right) is unchanged.
 */
class LibraryDetailsActivity : ComponentActivity() {

    private var specificPdfUrl: String = ""

    // ── Cover URL ─────────────────────────────────────────────────────────────

    private fun getCoverUrl(title: String): String {
        val encoded = title.replace(" ", "+").replace("&", "%26")
        return "https://covers.openlibrary.org/b/title/$encoded-L.jpg?default=false"
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.library_2)

        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        // ── Determine source ──────────────────────────────────────────────────
        // SOURCE extra: "browse" (from BrowseActivity) or "library" (from LibraryActivity)
        val source = intent.getStringExtra("SOURCE") ?: "library"
        val isFromBrowse = source == "browse"

        // ── Book metadata ─────────────────────────────────────────────────────
        // Browse passes all data via Intent extras directly.
        // Library passes BOOK_TITLE via Intent, rest via SharedPreferences.
        val bookTitle: String
        val bookAuthor: String
        val bookDesc: String
        val bookCourse: String
        val bookYear: String
        val bookUrl: String
        val bookChapters: Int

        if (isFromBrowse) {
            bookTitle    = intent.getStringExtra("BOOK_TITLE")   ?: "Unknown Book"
            bookAuthor   = intent.getStringExtra("BOOK_AUTHOR")  ?: ""
            bookDesc     = intent.getStringExtra("BOOK_DESC")    ?: ""
            bookCourse   = intent.getStringExtra("BOOK_COURSE")  ?: ""
            bookYear     = intent.getStringExtra("BOOK_YEAR")    ?: ""
            bookUrl      = intent.getStringExtra("BOOK_URL")     ?: ""
            bookChapters = intent.getIntExtra("BOOK_CHAPTERS", 0)
        } else {
            bookTitle    = intent.getStringExtra("BOOK_TITLE")
                           ?: prefs.getString("SELECTED_BOOK",    "Unknown Book") ?: "Unknown Book"
            bookAuthor   = prefs.getString("SELECTED_AUTHOR",  "") ?: ""
            bookDesc     = prefs.getString("SELECTED_DESC",    "") ?: ""
            bookCourse   = prefs.getString("SELECTED_COURSE",  "") ?: ""
            bookYear     = prefs.getString("SELECTED_YEAR",    "") ?: ""
            bookUrl      = prefs.getString("SELECTED_BOOK_URL","") ?: ""
            bookChapters = prefs.getInt("SELECTED_CHAPTERS", 0)
        }

        specificPdfUrl = bookUrl

        // ── Header ────────────────────────────────────────────────────────────
        findViewById<TextView>(R.id.detail_title).text      = bookTitle
        findViewById<TextView>(R.id.author_label).text      =
            if (bookAuthor.isNotBlank()) "by $bookAuthor" else "Supabase Library"
        findViewById<TextView>(R.id.course_year_label).text = "$bookCourse · $bookYear"

        Glide.with(this)
            .load(getCoverUrl(bookTitle))
            .placeholder(R.drawable.ic_logo)
            .error(R.drawable.ic_logo)
            .centerCrop()
            .into(findViewById(R.id.book_cover_image))

        findViewById<TextView>(R.id.book_description).text = bookDesc.ifBlank {
            "A collection of PDF resources for $bookCourse students in their $bookYear."
        }

        // ── Toolbar ───────────────────────────────────────────────────────────
        findViewById<ImageView>(R.id.back_button).setOnClickListener { finish() }

        // ── Button: Read Now ──────────────────────────────────────────────────
        val readNowBtn = findViewById<MaterialButton>(R.id.readnowbutton)
        readNowBtn.setOnClickListener {
            val urlToOpen = specificPdfUrl.ifBlank { bookUrl }
            if (urlToOpen.isNotBlank()) {
                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                    putExtra("PDF_URL",   urlToOpen)
                    putExtra("IS_LOCAL",  false)
                    putExtra("PDF_TITLE", bookTitle)
                })
            } else {
                Toast.makeText(this, "No PDF available to read.", Toast.LENGTH_SHORT).show()
            }
        }

        // ── Button: Save Book ─────────────────────────────────────────────────
        findViewById<View>(R.id.addlibrarybutton).setOnClickListener {
            addBookToLibrary(bookTitle, bookAuthor, bookDesc, bookChapters, bookCourse, bookYear)
        }

        // ── Button: Learn / Quiz (only for Library source) ────────────────────
        val learnBtn = findViewById<MaterialButton>(R.id.learnbuttn)
        if (isFromBrowse) {
            learnBtn.visibility = View.GONE
        } else {
            learnBtn.visibility = View.VISIBLE
            learnBtn.setOnClickListener {
                startActivity(Intent(this, GroqQuizActivity::class.java).apply {
                    putExtra("BOOK_TITLE",  bookTitle)
                    putExtra("BOOK_AUTHOR", bookAuthor)
                    putExtra("BOOK_DESC",   bookDesc)
                    putExtra("BOOK_COURSE", bookCourse)
                    putExtra("BOOK_YEAR",   bookYear)
                    putExtra("BOOK_URL",    specificPdfUrl)
                })
            }
        }

        // ── Three-dots overlay (unchanged) ────────────────────────────────────
        val threeDots   = findViewById<ImageView>(R.id.three_dots)
        val menuOverlay = findViewById<View>(R.id.three_dots_menu)
        threeDots.setOnClickListener { menuOverlay.visibility = View.VISIBLE }
        menuOverlay.findViewById<View>(R.id.menu_close).setOnClickListener {
            menuOverlay.visibility = View.GONE
        }
        menuOverlay.findViewById<View>(R.id.menu_download).setOnClickListener {
            menuOverlay.visibility = View.GONE
            val urlToOpen = specificPdfUrl.ifBlank { bookUrl }
            if (urlToOpen.isNotBlank()) {
                startActivity(Intent(this, PdfViewerActivity::class.java).apply {
                    putExtra("PDF_URL",   urlToOpen)
                    putExtra("IS_LOCAL",  false)
                    putExtra("PDF_TITLE", bookTitle)
                })
            } else {
                Toast.makeText(this, "No download URL available.", Toast.LENGTH_SHORT).show()
            }
        }

        // ── Background PDF Fetch (library path only – to get latest URL for Quiz) ──
        if (!isFromBrowse && bookCourse.isNotBlank() && bookYear.isNotBlank()) {
            fetchSpecificPdf(bookCourse, bookYear)
        }
    }

    // ── Background fetch (library flow) ──────────────────────────────────────

    private fun fetchSpecificPdf(course: String, year: String) {
        SupabaseRepository.fetchBooksForSlot(
            course    = course,
            year      = year,
            onSuccess = { books ->
                if (books.isNotEmpty()) {
                    specificPdfUrl = books[0].downloadUrl
                }
            },
            onError = { /* Fail silently */ }
        )
    }

    // ── Save to Library ───────────────────────────────────────────────────────

    private fun addBookToLibrary(
        title: String, author: String, desc: String,
        chapters: Int, course: String, year: String
    ) {
        val prefs   = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val list    = prefs.getString("DOWNLOADED_BOOKS_LIST", "") ?: ""
        val newItem = "$title|$author|$desc|$chapters|$course|$year|$specificPdfUrl"

        if (!list.contains(title)) {
            val newList = if (list.isEmpty()) newItem else "$list#$newItem"
            prefs.edit().putString("DOWNLOADED_BOOKS_LIST", newList).apply()
            Toast.makeText(this, "Saved to Library!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Already in Library", Toast.LENGTH_SHORT).show()
        }
    }
}
