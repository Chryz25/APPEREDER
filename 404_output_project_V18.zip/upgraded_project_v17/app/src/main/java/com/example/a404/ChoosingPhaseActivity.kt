package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

// ── Book data model ───────────────────────────────────────────────────────────
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String,
    val downloadUrl: String = ""
)

class ChoosingPhaseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  PER-SLOT GITHUB REPOSITORIES  ★
    //  Format: "username/repository-name"  OR full GitHub URL
    //  Each slot maps to one Course + Year combination.
    //  BSACT only supports 1st and 2nd Year.
    // ════════════════════════════════════════════════════════════════════════
    private val REPO_BSCS_1  = "https://github.com/cyniccccc/BSCS1"
    private val REPO_BSCS_2  = "https://github.com/cyniccccc/BSCS2"
    private val REPO_BSCS_3  = "https://github.com/cyniccccc/BSCS3"
    private val REPO_BSCS_4  = "https://github.com/cyniccccc/BSCS4"

    private val REPO_BSIT_1  = "https://github.com/cyniccccc/IT1"
    private val REPO_BSIT_2  = "https://github.com/cyniccccc/IT2"
    private val REPO_BSIT_3  = "https://github.com/cyniccccc/IT3"
    private val REPO_BSIT_4  = "https://github.com/cyniccccc/IT4"

    private val REPO_BSMC_1  = "https://github.com/cyniccccc/EMC1"
    private val REPO_BSMC_2  = "https://github.com/cyniccccc/EMC2"
    private val REPO_BSMC_3  = "https://github.com/cyniccccc/EMC3"
    private val REPO_BSMC_4  = "https://github.com/cyniccccc/EMC4"

    private val REPO_BSACT_1 = "https://github.com/cyniccccc/ACT1"
    private val REPO_BSACT_2 = "https://github.com/cyniccccc/ACT2"
    // ════════════════════════════════════════════════════════════════════════

    private val SLOT_REPOS: Map<String, String> by lazy {
        mapOf(
            "BS Computer Science|1st Year"            to normaliseRepo(REPO_BSCS_1),
            "BS Computer Science|2nd Year"            to normaliseRepo(REPO_BSCS_2),
            "BS Computer Science|3rd Year"            to normaliseRepo(REPO_BSCS_3),
            "BS Computer Science|4th Year"            to normaliseRepo(REPO_BSCS_4),
            "BS Information Technology|1st Year"      to normaliseRepo(REPO_BSIT_1),
            "BS Information Technology|2nd Year"      to normaliseRepo(REPO_BSIT_2),
            "BS Information Technology|3rd Year"      to normaliseRepo(REPO_BSIT_3),
            "BS Information Technology|4th Year"      to normaliseRepo(REPO_BSIT_4),
            "BS Multimedia Computing|1st Year"        to normaliseRepo(REPO_BSMC_1),
            "BS Multimedia Computing|2nd Year"        to normaliseRepo(REPO_BSMC_2),
            "BS Multimedia Computing|3rd Year"        to normaliseRepo(REPO_BSMC_3),
            "BS Multimedia Computing|4th Year"        to normaliseRepo(REPO_BSMC_4),
            "BS Applied Computer Technology|1st Year" to normaliseRepo(REPO_BSACT_1),
            "BS Applied Computer Technology|2nd Year" to normaliseRepo(REPO_BSACT_2)
        )
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false) // we handle retries manually
        .build()

    private val bookCatalog  = mutableMapOf<String, BookData>()
    private val pendingCount = AtomicInteger(0)
    private val MAX_RETRIES  = 2
    private val mainHandler  = Handler(Looper.getMainLooper())

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear:   MaterialCardView? = null
    private var bookConfirmed = false

    private val courseLabels   = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )
    private val allYearLabels  = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")
    private val BSACT_YEARS    = setOf("1st Year", "2nd Year")
    private val BSACT_INDEX    = 3

    private val colorSelected  = Color.parseColor("#FFFFF0E8")
    private val colorDefault   = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    private lateinit var tvHint:          TextView
    private lateinit var tvRetryStatus:   TextView
    private lateinit var progressLoading: ProgressBar
    private lateinit var bookGridLayout:  View
    private lateinit var bookCard:        MaterialCardView
    private lateinit var tvBookTitle:     TextView
    private lateinit var tvBookAuthor:    TextView
    private lateinit var tvBookDesc:      TextView
    private lateinit var tvBookChapters:  TextView
    private lateinit var btnContinue:     Button
    private lateinit var btnRetry:        Button
    private lateinit var yearChips:       List<MaterialCardView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        btnContinue     = findViewById(R.id.btn_continue)
        tvHint          = findViewById(R.id.tv_book_hint)
        bookGridLayout  = findViewById(R.id.book_grid)
        bookCard        = findViewById(R.id.selectionbook_1)
        tvBookTitle     = findViewById(R.id.book_title_label)
        tvBookAuthor    = findViewById(R.id.book_author_label)
        tvBookDesc      = findViewById(R.id.book_desc_label)
        tvBookChapters  = findViewById(R.id.book_chapters_label)
        progressLoading = findViewById(R.id.progress_loading)
        tvRetryStatus   = findViewById(R.id.tv_retry_status)
        btnRetry        = findViewById(R.id.btn_retry_load)

        // Continue button starts disabled — only enabled after book is confirmed
        btnContinue.isEnabled = false

        // ── Retry ─────────────────────────────────────────────────────────────
        btnRetry.setOnClickListener {
            bookCatalog.clear()
            fetchAllSlots()
        }

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                selectedCourse = selectCard(card, courses, selectedCourse)
                courseIndex    = if (selectedCourse != null) idx else -1
                yearIndex      = -1
                selectedYear   = null
                bookConfirmed  = false
                btnContinue.isEnabled = false
                applyYearChipVisibility()
                refreshBookCard()
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        yearChips = listOf(
            findViewById(R.id.chip_year_1),
            findViewById(R.id.chip_year_2),
            findViewById(R.id.chip_year_3),
            findViewById(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                if (chip.visibility != View.VISIBLE || !chip.isEnabled) return@setOnClickListener
                val visible = yearChips.filter { it.visibility == View.VISIBLE && it.isEnabled }
                selectedYear  = selectCard(chip, visible, selectedYear)
                yearIndex     = if (selectedYear != null) idx else -1
                bookConfirmed = false
                btnContinue.isEnabled = false
                refreshBookCard()
            }
        }

        // ── Book card: tap to confirm ─────────────────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex < 0 || yearIndex < 0) return@setOnClickListener
            if (!bookCatalog.containsKey(currentKey())) return@setOnClickListener

            bookConfirmed = !bookConfirmed
            val dp = resources.displayMetrics.density
            if (bookConfirmed) {
                bookCard.strokeWidth = (strokeSelected * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                bookCard.setCardBackgroundColor(colorSelected)
                tintCardText(bookCard, "#FF6A1B9A")
            } else {
                bookCard.strokeWidth = (strokeDefault * dp).toInt()
                bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                bookCard.setCardBackgroundColor(colorDefault)
                tintCardText(bookCard, "#FF2A2A2A")
            }
            // Enable/disable Continue based on confirmation
            btnContinue.isEnabled = bookConfirmed
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            when {
                courseIndex < 0   -> Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                yearIndex < 0     -> Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                !bookConfirmed    -> Toast.makeText(this, "Please tap the book card to confirm your selection", Toast.LENGTH_SHORT).show()
                else -> {
                    val book     = bookCatalog[currentKey()] ?: return@setOnClickListener
                    val repoPath = SLOT_REPOS[currentKey()] ?: ""
                    getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                        .putString ("SELECTED_BOOK",      book.title)
                        .putString ("SELECTED_AUTHOR",    book.author)
                        .putString ("SELECTED_DESC",      book.description)
                        .putInt    ("SELECTED_CHAPTERS",  book.chapters)
                        .putString ("SELECTED_COURSE",    book.course)
                        .putString ("SELECTED_YEAR",      book.year)
                        .putString ("SELECTED_BOOK_URL",  book.downloadUrl)
                        .putString ("SELECTED_REPO_PATH", repoPath)
                        .putBoolean("PROFILE_SETUP_DONE", true)
                        .apply()
                    startActivity(Intent(this, LibraryActivity::class.java))
                    finish()
                }
            }
        }

        // ── Initial state ─────────────────────────────────────────────────────
        tvHint.text               = "Select a course and year above to see your starter book."
        tvHint.visibility         = View.VISIBLE
        bookGridLayout.visibility = View.GONE

        fetchAllSlots()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Cancel pending requests so callbacks don't fire on a dead activity
        client.dispatcher.cancelAll()
        client.dispatcher.executorService.shutdown()
    }

    // ── Year chip visibility ──────────────────────────────────────────────────

    private fun applyYearChipVisibility() {
        val isBsact = courseIndex == BSACT_INDEX
        val dp      = resources.displayMetrics.density
        yearChips.forEachIndexed { idx, chip ->
            val yearLabel  = allYearLabels[idx]
            val shouldShow = !isBsact || BSACT_YEARS.contains(yearLabel)
            chip.visibility = if (shouldShow) View.VISIBLE else View.GONE
            chip.isEnabled  = shouldShow
            if (shouldShow) {
                chip.strokeWidth = (strokeDefault * dp).toInt()
                chip.strokeColor = Color.parseColor("#FFD6C5B4")
                chip.setCardBackgroundColor(colorDefault)
                tintCardText(chip, "#FF2A2A2A")
            }
        }
        // Always reset year when course changes
        selectedYear = null
        yearIndex    = -1
    }

    // ── Network check ─────────────────────────────────────────────────────────

    private fun isNetworkAvailable(): Boolean {
        val cm      = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps    = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ── Repo normalisation ────────────────────────────────────────────────────

    private fun normaliseRepo(raw: String): String =
        raw.trim()
           .replace("https://github.com/", "")
           .replace("https://raw.githubusercontent.com/", "")
           .removeSuffix("/main")
           .removeSuffix("/master")
           .removeSuffix("/")

    // ── Fetch all slots ───────────────────────────────────────────────────────

    private fun fetchAllSlots() {
        // Reset UI to loading state
        progressLoading.visibility = View.VISIBLE
        tvHint.text                = "Loading books from GitHub…"
        tvHint.visibility          = View.VISIBLE
        bookGridLayout.visibility  = View.GONE
        btnRetry.visibility        = View.GONE
        tvRetryStatus.visibility   = View.GONE
        btnContinue.isEnabled      = false
        bookConfirmed              = false

        if (!isNetworkAvailable()) {
            progressLoading.visibility = View.GONE
            tvHint.text                = "No internet connection."
            tvRetryStatus.text         = "Please check your connection and tap Retry."
            tvRetryStatus.visibility   = View.VISIBLE
            btnRetry.visibility        = View.VISIBLE
            return
        }

        // Deduplicate: group slots that share the same repo so we only fetch each URL once
        val repoToSlots = mutableMapOf<String, MutableList<String>>()
        for ((slotKey, repoPath) in SLOT_REPOS) {
            repoToSlots.getOrPut(repoPath) { mutableListOf() }.add(slotKey)
        }

        val uniqueRepos = repoToSlots.keys.toList()
        pendingCount.set(uniqueRepos.size)

        uniqueRepos.forEach { repoPath ->
            fetchRepo(repoPath, repoToSlots[repoPath] ?: emptyList(), attempt = 1)
        }
    }

    // ── Fetch a single repo ───────────────────────────────────────────────────

    private fun fetchRepo(repoPath: String, slots: List<String>, attempt: Int) {
        val request = Request.Builder()
            .url("https://api.github.com/repos/$repoPath/contents/")
            .header("Accept",     "application/vnd.github.v3+json")
            .header("User-Agent", "404-app-android")
            .build()

        client.newCall(request).enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                if (attempt < MAX_RETRIES) {
                    // Back-off retry: 1.5 s, then 3 s
                    mainHandler.postDelayed({
                        if (!isFinishing && !isDestroyed)
                            fetchRepo(repoPath, slots, attempt + 1)
                        else
                            safeDecrement()
                    }, attempt * 1500L)
                } else {
                    safeDecrement()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                // Read body on OkHttp thread before switching to UI thread
                val body = try { response.body?.string() } catch (_: Exception) { null }
                response.body?.close() // ensure closed

                runOnUiThread {
                    if (isFinishing || isDestroyed) {
                        pendingCount.decrementAndGet()
                        return@runOnUiThread
                    }

                    when (response.code) {
                        // Rate limited — retry with longer delay if attempts remain
                        403, 429 -> {
                            if (attempt < MAX_RETRIES) {
                                mainHandler.postDelayed({
                                    if (!isFinishing && !isDestroyed)
                                        fetchRepo(repoPath, slots, attempt + 1)
                                    else
                                        safeDecrement()
                                }, 3000L)
                                return@runOnUiThread // do NOT decrement yet
                            }
                            // Retries exhausted — fall through to decrement
                        }

                        // Repo not found — skip silently, fall through to decrement
                        404 -> { /* no-op */ }

                        // Success — parse PDF list
                        in 200..299 -> {
                            if (body != null) {
                                try {
                                    val arr = JSONArray(body)
                                    for (i in 0 until arr.length()) {
                                        val obj  = arr.getJSONObject(i)
                                        val type = obj.optString("type")
                                        val name = obj.optString("name")
                                        if (type == "file" && name.lowercase().endsWith(".pdf")) {
                                            val dlUrl = obj.optString("download_url").ifBlank {
                                                "https://raw.githubusercontent.com/$repoPath/main/$name"
                                            }
                                            // Assign this PDF to every slot using this repo
                                            slots.forEach { slotKey ->
                                                if (!bookCatalog.containsKey(slotKey)) {
                                                    val (course, year) = slotKey.split("|")
                                                    bookCatalog[slotKey] = buildBookData(
                                                        name, repoPath, course, year, dlUrl
                                                    )
                                                }
                                            }
                                            break // only take the first PDF per repo
                                        }
                                    }
                                } catch (_: Exception) { /* malformed JSON — skip */ }
                            }
                        }

                        // Any other HTTP error (5xx, redirects OkHttp didn't follow, etc.)
                        else -> { /* skip, fall through to decrement */ }
                    }

                    // Decrement for all paths except the "retry pending" early-returns above
                    if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
                }
            }
        })
    }

    /** Thread-safe decrement that calls onAllSlotsFetched() when count hits 0. */
    private fun safeDecrement() {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
            } else {
                pendingCount.decrementAndGet()
            }
        }
    }

    // ── Called when every repo fetch has resolved ─────────────────────────────

    private fun onAllSlotsFetched() {
        progressLoading.visibility = View.GONE

        if (bookCatalog.isEmpty()) {
            // All repos failed (404, network error, no PDFs found)
            tvHint.text              = "Could not load books from GitHub."
            tvHint.visibility        = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            tvRetryStatus.text       = "Check your internet or repository settings, then tap Retry."
            tvRetryStatus.visibility = View.VISIBLE
            btnRetry.visibility      = View.VISIBLE
            // Continue stays disabled — no books available
        } else {
            // Refresh the book card in case user already selected course+year
            refreshBookCard()
        }
    }

    // ── Build book data from raw GitHub API info ──────────────────────────────

    private fun buildBookData(
        fileName: String,
        repoPath: String,
        course: String,
        year: String,
        downloadUrl: String
    ): BookData {
        val displayName = fileName.removeSuffix(".pdf")
        val cleanTitle  = displayName
            .replace(Regex("[_\\-]+"), " ")
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            .trim()
        return BookData(
            title       = cleanTitle,
            author      = repoPath.substringBefore("/"),
            description = "PDF from GitHub · $repoPath",
            chapters    = 0,
            course      = course,
            year        = year,
            downloadUrl = downloadUrl
        )
    }

    // ── Book card refresh ─────────────────────────────────────────────────────

    private fun currentKey() =
        if (courseIndex >= 0 && yearIndex >= 0)
            "${courseLabels[courseIndex]}|${allYearLabels[yearIndex]}"
        else ""

    private fun refreshBookCard() {
        // Always hide retry when refreshing the card view
        btnRetry.visibility      = View.GONE
        tvRetryStatus.visibility = View.GONE

        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.text = if (courseIndex >= 0)
                "Now select your academic year."
            else
                "Select a course and year above to see your starter book."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val key  = currentKey()
        val book = bookCatalog[key]
        val stillLoading = pendingCount.get() > 0

        if (book == null) {
            tvHint.text = if (stillLoading)
                "Still loading from GitHub… please wait."
            else
                "No PDF found for this course/year in the repository."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE

            if (!stillLoading) {
                tvRetryStatus.text       = "Make sure the GitHub repository for this slot contains at least one PDF."
                tvRetryStatus.visibility = View.VISIBLE
                btnRetry.visibility      = View.VISIBLE
            }
            return
        }

        // ── Show the book card ────────────────────────────────────────────────
        tvBookTitle.text    = book.title
        tvBookAuthor.text   = "from ${book.author}"
        tvBookDesc.text     = book.description
        tvBookChapters.text = "GitHub Repository"

        val dp = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * dp).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")
        bookConfirmed         = false
        btnContinue.isEnabled = false  // user must tap the card to confirm

        tvHint.visibility         = View.GONE
        bookGridLayout.visibility = View.VISIBLE
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val dp = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * dp).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) null
        else {
            clicked.strokeWidth = (strokeSelected * dp).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
