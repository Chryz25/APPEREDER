package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.google.android.material.card.MaterialCardView
import okhttp3.*
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

// ── Book data model ───────────────────────────────────────────────────────────
data class BookData(
    val title: String,
    val author: String,
    val description: String,
    val chapters: Int,
    val course: String,
    val year: String,
    val downloadUrl: String = ""
)

class ChoosingPhaseActivity : ComponentActivity() {

    // ════════════════════════════════════════════════════════════════════════
    //  ★  PER-SLOT GITHUB REPOSITORIES  ★
    //  Each constant maps to exactly one Course + Year slot.
    //  The first PDF found at the root of that repo becomes the book.
    //  Replace the placeholder URLs with your actual repositories.
    //
    //  Format:  "username/repository-name"
    //           OR full URL: "https://github.com/user/repo"
    //
    //  BSACT only supports 1st and 2nd Year — no 3rd/4th entries needed.
    // ════════════════════════════════════════════════════════════════════════
    private val REPO_BSCS_1  = "cyniccccc/UI"   // BS Computer Science         – 1st Year
    private val REPO_BSCS_2  = "cyniccccc/UI"   // BS Computer Science         – 2nd Year
    private val REPO_BSCS_3  = "cyniccccc/UI"   // BS Computer Science         – 3rd Year
    private val REPO_BSCS_4  = "cyniccccc/UI"   // BS Computer Science         – 4th Year

    private val REPO_BSIT_1  = "cyniccccc/UI"   // BS Information Technology   – 1st Year
    private val REPO_BSIT_2  = "cyniccccc/UI"   // BS Information Technology   – 2nd Year
    private val REPO_BSIT_3  = "cyniccccc/UI"   // BS Information Technology   – 3rd Year
    private val REPO_BSIT_4  = "cyniccccc/UI"   // BS Information Technology   – 4th Year

    private val REPO_BSMC_1  = "cyniccccc/UI"   // BS Multimedia Computing     – 1st Year
    private val REPO_BSMC_2  = "cyniccccc/UI"   // BS Multimedia Computing     – 2nd Year
    private val REPO_BSMC_3  = "cyniccccc/UI"   // BS Multimedia Computing     – 3rd Year
    private val REPO_BSMC_4  = "cyniccccc/UI"   // BS Multimedia Computing     – 4th Year

    private val REPO_BSACT_1 = "cyniccccc/UI"   // BS Applied Computer Technology – 1st Year
    private val REPO_BSACT_2 = "cyniccccc/UI"   // BS Applied Computer Technology – 2nd Year
    // ════════════════════════════════════════════════════════════════════════

    // Slot key → repo path (built lazily from constants above)
    private val SLOT_REPOS: Map<String, String> by lazy {
        mapOf(
            "BS Computer Science|1st Year"            to normaliseRepo(REPO_BSCS_1),
            "BS Computer Science|2nd Year"            to normaliseRepo(REPO_BSCS_2),
            "BS Computer Science|3rd Year"            to normaliseRepo(REPO_BSCS_3),
            "BS Computer Science|4th Year"            to normaliseRepo(REPO_BSCS_4),

            "BS Information Technology|1st Year"      to normaliseRepo(REPO_BSIT_1),
            "BS Information Technology|2nd Year"      to normaliseRepo(REPO_BSIT_2),
            "BS Information Technology|3rd Year"      to normaliseRepo(REPO_BSIT_3),
            "BS Information Technology|4th Year"      to normaliseRepo(REPO_BSIT_4),

            "BS Multimedia Computing|1st Year"        to normaliseRepo(REPO_BSMC_1),
            "BS Multimedia Computing|2nd Year"        to normaliseRepo(REPO_BSMC_2),
            "BS Multimedia Computing|3rd Year"        to normaliseRepo(REPO_BSMC_3),
            "BS Multimedia Computing|4th Year"        to normaliseRepo(REPO_BSMC_4),

            // BSACT: 1st and 2nd year only
            "BS Applied Computer Technology|1st Year" to normaliseRepo(REPO_BSACT_1),
            "BS Applied Computer Technology|2nd Year" to normaliseRepo(REPO_BSACT_2)
        )
    }

    // ── FIX 1: OkHttpClient with explicit timeouts so slow networks don't
    //           silently stall and never call onFailure/onResponse ─────────────
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // Populated as GitHub responses arrive
    private val bookCatalog = mutableMapOf<String, BookData>()

    // ── FIX 2: Track fetch attempts per slot so we can retry individually ──────
    private val fetchAttempts = mutableMapOf<String, Int>()
    private val MAX_RETRIES   = 2

    // ── FIX 3: Track pending count with AtomicInteger so concurrent callbacks
    //           can't race and double-decrement ─────────────────────────────────
    private val pendingCount = java.util.concurrent.atomic.AtomicInteger(0)

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear:   MaterialCardView? = null
    private var bookConfirmed = false

    private val courseLabels = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )
    private val allYearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")

    private val BSACT_YEARS  = setOf("1st Year", "2nd Year")
    private val BSACT_INDEX  = 3

    private val colorSelected  = Color.parseColor("#FFFFF0E8")
    private val colorDefault   = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    // Cached view references
    private lateinit var tvHint:         TextView
    private lateinit var tvRetryStatus:  TextView
    private lateinit var progressLoading: ProgressBar
    private lateinit var bookGridLayout: View
    private lateinit var bookCard:       MaterialCardView
    private lateinit var tvBookTitle:    TextView
    private lateinit var tvBookAuthor:   TextView
    private lateinit var tvBookDesc:     TextView
    private lateinit var tvBookChapters: TextView
    private lateinit var btnContinue:    Button
    private lateinit var btnRetry:       Button
    private lateinit var yearChips:      List<MaterialCardView>

    // ── FIX 4: Retry handler so a "Retry" button can re-kick failed slots ──────
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        btnContinue     = findViewById(R.id.btn_continue)
        tvHint          = findViewById(R.id.tv_book_hint)
        bookGridLayout  = findViewById(R.id.book_grid)
        bookCard        = findViewById(R.id.selectionbook_1)
        tvBookTitle     = findViewById(R.id.book_title_label)
        tvBookAuthor    = findViewById(R.id.book_author_label)
        tvBookDesc      = findViewById(R.id.book_desc_label)
        tvBookChapters  = findViewById(R.id.book_chapters_label)

        // ── FIX 5: Wire up the new inline Retry button and loading indicator ──
        progressLoading = findViewById(R.id.progress_loading)
        tvRetryStatus   = findViewById(R.id.tv_retry_status)
        btnRetry        = findViewById(R.id.btn_retry_load)

        btnRetry.setOnClickListener {
            btnRetry.visibility    = View.GONE
            tvRetryStatus.visibility = View.GONE
            bookCatalog.clear()
            fetchAttempts.clear()
            fetchAllSlots()
        }

        btnContinue.isEnabled = false

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                val newSelected = selectCard(card, courses, selectedCourse)
                selectedCourse = newSelected
                courseIndex    = if (newSelected != null) idx else -1
                yearIndex      = -1
                selectedYear   = null
                bookConfirmed  = false
                applyYearChipVisibility()
                refreshBookCard()
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        yearChips = listOf(
            findViewById(R.id.chip_year_1),
            findViewById(R.id.chip_year_2),
            findViewById(R.id.chip_year_3),
            findViewById(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                if (chip.visibility != View.VISIBLE || !chip.isEnabled) return@setOnClickListener
                val visibleEnabled = yearChips.filter { it.visibility == View.VISIBLE && it.isEnabled }
                val newSelected    = selectCard(chip, visibleEnabled, selectedYear)
                selectedYear  = newSelected
                yearIndex     = if (newSelected != null) idx else -1
                bookConfirmed = false
                refreshBookCard()
            }
        }

        // ── Book card: tap to confirm / deconfirm ─────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex >= 0 && yearIndex >= 0 && bookCatalog.containsKey(currentKey())) {
                bookConfirmed = !bookConfirmed
                val dp = resources.displayMetrics.density
                if (bookConfirmed) {
                    bookCard.strokeWidth = (strokeSelected * dp).toInt()
                    bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                    bookCard.setCardBackgroundColor(colorSelected)
                    tintCardText(bookCard, "#FF6A1B9A")
                } else {
                    bookCard.strokeWidth = (strokeDefault * dp).toInt()
                    bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                    bookCard.setCardBackgroundColor(colorDefault)
                    tintCardText(bookCard, "#FF2A2A2A")
                }
            }
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            when {
                courseIndex < 0 ->
                    Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                yearIndex < 0 ->
                    Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                !bookConfirmed ->
                    Toast.makeText(this, "Please tap the book to confirm your selection", Toast.LENGTH_SHORT).show()
                else -> {
                    val book     = bookCatalog[currentKey()] ?: return@setOnClickListener
                    val repoPath = SLOT_REPOS[currentKey()] ?: ""
                    getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                        .putString ("SELECTED_BOOK",      book.title)
                        .putString ("SELECTED_AUTHOR",    book.author)
                        .putString ("SELECTED_DESC",      book.description)
                        .putInt    ("SELECTED_CHAPTERS",  book.chapters)
                        .putString ("SELECTED_COURSE",    book.course)
                        .putString ("SELECTED_YEAR",      book.year)
                        .putString ("SELECTED_BOOK_URL",  book.downloadUrl)
                        .putString ("SELECTED_REPO_PATH", repoPath)
                        .putBoolean("PROFILE_SETUP_DONE", true)
                        .apply()
                    startActivity(Intent(this, LibraryActivity::class.java))
                    finish()
                }
            }
        }

        // ── Initial state ─────────────────────────────────────────────────────
        tvHint.text              = "Select a course and year above to see your starter book."
        tvHint.visibility        = View.VISIBLE
        bookGridLayout.visibility = View.GONE

        fetchAllSlots()
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  YEAR CHIP VISIBILITY
    // ─────────────────────────────────────────────────────────────────────────
    private fun applyYearChipVisibility() {
        val isBsact = courseIndex == BSACT_INDEX
        val dp      = resources.displayMetrics.density

        yearChips.forEachIndexed { idx, chip ->
            val yearLabel  = allYearLabels[idx]
            val shouldShow = !isBsact || BSACT_YEARS.contains(yearLabel)

            chip.visibility = if (shouldShow) View.VISIBLE else View.GONE
            chip.isEnabled  = shouldShow

            if (shouldShow) {
                chip.strokeWidth = (strokeDefault * dp).toInt()
                chip.strokeColor = Color.parseColor("#FFD6C5B4")
                chip.setCardBackgroundColor(colorDefault)
                tintCardText(chip, "#FF2A2A2A")
            }
        }

        if (yearIndex >= 0 && yearChips[yearIndex].visibility == View.GONE) {
            yearIndex    = -1
            selectedYear = null
        }
        selectedYear = null
        yearIndex    = -1
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  NETWORK CHECK
    // ─────────────────────────────────────────────────────────────────────────
    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps    = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GITHUB FETCHING
    //  FIX 6: Deduplicate identical repo paths — only fetch each unique repo
    //  once, then broadcast the result to all slots that share it.
    //  This cuts 14 requests down to however many unique repos there are,
    //  which almost always means a single repo when all slots point to the
    //  same placeholder "cyniccccc/UI". Less requests = fewer failures.
    // ─────────────────────────────────────────────────────────────────────────
    private fun normaliseRepo(raw: String): String =
        raw.trim()
            .replace("https://github.com/", "")
            .replace("https://raw.githubusercontent.com/", "")
            .removeSuffix("/main")
            .removeSuffix("/")

    private fun fetchAllSlots() {
        // Show loading indicator
        progressLoading.visibility = View.VISIBLE
        tvHint.text                = "Loading books from GitHub…"
        tvHint.visibility          = View.VISIBLE
        bookGridLayout.visibility  = View.GONE
        btnRetry.visibility        = View.GONE
        tvRetryStatus.visibility   = View.GONE

        if (!isNetworkAvailable()) {
            progressLoading.visibility = View.GONE
            tvHint.text                = "No internet connection."
            tvRetryStatus.text         = "Please check your connection and tap Retry."
            tvRetryStatus.visibility   = View.VISIBLE
            btnRetry.visibility        = View.VISIBLE
            btnContinue.isEnabled      = false
            return
        }

        // Group slots by unique repoPath so we never fetch the same URL twice
        val repoToSlots = mutableMapOf<String, MutableList<String>>()
        for ((slotKey, repoPath) in SLOT_REPOS) {
            repoToSlots.getOrPut(repoPath) { mutableListOf() }.add(slotKey)
        }

        val uniqueRepos = repoToSlots.keys.toList()
        pendingCount.set(uniqueRepos.size)

        uniqueRepos.forEach { repoPath ->
            fetchRepo(repoPath, repoToSlots[repoPath] ?: emptyList(), attempt = 1)
        }
    }

    private fun fetchRepo(repoPath: String, slots: List<String>, attempt: Int) {
        val url = "https://api.github.com/repos/$repoPath/contents/"

        val request = Request.Builder()
            .url(url)
            .header("Accept",     "application/vnd.github.v3+json")
            .header("User-Agent", "404-app-android")   // FIX 7: GitHub API requires User-Agent
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // FIX 8: Retry on failure up to MAX_RETRIES times with back-off
                if (attempt < MAX_RETRIES) {
                    mainHandler.postDelayed({
                        fetchRepo(repoPath, slots, attempt + 1)
                    }, attempt * 1500L)   // 1.5 s then 3 s back-off
                } else {
                    // All retries exhausted for this repo
                    runOnUiThread {
                        if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
                    }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()

                runOnUiThread {
                    // FIX 9: Handle GitHub rate-limit (403/429) and not-found (404) explicitly
                    when {
                        response.code == 403 || response.code == 429 -> {
                            // Rate-limited — retry after a longer delay
                            if (attempt < MAX_RETRIES) {
                                mainHandler.postDelayed({
                                    fetchRepo(repoPath, slots, attempt + 1)
                                }, 3000L)
                                return@runOnUiThread
                            }
                        }
                        response.code == 404 -> {
                            // Repo doesn't exist — skip silently
                        }
                        response.isSuccessful && body != null -> {
                            try {
                                val arr = JSONArray(body)
                                // Find the FIRST pdf in the repo root
                                var found = false
                                for (i in 0 until arr.length()) {
                                    if (found) break
                                    val obj = arr.getJSONObject(i)
                                    if (obj.getString("type") == "file" &&
                                        obj.getString("name").lowercase().endsWith(".pdf")) {

                                        val fileName = obj.getString("name")
                                        // FIX 10: Prefer the download_url field from the API
                                        // which is always correct, rather than constructing it manually
                                        val downloadUrl = obj.optString("download_url")
                                            .ifBlank { "https://raw.githubusercontent.com/$repoPath/main/$fileName" }

                                        // Broadcast this PDF to every slot that uses this repo
                                        slots.forEach { slotKey ->
                                            if (!bookCatalog.containsKey(slotKey)) {
                                                val (course, year) = slotKey.split("|")
                                                bookCatalog[slotKey] = buildBookData(
                                                    fileName, repoPath, course, year, downloadUrl
                                                )
                                            }
                                        }
                                        found = true
                                    }
                                }
                            } catch (_: Exception) { /* malformed JSON — skip */ }
                        }
                    }

                    if (pendingCount.decrementAndGet() == 0) onAllSlotsFetched()
                }
            }
        })
    }

    private fun onAllSlotsFetched() {
        progressLoading.visibility = View.GONE
        btnContinue.isEnabled      = true

        // FIX 11: If the catalog is completely empty (all repos failed / no PDFs),
        // show the retry banner so the user isn't left staring at a blank hint.
        if (bookCatalog.isEmpty()) {
            tvHint.text              = "Could not load books from GitHub."
            tvHint.visibility        = View.VISIBLE
            tvRetryStatus.text       = "Check your internet or GitHub repo settings, then tap Retry."
            tvRetryStatus.visibility = View.VISIBLE
            btnRetry.visibility      = View.VISIBLE
        } else {
            // Re-evaluate the book card now that data has arrived.
            // If the user already selected a course+year while loading was in
            // progress the card will show immediately — no extra tap needed.
            refreshBookCard()
        }
    }

    private fun buildBookData(
        fileName: String,
        repoPath: String,
        course: String,
        year: String,
        downloadUrl: String
    ): BookData {
        val displayName = fileName.removeSuffix(".pdf")
        val cleanTitle  = displayName
            .replace(Regex("[_\\-]+"), " ")
            .split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            .trim()
        return BookData(
            title       = cleanTitle,
            author      = repoPath.substringBefore("/"),
            description = "PDF from GitHub · $repoPath",
            chapters    = 0,
            course      = course,
            year        = year,
            downloadUrl = downloadUrl
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  BOOK CARD REFRESH
    // ─────────────────────────────────────────────────────────────────────────
    private fun currentKey() =
        if (courseIndex >= 0 && yearIndex >= 0)
            "${courseLabels[courseIndex]}|${allYearLabels[yearIndex]}"
        else ""

    private fun refreshBookCard() {
        // Hide the retry banner whenever the card might show
        btnRetry.visibility        = View.GONE
        tvRetryStatus.visibility   = View.GONE

        if (courseIndex < 0 || yearIndex < 0) {
            tvHint.text = if (courseIndex >= 0)
                "Now select your academic year."
            else
                "Select a course and year above to see your starter book."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE
            return
        }

        val key  = currentKey()
        val book = bookCatalog[key]

        if (book == null) {
            // Still loading or no PDF in this slot
            val stillLoading = pendingCount.get() > 0
            tvHint.text = if (stillLoading)
                "Still loading… please wait."
            else
                "No PDF found for this course/year in the repository."
            tvHint.visibility         = View.VISIBLE
            bookGridLayout.visibility = View.GONE

            // Offer retry if loading already finished and nothing was found
            if (!stillLoading) {
                tvRetryStatus.text       = "Check the repository for this slot and tap Retry."
                tvRetryStatus.visibility = View.VISIBLE
                btnRetry.visibility      = View.VISIBLE
            }
            return
        }

        // ── Show the book card ────────────────────────────────────────────────
        tvBookTitle.text    = book.title
        tvBookAuthor.text   = "from ${book.author}"
        tvBookDesc.text     = book.description
        tvBookChapters.text = if (book.chapters > 0) "${book.chapters} Chapters" else "GitHub Repository"

        val dp = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * dp).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")
        bookConfirmed = false

        tvHint.visibility         = View.GONE
        bookGridLayout.visibility = View.VISIBLE
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  UI HELPERS
    // ─────────────────────────────────────────────────────────────────────────
    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val dp = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * dp).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) null
        else {
            clicked.strokeWidth = (strokeSelected * dp).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
