package com.example.a404.models

// OpenStax API Response Models
data class OpenStaxResponse(
    val results: List<OpenStaxBook>?
)

data class OpenStaxBook(
    val id: Int,
    val title: String,
    val short_description: String,
    val cover_url: String,
    val web_url: String,
    val authors: List<OpenStaxAuthor>?
)

data class OpenStaxAuthor(
    val name: String
)

// MIT OpenCourseWare Response Models
data class MITResponse(
    val results: List<MITCourse>?
)

data class MITCourse(
    val id: String,
    val title: String,
    val description: String,
    val image_src: String,
    val course_id: String,
    val url: String,
    val level: String
)

// Open Culture Response Model
data class OpenCultureResponse(
    val books: List<OpenCultureBook>?
)

data class OpenCultureBook(
    val title: String,
    val author: String,
    val url: String,
    val image: String,
    val subject: String
)
