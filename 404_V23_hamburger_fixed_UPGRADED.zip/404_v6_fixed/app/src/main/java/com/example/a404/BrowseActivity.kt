package com.example.a404

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.example.a404.models.Book
import com.example.a404.services.BookRepositoryService
import com.example.a404.utils.NetworkUtil
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BrowseActivity : ComponentActivity() {

    private val sourceItems = mutableListOf<Pair<MaterialCardView, String>>()
    private var hamburgerPopup: PopupWindow? = null
    private lateinit var bookRepositoryService: BookRepositoryService
    private val scope = CoroutineScope(Dispatchers.Main)
    private var currentBooks = listOf<Book>()
    private var selectedSource = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.browse_sources_1)

        // Check internet connection
        if (!NetworkUtil.isNetworkAvailable(this)) {
            Toast.makeText(this, "Internet connection required to browse books", Toast.LENGTH_LONG).show()
        }

        bookRepositoryService = BookRepositoryService(this)

        // Get selected course from SharedPreferences
        val prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val selectedCourse = prefs.getString("SELECTED_COURSE", "BS Computer Science") ?: "BS Computer Science"

        // ── Setup Repository Source Filters ───────────────────────────────────
        val sourceItems = mutableListOf<Pair<MaterialCardView, String>>()
        sourceItems += Pair(
            findViewById<MaterialCardView>(R.id.source_item_1),
            "OpenStax"
        )
        sourceItems += Pair(
            findViewById<MaterialCardView>(R.id.source_item_2),
            "Open Culture"
        )

        // Setup source item click listeners
        sourceItems.forEach { (card, source) ->
            card.setOnClickListener {
                selectedSource = source
                loadBooksBySource(selectedCourse, source)
                Toast.makeText(this, "Showing books from $source", Toast.LENGTH_SHORT).show()
            }
        }

        // Load initial books for the course
        loadBooksForCourse(selectedCourse)

        // ── Search setup ──────────────────────────────────────────────────────
        val searchIcon      = findViewById<View>(R.id.search_icon)
        val searchContainer = findViewById<View>(R.id.search_bar_container)
        val searchInput     = findViewById<EditText>(R.id.search_input)
        val cancelBtn       = findViewById<TextView>(R.id.btn_cancel_search)
        val noResults       = findViewById<View>(R.id.no_results_view)

        searchIcon.setOnClickListener {
            searchContainer.visibility = View.VISIBLE
            searchInput.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }

        cancelBtn.setOnClickListener {
            searchInput.setText("")
            searchContainer.visibility = View.GONE
            showAllItems()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filterItems(s?.toString() ?: "", noResults) }
        })

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
                true
            } else false
        }

        // ── Hamburger PopupWindow ─────────────────────────────────────────────
        val menuButton = findViewById<ImageView>(R.id.menu_button)
        menuButton.setOnClickListener { anchor ->
            if (hamburgerPopup?.isShowing == true) {
                hamburgerPopup?.dismiss()
            } else {
                showHamburgerMenu(anchor)
            }
        }

        setupNavigation()
    }

    private fun loadBooksForCourse(course: String) {
        scope.launch {
            try {
                val books = withContext(Dispatchers.Default) {
                    bookRepositoryService.getAllBooksForCourse(course)
                }
                currentBooks = books
                updateSourceDisplay(books)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@BrowseActivity, "Error loading books", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadBooksBySource(course: String, source: String) {
        scope.launch {
            try {
                val books = withContext(Dispatchers.Default) {
                    bookRepositoryService.getBooksBySource(course, source)
                }
                currentBooks = books
                updateSourceDisplay(books)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@BrowseActivity, "Error loading books from $source", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateSourceDisplay(books: List<Book>) {
        // Update UI to display books
        val sourceContainer = findViewById<LinearLayout>(R.id.source_list_container)
        sourceContainer?.removeAllViews()

        if (books.isEmpty()) {
            val noBooks = TextView(this).apply {
                text = "No books available. Please ensure you have internet connection and valid course selection."
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            sourceContainer?.addView(noBooks)
        } else {
            books.forEach { book ->
                val bookView = createBookItemView(book)
                sourceContainer?.addView(bookView)
            }
        }
    }

    private fun createBookItemView(book: Book): View {
        val container = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        val titleView = TextView(this).apply {
            text = book.title
            textSize = 16f
            setTextColor(android.graphics.Color.BLACK)
        }

        val authorView = TextView(this).apply {
            text = "by ${book.author}"
            textSize = 14f
            setTextColor(android.graphics.Color.GRAY)
        }

        val sourceView = TextView(this).apply {
            text = "Source: ${book.source}"
            textSize = 12f
            setTextColor(android.graphics.Color.parseColor("#6A1B9A"))
        }

        container.addView(titleView)
        container.addView(authorView)
        container.addView(sourceView)

        return container
    }

    private fun showHamburgerMenu(anchor: View) {
        val popupView = LayoutInflater.from(this)
            .inflate(R.layout.hamburger_dropdown_menu, null)

        val dp = resources.displayMetrics.density
        val popup = PopupWindow(
            popupView,
            (200 * dp).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            true  // focusable = true → blocks ALL background touches until dismissed
        ).apply {
            elevation = 12 * dp
            animationStyle = R.style.HamburgerDropdownAnimation
            isOutsideTouchable = true
        }

        popupView.findViewById<View>(R.id.menu_item_guide).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, GuideActivity::class.java))
        }
        popupView.findViewById<View>(R.id.menu_item_about_us).setOnClickListener {
            popup.dismiss()
            startActivity(Intent(this, AboutUsActivity::class.java))
        }

        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        popup.showAtLocation(
            anchor,
            Gravity.NO_GRAVITY,
            loc[0],
            loc[1] + anchor.height + (4 * dp).toInt()
        )
        hamburgerPopup = popup
    }

    private fun filterItems(query: String, noResults: View) {
        val q = query.trim().lowercase()
        var anyVisible = false
        sourceItems.forEach { (card, text) ->
            val match = q.isEmpty() || text.lowercase().contains(q)
            card.visibility = if (match) View.VISIBLE else View.GONE
            if (match) anyVisible = true
        }
        noResults.visibility = if (!anyVisible && q.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun showAllItems() {
        sourceItems.forEach { (card, _) -> card.visibility = View.VISIBLE }
    }

    private fun setupNavigation() {
        findViewById<LinearLayout>(R.id.nav_library)?.setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_history)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.nav_download)?.setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
    }
}
