package com.example.a404.models

import java.io.Serializable

data class Book(
    val id: String,
    val title: String,
    val author: String,
    val subject: String,
    val description: String,
    val coverUrl: String,
    val bookUrl: String,
    val source: String, // "OpenStax", "OpenCulture", "MIT OpenCourseWare"
    val course: String,
    val academicYear: String,
    val language: String = "English",
    val publishDate: String = "",
    val isbn: String = ""
) : Serializable
