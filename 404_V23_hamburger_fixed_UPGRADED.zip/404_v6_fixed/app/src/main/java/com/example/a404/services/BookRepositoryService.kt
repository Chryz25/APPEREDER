package com.example.a404.services

import android.content.Context
import com.example.a404.api.BookRepositoryAPI
import com.example.a404.models.Book
import com.example.a404.utils.NetworkUtil
import com.google.gson.Gson
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class BookRepositoryService(private val context: Context) {

    private val openStaxRetrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.openstax.org/api/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private val openStaxAPI: BookRepositoryAPI by lazy {
        openStaxRetrofit.create(BookRepositoryAPI::class.java)
    }

    // Course to subject mapping
    private val courseSubjectMap = mapOf(
        "Computer Science" to listOf("computer science", "programming", "data structures"),
        "Information Technology" to listOf("information technology", "web development"),
        "Engineering" to listOf("engineering", "physics"),
        "Business" to listOf("business", "economics", "accounting"),
        "Mathematics" to listOf("mathematics", "calculus", "algebra"),
        "Science" to listOf("biology", "chemistry", "physics"),
        "Health Sciences" to listOf("health sciences", "medicine", "nursing"),
        "Education" to listOf("education", "pedagogy")
    )

    /**
     * Fetch books from OpenStax based on course and academic year
     */
    fun getOpenStaxBooks(course: String): List<Book> {
        if (!NetworkUtil.isNetworkAvailable(context)) {
            return emptyList()
        }

        val subjects = courseSubjectMap[course] ?: listOf(course.lowercase())
        val allBooks = mutableListOf<Book>()

        subjects.forEach { subject ->
            try {
                val response = openStaxAPI.getOpenStaxBooks(subject).execute()
                if (response.isSuccessful) {
                    response.body()?.results?.forEach { book ->
                        val authors = book.authors?.joinToString(", ") { it.name } ?: "Unknown"
                        allBooks.add(
                            Book(
                                id = "openstax_${book.id}",
                                title = book.title,
                                author = authors,
                                subject = subject,
                                description = book.short_description,
                                coverUrl = book.cover_url,
                                bookUrl = book.web_url,
                                source = "OpenStax",
                                course = course,
                                academicYear = getCurrentYear()
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return allBooks
    }

    /**
     * Fetch books from Open Culture - this uses a mock API for demo purposes
     * In production, you'd need to parse their website or use a web scraping service
     */
    fun getOpenCultureBooks(course: String): List<Book> {
        if (!NetworkUtil.isNetworkAvailable(context)) {
            return emptyList()
        }

        // Mock data - in production this would call actual API or parse website
        val mockBooks = listOf(
            Book(
                id = "openculture_1",
                title = "Introduction to Computer Science",
                author = "Open Culture",
                subject = "Computer Science",
                description = "Comprehensive introduction to computer science fundamentals",
                coverUrl = "https://via.placeholder.com/150?text=CS+101",
                bookUrl = "https://www.openculture.com",
                source = "Open Culture",
                course = course,
                academicYear = getCurrentYear()
            ),
            Book(
                id = "openculture_2",
                title = "Web Development Fundamentals",
                author = "Open Culture",
                subject = "Web Development",
                description = "Learn web development from scratch",
                coverUrl = "https://via.placeholder.com/150?text=WebDev",
                bookUrl = "https://www.openculture.com",
                source = "Open Culture",
                course = course,
                academicYear = getCurrentYear()
            )
        )

        return mockBooks.filter { it.course == course }
    }

    /**
     * Fetch books from MIT OpenCourseWare
     */
    fun getMITOpenCourseWareBooks(course: String): List<Book> {
        if (!NetworkUtil.isNetworkAvailable(context)) {
            return emptyList()
        }

        // Mock data - MIT OCW requires web scraping or unofficial API
        val mockBooks = listOf(
            Book(
                id = "mit_ocw_1",
                title = "Introduction to Algorithms",
                author = "MIT OpenCourseWare",
                subject = "Computer Science",
                description = "Algorithms and data structures from MIT",
                coverUrl = "https://via.placeholder.com/150?text=MIT+Algorithms",
                bookUrl = "https://ocw.mit.edu",
                source = "MIT OpenCourseWare",
                course = course,
                academicYear = getCurrentYear()
            ),
            Book(
                id = "mit_ocw_2",
                title = "Linear Algebra",
                author = "MIT OpenCourseWare",
                subject = "Mathematics",
                description = "Linear algebra fundamentals from MIT",
                coverUrl = "https://via.placeholder.com/150?text=MIT+LinearAlg",
                bookUrl = "https://ocw.mit.edu",
                source = "MIT OpenCourseWare",
                course = course,
                academicYear = getCurrentYear()
            )
        )

        return mockBooks.filter { it.course == course }
    }

    /**
     * Aggregate books from all repositories for a given course
     */
    fun getAllBooksForCourse(course: String): List<Book> {
        if (!NetworkUtil.isNetworkAvailable(context)) {
            return emptyList()
        }

        val allBooks = mutableListOf<Book>()
        allBooks.addAll(getOpenStaxBooks(course))
        allBooks.addAll(getOpenCultureBooks(course))
        allBooks.addAll(getMITOpenCourseWareBooks(course))

        return allBooks
    }

    /**
     * Get books filtered by source repository
     */
    fun getBooksBySource(course: String, source: String): List<Book> {
        return getAllBooksForCourse(course).filter { it.source == source }
    }

    private fun getCurrentYear(): String {
        return java.util.Calendar.getInstance().get(java.util.Calendar.YEAR).toString()
    }
}
