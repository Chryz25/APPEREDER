package com.example.a404.api

import com.example.a404.models.OpenStaxResponse
import com.example.a404.models.MITResponse
import com.example.a404.models.OpenCultureResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface BookRepositoryAPI {

    // OpenStax API endpoints
    @GET("books")
    fun getOpenStaxBooks(
        @Query("subject") subject: String,
        @Query("page") page: Int = 1,
        @Query("page_size") pageSize: Int = 20
    ): Call<OpenStaxResponse>

    // MIT OpenCourseWare endpoints (using web scraping data)
    // This would typically require parsing HTML or using an unofficial API
    @GET("courses")
    fun getMITCourses(
        @Query("subject") subject: String
    ): Call<MITResponse>

    // Open Culture endpoints
    @GET("books")
    fun getOpenCultureBooks(
        @Query("subject") subject: String,
        @Query("limit") limit: Int = 20
    ): Call<OpenCultureResponse>
}
