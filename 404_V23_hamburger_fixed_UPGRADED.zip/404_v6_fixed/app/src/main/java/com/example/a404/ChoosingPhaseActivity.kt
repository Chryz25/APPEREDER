package com.example.a404

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.example.a404.models.Book
import com.example.a404.services.BookRepositoryService
import com.example.a404.utils.NetworkUtil
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChoosingPhaseActivity : ComponentActivity() {

    private var selectedCourse: MaterialCardView? = null
    private var selectedYear: MaterialCardView? = null
    private var bookConfirmed = false
    private var selectedBook: Book? = null

    private val courseLabels = listOf(
        "BS Computer Science",
        "BS Information Technology",
        "BS Multimedia Computing",
        "BS Applied Computer Technology"
    )

    private val yearLabels = listOf("1st Year", "2nd Year", "3rd Year", "4th Year")

    private lateinit var bookRepositoryService: BookRepositoryService
    private val scope = CoroutineScope(Dispatchers.Main)

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    private val colorSelected = Color.parseColor("#FFFFF0E8")
    private val colorDefault  = Color.WHITE
    private val strokeSelected = 2
    private val strokeDefault  = 1

    private var courseIndex = -1
    private var yearIndex   = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.choosing_phase)

        // Check internet connection
        if (!NetworkUtil.isNetworkAvailable(this)) {
            Toast.makeText(this, "Internet connection required to load books", Toast.LENGTH_LONG).show()
        }

        bookRepositoryService = BookRepositoryService(this)

        val btnContinue    = findViewById<Button>(R.id.btn_continue)
        val tvHint         = findViewById<TextView>(R.id.tv_book_hint)
        val bookGridLayout = findViewById<View>(R.id.book_grid)
        val bookCard       = findViewById<MaterialCardView>(R.id.selectionbook_1)
        val tvBookTitle    = findViewById<TextView>(R.id.book_title_label)
        val tvBookAuthor   = findViewById<TextView>(R.id.book_author_label)
        val tvBookDesc     = findViewById<TextView>(R.id.book_desc_label)
        val tvBookChapters = findViewById<TextView>(R.id.book_chapters_label)
        val progressBar    = findViewById<ProgressBar>(R.id.progress_loading)

        // ── Course cards ──────────────────────────────────────────────────────
        val courses = listOf(
            findViewById<MaterialCardView>(R.id.btn_course_1),
            findViewById<MaterialCardView>(R.id.btn_course_2),
            findViewById<MaterialCardView>(R.id.btn_course_3),
            findViewById<MaterialCardView>(R.id.btn_course_4)
        )
        courses.forEachIndexed { idx, card ->
            card.setOnClickListener {
                val newSelected = selectCard(card, courses, selectedCourse)
                selectedCourse = newSelected
                courseIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                if (courseIndex >= 0 && yearIndex >= 0) {
                    loadBooksForSelection(tvHint, bookGridLayout, bookCard,
                        tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters, progressBar)
                } else {
                    refreshBookCard(tvHint, bookGridLayout, bookCard,
                        tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters, null)
                }
            }
        }

        // ── Year chips ────────────────────────────────────────────────────────
        val yearChips = listOf(
            findViewById<MaterialCardView>(R.id.chip_year_1),
            findViewById<MaterialCardView>(R.id.chip_year_2),
            findViewById<MaterialCardView>(R.id.chip_year_3),
            findViewById<MaterialCardView>(R.id.chip_year_4)
        )
        yearChips.forEachIndexed { idx, chip ->
            chip.setOnClickListener {
                val newSelected = selectCard(chip, yearChips, selectedYear)
                selectedYear = newSelected
                yearIndex = if (newSelected != null) idx else -1
                bookConfirmed = false
                if (courseIndex >= 0 && yearIndex >= 0) {
                    loadBooksForSelection(tvHint, bookGridLayout, bookCard,
                        tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters, progressBar)
                } else {
                    refreshBookCard(tvHint, bookGridLayout, bookCard,
                        tvBookTitle, tvBookAuthor, tvBookDesc, tvBookChapters, null)
                }
            }
        }

        // ── Book card tap = confirm / deconfirm ───────────────────────────────
        bookCard.setOnClickListener {
            if (courseIndex >= 0 && yearIndex >= 0 && selectedBook != null) {
                bookConfirmed = !bookConfirmed
                val density = resources.displayMetrics.density
                if (bookConfirmed) {
                    bookCard.strokeWidth = (strokeSelected * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FF6A1B9A")
                    bookCard.setCardBackgroundColor(colorSelected)
                    tintCardText(bookCard, "#FF6A1B9A")
                } else {
                    bookCard.strokeWidth = (strokeDefault * density).toInt()
                    bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
                    bookCard.setCardBackgroundColor(colorDefault)
                    tintCardText(bookCard, "#FF2A2A2A")
                }
            }
        }

        // ── Continue ──────────────────────────────────────────────────────────
        btnContinue.setOnClickListener {
            if (courseIndex < 0) {
                Toast.makeText(this, "Please choose a course", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (yearIndex < 0) {
                Toast.makeText(this, "Please select an academic year", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!bookConfirmed || selectedBook == null) {
                Toast.makeText(this, "Please tap the book to confirm your selection",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val book = selectedBook ?: return@setOnClickListener

            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).edit()
                .putString("SELECTED_BOOK", book.title)
                .putString("SELECTED_AUTHOR", book.author)
                .putString("SELECTED_DESC", book.description)
                .putString("SELECTED_COURSE", book.course)
                .putString("SELECTED_YEAR", book.academicYear)
                .putString("SELECTED_SOURCE", book.source)
                .putString("SELECTED_BOOK_URL", book.bookUrl)
                .putString("SELECTED_COVER_URL", book.coverUrl)
                .putBoolean("PROFILE_SETUP_DONE", true)
                .apply()

            startActivity(Intent(this, LibraryActivity::class.java))
            finish()
        }
    }

    private fun loadBooksForSelection(
        tvHint: TextView,
        bookGrid: View,
        bookCard: MaterialCardView,
        tvTitle: TextView,
        tvAuthor: TextView,
        tvDesc: TextView,
        tvChapters: TextView,
        progressBar: ProgressBar
    ) {
        progressBar.visibility = View.VISIBLE
        
        scope.launch {
            try {
                val course = courseLabels[courseIndex]
                val books = withContext(Dispatchers.Default) {
                    bookRepositoryService.getAllBooksForCourse(course)
                }

                if (books.isEmpty()) {
                    Toast.makeText(
                        this@ChoosingPhaseActivity,
                        "No books available for this course. Please check your internet connection.",
                        Toast.LENGTH_SHORT
                    ).show()
                    tvHint.visibility = View.VISIBLE
                    bookGrid.visibility = View.GONE
                    progressBar.visibility = View.GONE
                    return@launch
                }

                selectedBook = books.firstOrNull()
                refreshBookCard(tvHint, bookGrid, bookCard, tvTitle, tvAuthor, tvDesc, tvChapters, selectedBook)
                progressBar.visibility = View.GONE
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@ChoosingPhaseActivity,
                    "Error loading books: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun refreshBookCard(
        tvHint: TextView,
        bookGrid: View,
        bookCard: MaterialCardView,
        tvTitle: TextView,
        tvAuthor: TextView,
        tvDesc: TextView,
        tvChapters: TextView,
        book: Book?
    ) {
        if (book == null) {
            tvHint.visibility = View.VISIBLE
            bookGrid.visibility = View.GONE
            return
        }

        tvTitle.text = book.title
        tvAuthor.text = "by ${book.author}"
        tvDesc.text = book.description
        tvChapters.text = "Source: ${book.source}"

        // Reset visual state
        val density = resources.displayMetrics.density
        bookCard.strokeWidth = (strokeDefault * density).toInt()
        bookCard.strokeColor = Color.parseColor("#FFD6C5B4")
        bookCard.setCardBackgroundColor(colorDefault)
        tintCardText(bookCard, "#FF2A2A2A")

        tvHint.visibility = View.GONE
        bookGrid.visibility = View.VISIBLE
    }

    private fun selectCard(
        clicked: MaterialCardView,
        all: List<MaterialCardView>,
        current: MaterialCardView?
    ): MaterialCardView? {
        val density = resources.displayMetrics.density
        all.forEach { card ->
            card.strokeWidth = (strokeDefault * density).toInt()
            card.strokeColor = Color.parseColor("#FFD6C5B4")
            card.setCardBackgroundColor(colorDefault)
            tintCardText(card, "#FF2A2A2A")
        }
        return if (clicked == current) {
            null
        } else {
            clicked.strokeWidth = (strokeSelected * density).toInt()
            clicked.strokeColor = Color.parseColor("#FF6A1B9A")
            clicked.setCardBackgroundColor(colorSelected)
            tintCardText(clicked, "#FF6A1B9A")
            clicked
        }
    }

    private fun tintCardText(view: android.view.View, hex: String) {
        val color = Color.parseColor(hex)
        if (view is TextView) {
            view.setTextColor(color)
        } else if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) tintCardText(view.getChildAt(i), hex)
        }
    }
}
